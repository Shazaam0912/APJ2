# Project Management Dashboard (Frontend Rebuild)

This is a standalone frontend implementation of the Project Management Dashboard, built with React, TypeScript, and Tailwind CSS.

## Features

- **Project Board**: Kanban-style task management with drag-and-drop support.
- **Modern UI**: Dark mode, glassmorphism, and premium design aesthetics.
- **Responsive Layout**: Sidebar navigation and top bar actions.

## Getting Started

1.  Install dependencies:
    ```bash
    npm install
    ```

2.  Start the development server:
    ```bash
    npm run dev
    ```

3.  Open [http://localhost:5173](http://localhost:5173) in your browser.

## Tech Stack

-   **Framework**: Vite + React + TypeScript
-   **Styling**: Tailwind CSS
-   **Icons**: Lucide React
-   **Drag & Drop**: React Beautiful DnD
# AAPM
