/**
 * Sprints API Service
 */

const API_BASE = 'http://localhost:8000';

export interface Sprint {
    id: string;
    name: string;
    goal?: string;
    status: string;
    project_id: string;
    start_date?: string;
    end_date?: string;
    task_ids: string[];
    velocity: number;
    created_at: string;
    updated_at: string;
}

export interface SprintCreate {
    name: string;
    goal?: string;
    project_id: string;
    start_date?: string;
    end_date?: string;
}

export const SprintsAPI = {
    async getAll(projectId?: string): Promise<Sprint[]> {
        const url = projectId
            ? `${API_BASE}/sprints?project_id=${projectId}`
            : `${API_BASE}/sprints`;
        const response = await fetch(url);
        if (!response.ok) throw new Error('Failed to fetch sprints');
        return response.json();
    },

    async getById(id: string): Promise<Sprint> {
        const response = await fetch(`${API_BASE}/sprints/${id}`);
        if (!response.ok) throw new Error('Failed to fetch sprint');
        return response.json();
    },

    async create(sprint: SprintCreate): Promise<Sprint> {
        const response = await fetch(`${API_BASE}/sprints`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(sprint),
        });
        if (!response.ok) throw new Error('Failed to create sprint');
        return response.json();
    },

    async update(id: string, updates: Partial<SprintCreate & { status: string }>): Promise<Sprint> {
        const response = await fetch(`${API_BASE}/sprints/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(updates),
        });
        if (!response.ok) throw new Error('Failed to update sprint');
        return response.json();
    },

    async delete(id: string): Promise<void> {
        const response = await fetch(`${API_BASE}/sprints/${id}`, {
            method: 'DELETE',
        });
        if (!response.ok) throw new Error('Failed to delete sprint');
    },
};
