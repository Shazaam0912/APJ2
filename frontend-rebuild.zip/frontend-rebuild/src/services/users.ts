/**
 * Users API Service
 */

const API_BASE = 'http://localhost:8000';

export interface User {
    id: string;
    name: string;
    email: string;
    role: string;
    avatar?: string;
    is_active: boolean;
    preferences: any;
    created_at: string;
    updated_at: string;
}

export interface UserCreate {
    name: string;
    email: string;
    role?: string;
}

export const UsersAPI = {
    async getAll(): Promise<User[]> {
        const response = await fetch(`${API_BASE}/users`);
        if (!response.ok) throw new Error('Failed to fetch users');
        return response.json();
    },

    async getById(id: string): Promise<User> {
        const response = await fetch(`${API_BASE}/users/${id}`);
        if (!response.ok) throw new Error('Failed to fetch user');
        return response.json();
    },

    async create(user: UserCreate): Promise<User> {
        const response = await fetch(`${API_BASE}/users`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(user),
        });
        if (!response.ok) throw new Error('Failed to create user');
        return response.json();
    },

    async update(id: string, updates: Partial<UserCreate & { is_active: boolean }>): Promise<User> {
        const response = await fetch(`${API_BASE}/users/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(updates),
        });
        if (!response.ok) throw new Error('Failed to update user');
        return response.json();
    },

    async delete(id: string): Promise<void> {
        const response = await fetch(`${API_BASE}/users/${id}`, {
            method: 'DELETE',
        });
        if (!response.ok) throw new Error('Failed to delete user');
    },
};
