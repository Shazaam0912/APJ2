/**
 * Projects API Service
 */

const API_BASE = 'http://localhost:8000';

export interface Project {
    id: string;
    name: string;
    key: string;
    description?: string;
    status: string;
    category: string;
    board_config: any;
    members: any[];
    created_at: string;
    updated_at: string;
}

export interface ProjectCreate {
    name: string;
    description?: string;
    category?: string;
}

export const ProjectsAPI = {
    async getAll(): Promise<Project[]> {
        const response = await fetch(`${API_BASE}/projects`);
        if (!response.ok) throw new Error('Failed to fetch projects');
        return response.json();
    },

    async getById(id: string): Promise<Project> {
        const response = await fetch(`${API_BASE}/projects/${id}`);
        if (!response.ok) throw new Error('Failed to fetch project');
        return response.json();
    },

    async create(project: ProjectCreate): Promise<Project> {
        const response = await fetch(`${API_BASE}/projects`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(project),
        });
        if (!response.ok) throw new Error('Failed to create project');
        return response.json();
    },

    async update(id: string, updates: Partial<ProjectCreate>): Promise<Project> {
        const response = await fetch(`${API_BASE}/projects/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(updates),
        });
        if (!response.ok) throw new Error('Failed to update project');
        return response.json();
    },

    async delete(id: string): Promise<void> {
        const response = await fetch(`${API_BASE}/projects/${id}`, {
            method: 'DELETE',
        });
        if (!response.ok) throw new Error('Failed to delete project');
    },
};
