const API_BASE = 'http://localhost:8000';

export interface UnifiedAgentRequest {
    prompt: string;
    context?: {
        project_id?: string;
        priority?: string;
        tasks?: any[];
        backlog?: any[];
        goals?: string;
        capacity?: number;
        team_info?: string;
        hourly_rate?: number;
    };
    history?: Array<{ role: string; content: string }>;
}

export interface UnifiedAgentResponse {
    success: boolean;
    action: string;
    result: any;
    message: string;
    execution_details?: any;
}

export const AgentAPI = {
    /**
     * **Unified Agent Endpoint** - One prompt, all capabilities
     * 
     * Examples:
     * - "Create a food delivery mobile app"
     * - "Add a task to implement login"
     * - "Break down the payment integration"
     * - "Estimate time for auth system"
     * - "Prioritize my backlog"
     */
    async execute(prompt: string, context?: any, history?: Array<{ role: string; content: string }>): Promise<UnifiedAgentResponse> {
        const response = await fetch(`${API_BASE}/agent/execute`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ prompt, context, history })
        });
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({ detail: 'Failed to execute agent command' }));
            throw new Error(errorData.detail || 'Failed to execute agent command');
        }
        return response.json();
    },

    async getCapabilities(): Promise<any> {
        const response = await fetch(`${API_BASE}/agent/capabilities`);
        if (!response.ok) throw new Error('Failed to get capabilities');
        return response.json();
    },

    async checkStatus(): Promise<{ enabled: boolean; model?: string; endpoint: string }> {
        const response = await fetch(`${API_BASE}/agent/status`);
        if (!response.ok) throw new Error('Failed to check agent status');
        return response.json();
    }
};
