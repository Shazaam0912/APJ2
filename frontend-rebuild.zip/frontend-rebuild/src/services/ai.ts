import { GoogleGenerativeAI } from '@google/generative-ai';

const API_KEY = import.meta.env.VITE_GEMINI_API_KEY;

let genAI: GoogleGenerativeAI | null = null;
let model: any = null;

if (API_KEY) {
    genAI = new GoogleGenerativeAI(API_KEY);
    model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });
}

export const isAIEnabled = () => !!API_KEY;

export const generateText = async (prompt: string): Promise<string> => {
    if (!model) throw new Error('AI not configured. Missing API Key.');
    try {
        const result = await model.generateContent(prompt);
        const response = await result.response;
        return response.text();
    } catch (error) {
        console.error('AI Generation Error:', error);
        throw error;
    }
};

export const summarizeTask = async (taskContent: string, description: string): Promise<string> => {
    const prompt = `Summarize the following task into a concise 1-sentence overview:
    Task: ${taskContent}
    Description: ${description}`;
    return generateText(prompt);
};

export const suggestSubtasks = async (taskContent: string): Promise<string[]> => {
    const prompt = `Suggest 3-5 actionable subtasks for the following task. Return ONLY the subtasks as a bulleted list.
    Task: ${taskContent}`;
    const text = await generateText(prompt);
    return text.split('\n').filter(line => line.trim().startsWith('-') || line.trim().startsWith('*')).map(line => line.replace(/^[-*]\s*/, '').trim());
};

export const chatWithAgent = async (history: { role: 'user' | 'model', parts: string }[], message: string) => {
    if (!model) throw new Error('AI not configured.');

    // Convert simple history format to Gemini format if needed, 
    // but startChat expects { role, parts: [{ text }] }
    const chat = model.startChat({
        history: history.map(h => ({
            role: h.role,
            parts: [{ text: h.parts }]
        })),
        generationConfig: {
            maxOutputTokens: 1000,
        },
    });

    const result = await chat.sendMessage(message);
    const response = await result.response;
    return response.text();
};
