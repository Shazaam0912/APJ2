import { Layout } from './components/layout/Layout';
import { ProjectBoard } from './pages/ProjectBoard';
import { Dashboard } from './pages/Dashboard';
import { Chat } from './pages/Chat';
import { Calendar } from './pages/Calendar';
import { Team } from './pages/Team';
import { Settings } from './pages/Settings';
import { Inbox } from './pages/Inbox';
import { Documents } from './pages/Documents';
import APITest from './pages/APITest';
import { DataProvider, useData } from './context/DataContext';
import { CommandPalette } from './components/search/CommandPalette';
import { NotificationToast } from './components/NotificationToast';

const AppContent = () => {
  const { activePage } = useData();

  return (
    <>
      <CommandPalette />
      <NotificationToast />
      <Layout>
        {activePage === 'dashboard' && <Dashboard />}
        {activePage === 'projects' && <ProjectBoard />}
        {activePage === 'inbox' && <Inbox />}
        {activePage === 'chat' && <Chat />}
        {activePage === 'documents' && <Documents />}
        {activePage === 'calendar' && <Calendar />}
        {activePage === 'team' && <Team />}
        {activePage === 'settings' && <Settings />}
        {activePage === 'api-test' && <APITest />}
      </Layout>
    </>
  );
};

function App() {
  return (
    <DataProvider>
      <AppContent />
    </DataProvider>
  );
}

export default App;
