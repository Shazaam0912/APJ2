import { useState } from 'react';
import { Plus, Calendar as CalendarIcon, List, Clock } from 'lucide-react';
import clsx from 'clsx';
import { useData } from '../context/DataContext';
import { EventModal } from '../components/calendar/EventModal';
import { WeekView } from '../components/calendar/WeekView';
import { DayView } from '../components/calendar/DayView';
import { AgendaView } from '../components/calendar/AgendaView';
import { MonthView } from '../components/calendar/MonthView';

type ViewMode = 'month' | 'week' | 'day' | 'agenda';

export const Calendar = () => {
    const { events, addEvent, updateEvent, deleteEvent } = useData();
    const [currentDate, setCurrentDate] = useState(new Date());
    const [viewMode, setViewMode] = useState<ViewMode>('month');
    const [showEventModal, setShowEventModal] = useState(false);
    const [selectedEvent, setSelectedEvent] = useState<any>(null);
    const [selectedDate, setSelectedDate] = useState<Date | null>(null);

    const handlePrevious = () => {
        const newDate = new Date(currentDate);
        switch (viewMode) {
            case 'month':
                newDate.setMonth(newDate.getMonth() - 1);
                break;
            case 'week':
                newDate.setDate(newDate.getDate() - 7);
                break;
            case 'day':
                newDate.setDate(newDate.getDate() - 1);
                break;
        }
        setCurrentDate(newDate);
    };

    const handleNext = () => {
        const newDate = new Date(currentDate);
        switch (viewMode) {
            case 'month':
                newDate.setMonth(newDate.getMonth() + 1);
                break;
            case 'week':
                newDate.setDate(newDate.getDate() + 7);
                break;
            case 'day':
                newDate.setDate(newDate.getDate() + 1);
                break;
        }
        setCurrentDate(newDate);
    };

    const handleToday = () => {
        setCurrentDate(new Date());
    };

    const handleCreateEvent = (date?: Date) => {
        setSelectedDate(date || null);
        setSelectedEvent(null);
        setShowEventModal(true);
    };

    const handleEditEvent = (event: any) => {
        setSelectedEvent(event);
        setShowEventModal(true);
    };

    const handleCloseModal = () => {
        setShowEventModal(false);
        setSelectedEvent(null);
        setSelectedDate(null);
    };

    const getDateRangeText = () => {
        const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

        switch (viewMode) {
            case 'month':
                return `${monthNames[currentDate.getMonth()]} ${currentDate.getFullYear()}`;
            case 'week': {
                const startOfWeek = new Date(currentDate);
                startOfWeek.setDate(currentDate.getDate() - currentDate.getDay());
                const endOfWeek = new Date(startOfWeek);
                endOfWeek.setDate(startOfWeek.getDate() + 6);
                return `${monthNames[startOfWeek.getMonth()]} ${startOfWeek.getDate()} - ${monthNames[endOfWeek.getMonth()]} ${endOfWeek.getDate()}, ${currentDate.getFullYear()}`;
            }
            case 'day':
                return `${monthNames[currentDate.getMonth()]} ${currentDate.getDate()}, ${currentDate.getFullYear()}`;
            case 'agenda':
                return 'Upcoming Events';
        }
    };

    return (
        <div className="h-full flex flex-col bg-white">
            {/* Header with Controls */}
            <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-4">
                    <h1 className="text-3xl font-bold text-gray-900">{getDateRangeText()}</h1>

                    {viewMode !== 'agenda' && (
                        <div className="flex items-center gap-1 bg-white rounded-xl border border-gray-200 p-1 shadow-sm">
                            <button onClick={handlePrevious} className="px-3 py-1.5 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-all text-sm font-medium">
                                Previous
                            </button>
                            <button onClick={handleToday} className="px-3 py-1.5 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-all text-sm font-medium">
                                Today
                            </button>
                            <button onClick={handleNext} className="px-3 py-1.5 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-all text-sm font-medium">
                                Next
                            </button>
                        </div>
                    )}
                </div>

                <div className="flex items-center gap-3">
                    {/* View Switcher */}
                    <div className="flex items-center gap-1 bg-gray-50 border border-gray-200 rounded-xl p-1 shadow-sm">
                        <button
                            onClick={() => setViewMode('month')}
                            className={clsx(
                                'flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-semibold transition-all',
                                viewMode === 'month' ? 'bg-primary text-white shadow-sm' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                            )}
                        >
                            <CalendarIcon className="w-4 h-4" />
                            Month
                        </button>
                        <button
                            onClick={() => setViewMode('week')}
                            className={clsx(
                                'flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-semibold transition-all',
                                viewMode === 'week' ? 'bg-primary text-white shadow-sm' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                            )}
                        >
                            <Clock className="w-4 h-4" />
                            Week
                        </button>
                        <button
                            onClick={() => setViewMode('day')}
                            className={clsx(
                                'flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-semibold transition-all',
                                viewMode === 'day' ? 'bg-primary text-white shadow-sm' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                            )}
                        >
                            <Clock className="w-4 h-4" />
                            Day
                        </button>
                        <button
                            onClick={() => setViewMode('agenda')}
                            className={clsx(
                                'flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-semibold transition-all',
                                viewMode === 'agenda' ? 'bg-primary text-white shadow-sm' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                            )}
                        >
                            <List className="w-4 h-4" />
                            Agenda
                        </button>
                    </div>

                    <button
                        onClick={() => handleCreateEvent()}
                        className="flex items-center gap-2 bg-white hover:bg-gray-50 border-2 border-primary text-primary px-5 py-2.5 rounded-xl text-sm font-semibold transition-all shadow-sm hover:shadow-md"
                    >
                        <Plus className="w-4 h-4" />
                        New Event
                    </button>
                </div>
            </div>

            {/* Calendar Views */}
            <div className="flex-1 overflow-hidden">
                {viewMode === 'month' && (
                    <MonthView
                        currentDate={currentDate}
                        events={events}
                        onEventClick={handleEditEvent}
                        onDateClick={handleCreateEvent}
                    />
                )}
                {viewMode === 'week' && (
                    <WeekView
                        currentDate={currentDate}
                        events={events}
                        onEventClick={handleEditEvent}
                        onTimeSlotClick={handleCreateEvent}
                    />
                )}
                {viewMode === 'day' && (
                    <DayView
                        currentDate={currentDate}
                        events={events}
                        onEventClick={handleEditEvent}
                        onTimeSlotClick={handleCreateEvent}
                    />
                )}
                {viewMode === 'agenda' && (
                    <AgendaView
                        events={events}
                        onEventClick={handleEditEvent}
                        onCreateClick={handleCreateEvent}
                    />
                )}
            </div>

            {/* Event Modal */}
            {showEventModal && (
                <EventModal
                    event={selectedEvent}
                    initialDate={selectedDate}
                    onClose={handleCloseModal}
                    onSave={(eventData: any) => {
                        if (selectedEvent) {
                            updateEvent(selectedEvent.id, eventData);
                        } else {
                            addEvent(eventData as any);
                        }
                        handleCloseModal();
                    }}
                    onDelete={selectedEvent ? () => {
                        deleteEvent(selectedEvent.id);
                        handleCloseModal();
                    } : undefined}
                />
            )}
        </div>
    );
};
