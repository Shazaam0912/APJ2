import { useState } from 'react';
import { Hash, Lock, Search, Send, Smile, Paperclip, MoreVertical, Phone, Video } from 'lucide-react';
import clsx from 'clsx';
import { useData } from '../context/DataContext';

export const Chat = () => {
    const { channels, activeChannelId, setActiveChannelId, addMessage, teamMembers } = useData();
    const [messageInput, setMessageInput] = useState('');

    const activeChannel = channels.find(c => c.id === activeChannelId);

    const handleSend = (e: React.FormEvent) => {
        e.preventDefault();
        if (messageInput.trim()) {
            addMessage(activeChannelId, messageInput);
            setMessageInput('');
        }
    };

    return (
        <div className="h-full flex bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-sm">
            {/* Chat Sidebar */}
            <div className="w-64 bg-white border-r border-gray-200 flex flex-col">
                <div className="p-4 border-b border-gray-200">
                    <div className="relative">
                        <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
                        <input
                            type="text"
                            placeholder="Jump to..."
                            className="w-full bg-gray-50 rounded-xl pl-9 pr-3 py-2 text-sm text-gray-900 placeholder-gray-400 border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/10 outline-none transition-all"
                        />
                    </div>
                </div>

                <div className="flex-1 overflow-y-auto p-3 space-y-6">
                    <div>
                        <h3 className="px-3 text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Channels</h3>
                        <div className="space-y-0.5">
                            {channels.filter(c => c.type !== 'dm').map(channel => (
                                <button
                                    key={channel.id}
                                    onClick={() => setActiveChannelId(channel.id)}
                                    className={clsx(
                                        'w-full flex items-center justify-between px-3 py-2 rounded-xl text-sm transition-all group font-medium',
                                        activeChannelId === channel.id ? 'bg-primary/10 text-primary' : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
                                    )}
                                >
                                    <div className="flex items-center gap-2">
                                        {channel.type === 'private' ? <Lock className="w-3.5 h-3.5" /> : <Hash className="w-3.5 h-3.5" />}
                                        <span>{channel.name}</span>
                                    </div>
                                    {channel.unreadCount ? (
                                        <span className="bg-primary text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full">{channel.unreadCount}</span>
                                    ) : null}
                                </button>
                            ))}
                        </div>
                    </div>

                    <div>
                        <h3 className="px-3 text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Direct Messages</h3>
                        <div className="space-y-0.5">
                            {channels.filter(c => c.type === 'dm').map(channel => (
                                <button
                                    key={channel.id}
                                    onClick={() => setActiveChannelId(channel.id)}
                                    className={clsx(
                                        'w-full flex items-center gap-2 px-3 py-2 rounded-xl text-sm transition-all font-medium',
                                        activeChannelId === channel.id ? 'bg-primary/10 text-primary' : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
                                    )}
                                >
                                    <div className="w-2 h-2 rounded-full bg-green-500" />
                                    <span>{channel.name}</span>
                                </button>
                            ))}
                        </div>
                    </div>
                </div>
            </div>

            {/* Main Chat Area */}
            <div className="flex-1 flex flex-col min-w-0 bg-white">
                {/* Header */}
                <div className="h-16 border-b border-gray-200 flex items-center justify-between px-6 bg-white">
                    <div className="flex items-center gap-2">
                        {activeChannel?.type === 'private' ? <Lock className="w-4 h-4 text-gray-500" /> :
                            activeChannel?.type === 'public' ? <Hash className="w-4 h-4 text-gray-500" /> :
                                <div className="w-2 h-2 rounded-full bg-green-500" />}
                        <h2 className="font-bold text-gray-900">{activeChannel?.name}</h2>
                    </div>
                    <div className="flex items-center gap-4 text-gray-500">
                        <Phone className="w-5 h-5 hover:text-gray-900 cursor-pointer transition-colors" />
                        <Video className="w-5 h-5 hover:text-gray-900 cursor-pointer transition-colors" />
                        <div className="w-px h-5 bg-gray-200" />
                        <MoreVertical className="w-5 h-5 hover:text-gray-900 cursor-pointer transition-colors" />
                    </div>
                </div>

                {/* Messages */}
                <div className="flex-1 overflow-y-auto p-6 space-y-6">
                    {activeChannel?.messages.map((msg) => {
                        const isMe = msg.senderId === 'Me';
                        const sender = teamMembers.find(m => m.id === msg.senderId) || { name: 'Me', avatar: '#5A8FF6' };

                        return (
                            <div key={msg.id} className={clsx("flex gap-4 group", isMe && "flex-row-reverse")}>
                                <div
                                    className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-bold text-sm flex-shrink-0 shadow-sm"
                                    style={{ backgroundColor: sender.avatar }}
                                >
                                    {sender.name.substring(0, 2)}
                                </div>
                                <div className={clsx("flex flex-col max-w-[70%]", isMe && "items-end")}>
                                    <div className="flex items-baseline gap-2 mb-1">
                                        <span className="font-semibold text-gray-900 text-sm">{sender.name}</span>
                                        <span className="text-xs text-gray-400">{msg.timestamp}</span>
                                    </div>
                                    <div className={clsx(
                                        "p-3 rounded-2xl text-sm leading-relaxed",
                                        isMe ? "bg-primary text-white rounded-tr-sm shadow-sm" : "bg-gray-100 text-gray-900 rounded-tl-sm border border-gray-200"
                                    )}>
                                        {msg.content}
                                    </div>
                                </div>
                            </div>
                        );
                    })}
                </div>

                {/* Input */}
                <div className="p-4 border-t border-gray-200 bg-white">
                    <form onSubmit={handleSend} className="bg-gray-50 border border-gray-200 rounded-2xl p-3 focus-within:ring-2 focus-within:ring-primary/20 transition-all">
                        <input
                            type="text"
                            value={messageInput}
                            onChange={(e) => setMessageInput(e.target.value)}
                            placeholder={`Message #${activeChannel?.name}`}
                            className="w-full bg-transparent text-gray-900 placeholder-gray-400 px-2 py-2 outline-none"
                        />
                        <div className="flex items-center justify-between px-2 pt-3 border-t border-gray-200 mt-2">
                            <div className="flex items-center gap-2 text-gray-500">
                                <button type="button" className="p-1.5 hover:bg-gray-200 rounded-lg transition-colors"><Paperclip className="w-4 h-4" /></button>
                                <button type="button" className="p-1.5 hover:bg-gray-200 rounded-lg transition-colors"><Smile className="w-4 h-4" /></button>
                            </div>
                            <button
                                type="submit"
                                disabled={!messageInput.trim()}
                                className="p-2.5 bg-primary text-white rounded-xl disabled:opacity-50 disabled:cursor-not-allowed hover:bg-blue-600 transition-all shadow-sm hover:shadow-md"
                            >
                                <Send className="w-4 h-4" />
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
};
