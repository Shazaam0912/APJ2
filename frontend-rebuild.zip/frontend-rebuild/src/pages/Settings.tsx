import { useState } from 'react';
import { User, Bell, Shield, Palette, Globe } from 'lucide-react';
import clsx from 'clsx';

export const Settings = () => {
    const [activeTab, setActiveTab] = useState('profile');

    const tabs = [
        { id: 'profile', label: 'My Profile', icon: User },
        { id: 'notifications', label: 'Notifications', icon: Bell },
        { id: 'security', label: 'Security', icon: Shield },
        { id: 'appearance', label: 'Appearance', icon: Palette },
        { id: 'language', label: 'Language', icon: Globe },
    ];

    return (
        <div className="h-full flex flex-col max-w-6xl mx-auto bg-white">
            <h1 className="text-3xl font-bold text-gray-900 mb-8">Settings</h1>

            <div className="flex-1 flex gap-8">
                {/* Sidebar */}
                <div className="w-64 space-y-1">
                    {tabs.map((tab) => (
                        <button
                            key={tab.id}
                            onClick={() => setActiveTab(tab.id)}
                            className={clsx(
                                'w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all',
                                activeTab === tab.id
                                    ? 'bg-primary/10 text-primary shadow-sm'
                                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                            )}
                        >
                            <tab.icon className="w-5 h-5" />
                            {tab.label}
                        </button>
                    ))}
                </div>

                {/* Content */}
                <div className="flex-1 bg-white rounded-2xl border border-gray-200 p-8 shadow-sm">
                    {activeTab === 'profile' && (
                        <div className="space-y-8">
                            <div>
                                <h2 className="text-xl font-bold text-gray-900 mb-1">Public Profile</h2>
                                <p className="text-sm text-gray-500">Manage how you appear to other people.</p>
                            </div>

                            <div className="flex items-center gap-6">
                                <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-primary to-blue-600 flex items-center justify-center text-2xl font-bold text-white shadow-md">
                                    JD
                                </div>
                                <div className="space-y-2">
                                    <button className="bg-white hover:bg-gray-50 border-2 border-primary text-primary px-5 py-2.5 rounded-xl text-sm font-semibold transition-all shadow-sm hover:shadow-md">
                                        Upload New Picture
                                    </button>
                                    <p className="text-xs text-gray-500">JPG, GIF or PNG. Max size of 800K</p>
                                </div>
                            </div>

                            <div className="space-y-5">
                                <div className="grid grid-cols-2 gap-5">
                                    <div className="space-y-2">
                                        <label className="text-sm font-semibold text-gray-700">First Name</label>
                                        <input type="text" defaultValue="John" className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-gray-900 outline-none focus:border-primary focus:ring-2 focus:ring-primary/10 transition-all" />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-sm font-semibold text-gray-700">Last Name</label>
                                        <input type="text" defaultValue="Doe" className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-gray-900 outline-none focus:border-primary focus:ring-2 focus:ring-primary/10 transition-all" />
                                    </div>
                                </div>

                                <div className="space-y-2">
                                    <label className="text-sm font-semibold text-gray-700">Email Address</label>
                                    <input type="email" defaultValue="john@example.com" className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-gray-900 outline-none focus:border-primary focus:ring-2 focus:ring-primary/10 transition-all" />
                                </div>

                                <div className="space-y-2">
                                    <label className="text-sm font-semibold text-gray-700">Bio</label>
                                    <textarea defaultValue="Product Manager at Huly Clone." className="w-full h-32 bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-gray-900 outline-none focus:border-primary focus:ring-2 focus:ring-primary/10 resize-none transition-all" />
                                </div>
                            </div>

                            <div className="pt-6 border-t border-gray-200 flex justify-end">
                                <button className="bg-primary hover:bg-blue-600 text-white px-6 py-2.5 rounded-xl font-semibold transition-all shadow-sm hover:shadow-md">
                                    Save Changes
                                </button>
                            </div>
                        </div>
                    )}

                    {activeTab !== 'profile' && (
                        <div className="flex flex-col items-center justify-center h-full text-center space-y-4 py-20">
                            <div className="w-20 h-20 rounded-2xl bg-gray-100 flex items-center justify-center">
                                <Palette className="w-10 h-10 text-gray-400" />
                            </div>
                            <div>
                                <h3 className="text-xl font-bold text-gray-900">Coming Soon</h3>
                                <p className="text-gray-500 text-sm max-w-xs mx-auto mt-2">
                                    This section is currently under development. Check back later for updates.
                                </p>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};
