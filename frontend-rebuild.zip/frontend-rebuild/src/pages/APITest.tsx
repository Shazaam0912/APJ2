import { useState, useEffect } from 'react';
import { ProjectsAPI, TasksAPI } from '../services';
import type { Project, Task } from '../services';

export default function APITestPage() {
    const [projects, setProjects] = useState<Project[]>([]);
    const [tasks, setTasks] = useState<Task[]>([]);
    const [loading, setLoading] = useState(false);
    const [message, setMessage] = useState('');

    useEffect(() => {
        loadData();
    }, []);

    const loadData = async () => {
        try {
            setLoading(true);
            const [projectsData, tasksData] = await Promise.all([
                ProjectsAPI.getAll(),
                TasksAPI.getAll(),
            ]);
            setProjects(projectsData);
            setTasks(tasksData);
            setMessage('✅ Data loaded successfully!');
        } catch (error: any) {
            setMessage(`❌ Error: ${error.message}`);
        } finally {
            setLoading(false);
        }
    };

    const createTestProject = async () => {
        try {
            setLoading(true);
            const project = await ProjectsAPI.create({
                name: 'Test Project from Frontend',
                description: 'Created via React app',
                category: 'testing',
            });
            setMessage(`✅ Created project: ${project.name}`);
            loadData();
        } catch (error: any) {
            setMessage(`❌ Error: ${error.message}`);
        } finally {
            setLoading(false);
        }
    };

    const createTestTask = async () => {
        if (projects.length === 0) {
            setMessage('❌ Please create a project first');
            return;
        }

        try {
            setLoading(true);
            const task = await TasksAPI.create({
                content: 'Test task from frontend',
                description: 'Testing task creation',
                project_id: projects[0].id,
                priority: 'high',
            });
            setMessage(`✅ Created task: ${task.content}`);
            loadData();
        } catch (error: any) {
            setMessage(`❌ Error: ${error.message}`);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen bg-gray-50 p-8">
            <div className="max-w-6xl mx-auto">
                <div className="bg-white rounded-2xl shadow-lg p-8">
                    <h1 className="text-3xl font-bold text-gray-900 mb-2">API Test Dashboard</h1>
                    <p className="text-gray-600 mb-6">PostgreSQL Backend Integration</p>

                    {/* Message */}
                    {message && (
                        <div className={`mb-6 p-4 rounded-lg ${message.startsWith('✅') ? 'bg-green-50 text-green-800' : 'bg-red-50 text-red-800'}`}>
                            {message}
                        </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex gap-4 mb-8">
                        <button
                            onClick={loadData}
                            disabled={loading}
                            className="px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:opacity-50 font-medium"
                        >
                            {loading ? 'Loading...' : 'Refresh Data'}
                        </button>
                        <button
                            onClick={createTestProject}
                            disabled={loading}
                            className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50 font-medium"
                        >
                            Create Test Project
                        </button>
                        <button
                            onClick={createTestTask}
                            disabled={loading}
                            className="px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50 font-medium"
                        >
                            Create Test Task
                        </button>
                    </div>

                    {/* Data Display */}
                    <div className="grid md:grid-cols-2 gap-6">
                        {/* Projects */}
                        <div>
                            <h2 className="text-xl font-bold text-gray-900 mb-4">
                                Projects ({projects.length})
                            </h2>
                            <div className="space-y-3">
                                {projects.length === 0 ? (
                                    <p className="text-gray-500 italic">No projects yet</p>
                                ) : (
                                    projects.map((project) => (
                                        <div key={project.id} className="border border-gray-200 rounded-lg p-4 hover:border-indigo-300 transition">
                                            <div className="flex items-start justify-between">
                                                <div>
                                                    <h3 className="font-semibold text-gray-900">{project.name}</h3>
                                                    <p className="text-sm text-gray-600">{project.description}</p>
                                                    <div className="mt-2 flex gap-2">
                                                        <span className="px-2 py-1 bg-indigo-100 text-indigo-800 text-xs rounded">
                                                            {project.key}
                                                        </span>
                                                        <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded">
                                                            {project.status}
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                            <p className="text-xs text-gray-400 mt-2">ID: {project.id}</p>
                                        </div>
                                    ))
                                )}
                            </div>
                        </div>

                        {/* Tasks */}
                        <div>
                            <h2 className="text-xl font-bold text-gray-900 mb-4">
                                Tasks ({tasks.length})
                            </h2>
                            <div className="space-y-3">
                                {tasks.length === 0 ? (
                                    <p className="text-gray-500 italic">No tasks yet</p>
                                ) : (
                                    tasks.map((task) => (
                                        <div key={task.id} className="border border-gray-200 rounded-lg p-4 hover:border-purple-300 transition">
                                            <h3 className="font-semibold text-gray-900">{task.content}</h3>
                                            <p className="text-sm text-gray-600">{task.description}</p>
                                            <div className="mt-2 flex gap-2">
                                                <span className={`px-2 py-1 text-xs rounded ${task.priority === 'high' ? 'bg-red-100 text-red-800' :
                                                    task.priority === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                                                        'bg-gray-100 text-gray-800'
                                                    }`}>
                                                    {task.priority}
                                                </span>
                                                <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">
                                                    {task.status}
                                                </span>
                                            </div>
                                            <p className="text-xs text-gray-400 mt-2">ID: {task.id}</p>
                                        </div>
                                    ))
                                )}
                            </div>
                        </div>
                    </div>

                    {/* API Info */}
                    <div className="mt-8 p-4 bg-indigo-50 rounded-lg">
                        <h3 className="font-semibold text-indigo-900 mb-2">API Endpoints</h3>
                        <div className="text-sm text-indigo-800 space-y-1">
                            <p>• GET /projects - Fetch all projects</p>
                            <p>• POST /projects - Create new project</p>
                            <p>• GET /tasks - Fetch all tasks</p>
                            <p>• POST /tasks - Create new task</p>
                            <p>• Backend: http://localhost:8000</p>
                            <p>• Database: PostgreSQL (Neon)</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
