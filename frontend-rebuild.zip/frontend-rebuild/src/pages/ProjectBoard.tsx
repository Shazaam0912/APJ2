import { useState } from 'react';
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd';
import { Plus, MoreVertical, Edit2, Trash2, FolderKanban } from 'lucide-react';
import clsx from 'clsx';
import { useData, type Task } from '../context/DataContext';
import { Badge } from '../components/ui/Badge';
import { Dropdown, DropdownItem, DropdownSeparator } from '../components/ui/Dropdown';
import { FilterBar } from '../components/board/FilterBar';
import { BoardToolbar } from '../components/board/BoardToolbar';
import { TableView } from '../components/board/TableView';
import { EmptyState } from '../components/ui/EmptyState';
import { TaskDetailsPanel } from '../components/task/TaskDetailsPanel';
import { WipLimitIndicator } from '../components/board/WipLimitIndicator';
import { SwimlaneView } from '../components/board/SwimlaneView';
import { SprintPanel } from '../components/sprint/SprintPanel';
import { FilterModal, type FilterState } from '../components/modals/FilterModal';

interface FilterChip {
    id: string;
    label: string;
    value: string;
    type: string;
}


export const ProjectBoard = () => {
    const { data, moveTask, addTask, deleteTask, updateTask, tasks: contextTasks } = useData();
    const [showTaskModal, setShowTaskModal] = useState(false);
    const [selectedColumn, setSelectedColumn] = useState<string>('');
    const [taskForm, setTaskForm] = useState({ content: '', priority: 'medium' as 'low' | 'medium' | 'high', assignee: '', dueDate: '', description: '' });
    const [editingTask, setEditingTask] = useState<Task | null>(null);

    // New state for Phase 3
    const [filters, setFilters] = useState<FilterChip[]>([]);
    const [groupBy, setGroupBy] = useState<'none' | 'status' | 'assignee' | 'priority'>('status');

    // Phase 7B: Swimlane grouping
    const [swimlaneGroupBy, setSwimlaneGroupBy] = useState<'none' | 'assignee' | 'priority' | 'label'>('none');
    const [currentView, setCurrentView] = useState<'board' | 'list' | 'table' | 'sprint'>('board');

    // Filter Modal State
    const [showFilterModal, setShowFilterModal] = useState(false);
    const [activeFilters, setActiveFilters] = useState<FilterState>({
        priority: [],
        assignee: [],
        labels: [],
        status: [],
        dueDate: '',
    });

    // Task Details Panel
    const [selectedTask, setSelectedTask] = useState<Task | null>(null);
    const [showDetailsPanel, setShowDetailsPanel] = useState(false);

    const handleTaskClick = (task: Task) => {
        setSelectedTask(task);
        setShowDetailsPanel(true);
    };

    const handleAddTask = (columnId: string) => {
        setSelectedColumn(columnId);
        setTaskForm({ content: '', priority: 'medium', assignee: '', dueDate: '', description: '' });
        setEditingTask(null);
        setShowTaskModal(true);
    };

    const handleEditTask = (task: Task) => {
        setEditingTask(task);
        setTaskForm({
            content: task.content,
            priority: task.priority,
            assignee: task.assignee || '',
            dueDate: task.dueDate || '',
            description: task.description || ''
        });
        setShowTaskModal(true);
    };

    const handleSubmit = () => {
        if (taskForm.content.trim()) {
            if (editingTask) {
                updateTask(editingTask.id, taskForm);
            } else {
                addTask(selectedColumn, {
                    ...taskForm,
                    tags: []
                });
            }
            setShowTaskModal(false);
            setTaskForm({ content: '', priority: 'medium', assignee: '', dueDate: '', description: '' });
            setEditingTask(null);
        }
    };

    const getPriorityVariant = (priority: string) => {
        switch (priority) {
            case 'high': return 'destructive';
            case 'medium': return 'warning';
            default: return 'default';
        }
    };

    const handleRemoveFilter = (id: string) => {
        setFilters(filters.filter(f => f.id !== id));
    };

    const handleClearAllFilters = () => {
        setFilters([]);
    };

    const handleAddFilter = (type: string, value: string) => {
        const newFilter: FilterChip = {
            id: Date.now().toString(),
            label: type,
            value: value,
            type: type
        };
        setFilters([...filters, newFilter]);
    };

    const handleApplyFilters = (filters: FilterState) => {
        setActiveFilters(filters);
    };

    const activeFilterCount =
        activeFilters.priority.length +
        activeFilters.assignee.length +
        activeFilters.labels.length +
        activeFilters.status.length +
        (activeFilters.dueDate ? 1 : 0);

    const handleDragEnd = (result: any) => {
        const { destination, source, draggableId } = result;

        if (!destination) return;
        if (destination.droppableId === source.droppableId && destination.index === source.index) return;

        // Parse IDs (format: "laneId::columnId" or just "columnId")
        const sourceParts = source.droppableId.split('::');
        const destParts = destination.droppableId.split('::');

        const sourceColumnId = sourceParts.length > 1 ? sourceParts[1] : sourceParts[0];
        const destColumnId = destParts.length > 1 ? destParts[1] : destParts[0];

        // 1. Handle Column Change (Status)
        if (sourceColumnId !== destColumnId || source.index !== destination.index) {
            moveTask({
                ...result,
                source: { ...source, droppableId: sourceColumnId },
                destination: { ...destination, droppableId: destColumnId }
            });
        }

        // 2. Handle Swimlane Change (Property Update)
        if (swimlaneGroupBy !== 'none' && sourceParts.length > 1 && destParts.length > 1) {
            const sourceLaneId = sourceParts[0];
            const destLaneId = destParts[0];

            if (sourceLaneId !== destLaneId) {
                const updates: any = {};

                if (swimlaneGroupBy === 'assignee') {
                    updates.assignee = destLaneId === 'Unassigned' ? '' : destLaneId;
                } else if (swimlaneGroupBy === 'priority') {
                    updates.priority = destLaneId;
                } else if (swimlaneGroupBy === 'label') {
                    // Complex logic for labels (add new, remove old?), for now let's just add the new label
                    // Or maybe we shouldn't allow dragging between label lanes easily as tasks can have multiple labels
                    // For simplicity, let's skip label updates on drag for now or just add the target label
                    if (destLaneId !== 'No Labels') {
                        // We would need to fetch the task to know its current tags, 
                        // but we can't easily access it here without looking it up.
                        // Let's assume we can just add the tag.
                        // Actually, let's skip label updates for now to avoid complexity/bugs
                    }
                }

                if (Object.keys(updates).length > 0) {
                    // We need to call updateTask. 
                    // Since moveTask is async/state-based, we should probably wait or just fire and forget.
                    // But we don't have updateTask exposed from useData directly in the component props?
                    // We do, we extracted it from useData()
                    // Wait, we didn't extract updateTask in ProjectBoard. Let's add it.
                    // For now, I'll assume I will add it.
                    updateTask(draggableId, updates);
                }
            }
        }
    };

    // Get all tasks as a flat array for table/list views - use tasks from context directly
    const allTasks = contextTasks || [];

    // Filter tasks based on active filters
    const filteredTasks = allTasks.filter(task => {
        // Filter by Priority
        if (activeFilters.priority.length > 0 && !activeFilters.priority.map(p => p.toLowerCase()).includes(task.priority.toLowerCase())) {
            return false;
        }

        // Filter by Assignee
        if (activeFilters.assignee.length > 0 && (!task.assignee || !activeFilters.assignee.includes(task.assignee))) {
            return false;
        }

        // Filter by Status (Column)
        if (activeFilters.status.length > 0) {
            const column = data.columns[task.status];
            if (!column || !activeFilters.status.includes(column.title)) {
                return false;
            }
        }

        // Filter by Due Date
        if (activeFilters.dueDate) {
            if (!task.dueDate) return false;
            const taskDate = new Date(task.dueDate);
            const filterDate = new Date(activeFilters.dueDate);
            if (taskDate > filterDate) return false;
        }

        return true;
    });

    return (
        <div className="h-full flex flex-col bg-white">
            {/* Filter Bar */}
            <FilterBar
                filters={filters}
                onRemoveFilter={handleRemoveFilter}
                onClearAll={handleClearAllFilters}
                onAddFilter={handleAddFilter}
            />

            {/* Toolbar */}
            <BoardToolbar
                currentView={currentView}
                onViewChange={setCurrentView}
                groupBy={groupBy}
                onGroupByChange={setGroupBy}
                swimlaneGroupBy={swimlaneGroupBy}
                onSwimlaneGroupByChange={setSwimlaneGroupBy}
                onFilterClick={() => setShowFilterModal(true)}
                activeFilterCount={activeFilterCount}
            />

            {/* Views */}
            {currentView === 'sprint' ? (
                <SprintPanel onTaskClick={handleTaskClick} />
            ) : currentView === 'table' ? (
                <TableView tasks={filteredTasks.filter(task => !task.parentId)} />
            ) : currentView === 'list' ? (
                <div className="flex-1 overflow-auto p-6">
                    <div className="max-w-4xl mx-auto space-y-3">
                        {filteredTasks.map((task, index) => (
                            <div
                                key={task.id}
                                onClick={() => handleTaskClick(task)}
                                className="bg-white border border-gray-200 rounded-xl p-5 hover:border-primary/50 hover:shadow-lg transition-all cursor-pointer group hover-lift animate-slide-in-up"
                                style={{ animationDelay: `${index * 0.05} s` }}
                            >
                                <div className="flex items-start justify-between gap-4">
                                    <div className="flex-1 min-w-0">
                                        <h3 className="text-sm font-medium text-white mb-2 group-hover:text-primary transition-colors">{task.content}</h3>
                                        {task.description && (
                                            <p className="text-sm text-muted mb-3">{task.description}</p>
                                        )}
                                        <div className="flex items-center gap-3 flex-wrap">
                                            <Badge variant={getPriorityVariant(task.priority) as any}>
                                                {task.priority}
                                            </Badge>
                                            {task.assignee && (
                                                <div className="flex items-center gap-2">
                                                    <div className="w-5 h-5 rounded-full bg-primary flex items-center justify-center text-xs font-medium text-white">
                                                        {task.assignee}
                                                    </div>
                                                    <span className="text-xs text-muted">{task.assignee}</span>
                                                </div>
                                            )}
                                            {task.dueDate && (
                                                <span className="text-xs text-muted">Due: {task.dueDate}</span>
                                            )}
                                        </div>
                                    </div>
                                    <Dropdown
                                        trigger={
                                            <button className="p-2 hover:bg-hover rounded-lg transition-colors opacity-0 group-hover:opacity-100">
                                                <MoreVertical className="w-4 h-4 text-muted" />
                                            </button>
                                        }
                                        align="end"
                                    >
                                        <DropdownItem icon={<Edit2 className="w-4 h-4" />} onClick={() => handleEditTask(task)}>
                                            Edit
                                        </DropdownItem>
                                        <DropdownSeparator />
                                        <DropdownItem icon={<Trash2 className="w-4 h-4" />} variant="danger" onClick={() => deleteTask(task.id)}>
                                            Delete
                                        </DropdownItem>
                                    </Dropdown>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            ) : (
                <div className="flex-1 overflow-x-auto p-6">
                    {filteredTasks.length === 0 ? (
                        <EmptyState
                            icon={<FolderKanban className="w-8 h-8" />}
                            title="No tasks found"
                            description={allTasks.length === 0 ? "Get started by creating your first task." : "Try adjusting your filters to see more tasks."}
                            action={{
                                label: "Create Task",
                                onClick: () => handleAddTask(data.columnOrder[0])
                            }}
                        />
                    ) : swimlaneGroupBy !== 'none' ? (
                        // Swimlane View
                        <SwimlaneView
                            data={{ ...data, tasks: filteredTasks.reduce((acc, task) => ({ ...acc, [task.id]: task }), {}) }}
                            groupBy={swimlaneGroupBy}
                            onTaskClick={handleTaskClick}
                            onAddTask={handleAddTask}
                            onDragEnd={handleDragEnd}
                        />
                    ) : (
                        // Regular Column View
                        <DragDropContext onDragEnd={handleDragEnd}>
                            <div className="flex gap-6 h-full min-w-max">
                                {data?.columnOrder?.map((columnId) => {
                                    const column = data.columns?.[columnId];
                                    if (!column) return null;

                                    // Filter tasks for this column based on the global filteredTasks
                                    const tasks = (column.taskIds || [])
                                        .map((taskId) => data.tasks?.[taskId])
                                        .filter(task => task && !task.parentId && filteredTasks.find(ft => ft.id === task.id));

                                    return (
                                        <div key={column.id} className="flex flex-col w-80 bg-white border border-gray-100 rounded-xl">
                                            <div className="p-4 flex items-center justify-between">
                                                <div className="flex items-center gap-2 flex-1">
                                                    <h3 className="font-bold text-text">{column.title}</h3>
                                                    <span className="px-2 py-0.5 bg-white border border-gray-200 text-muted rounded-full text-xs font-medium shadow-sm">{tasks.length}</span>
                                                    <WipLimitIndicator
                                                        current={tasks.length}
                                                        limit={column.wipLimit}
                                                        showWarning={column.showWipWarning !== false}
                                                    />
                                                </div>
                                                <button
                                                    onClick={() => handleAddTask(column.id)}
                                                    className="p-1 hover:bg-gray-50 rounded-lg transition-colors text-muted hover:text-text border border-transparent hover:border-gray-100"
                                                >
                                                    <Plus className="w-5 h-5" />
                                                </button>
                                            </div>

                                            <Droppable droppableId={column.id}>
                                                {(provided, snapshot) => (
                                                    <div
                                                        ref={provided.innerRef}
                                                        {...provided.droppableProps}
                                                        className={clsx(
                                                            'flex-1 p-3 space-y-3 overflow-y-auto',
                                                            snapshot.isDraggingOver && 'bg-gray-50/50'
                                                        )}
                                                    >
                                                        {tasks.map((task, index) => (
                                                            <Draggable key={task.id} draggableId={task.id} index={index}>
                                                                {(provided, snapshot) => (
                                                                    <div
                                                                        ref={provided.innerRef}
                                                                        {...provided.draggableProps}
                                                                        {...provided.dragHandleProps}
                                                                        className={clsx(
                                                                            'bg-white border border-gray-200 rounded-xl p-4 cursor-pointer hover:shadow-md transition-all group',
                                                                            snapshot.isDragging && 'shadow-xl ring-2 ring-primary/20 rotate-2'
                                                                        )}
                                                                        onClick={() => handleTaskClick(task)}
                                                                    >
                                                                        <div className="flex items-start justify-between gap-2 mb-3">
                                                                            <h4 className="text-sm font-semibold text-text flex-1 leading-snug">{task.content}</h4>
                                                                            <Dropdown
                                                                                trigger={
                                                                                    <button className="p-1 hover:bg-gray-50 rounded transition-colors opacity-0 group-hover:opacity-100 text-muted border border-transparent hover:border-gray-100">
                                                                                        <MoreVertical className="w-4 h-4" />
                                                                                    </button>
                                                                                }
                                                                                align="end"
                                                                            >
                                                                                <DropdownItem icon={<Edit2 className="w-4 h-4" />} onClick={() => handleEditTask(task)}>
                                                                                    Edit
                                                                                </DropdownItem>
                                                                                <DropdownSeparator />
                                                                                <DropdownItem icon={<Trash2 className="w-4 h-4" />} variant="danger" onClick={() => deleteTask(task.id)}>
                                                                                    Delete
                                                                                </DropdownItem>
                                                                            </Dropdown>
                                                                        </div>

                                                                        {task.description && (
                                                                            <p className="text-xs text-muted mb-3 line-clamp-2">{task.description}</p>
                                                                        )}

                                                                        <div className="flex items-center gap-2 flex-wrap mb-3">
                                                                            <Badge variant={getPriorityVariant(task.priority) as any} className="capitalize">
                                                                                {task.priority}
                                                                            </Badge>
                                                                            {task.assignee && (
                                                                                <div className="w-6 h-6 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-[10px] font-bold text-white ring-2 ring-white">
                                                                                    {task.assignee}
                                                                                </div>
                                                                            )}
                                                                            {task.dueDate && (
                                                                                <span className="text-[10px] font-medium px-2 py-1 bg-white rounded text-muted border border-gray-200">
                                                                                    {task.dueDate}
                                                                                </span>
                                                                            )}
                                                                        </div>

                                                                        {/* Advanced Feature Indicators */}
                                                                        <div className="flex items-center gap-3 text-xs text-gray-400 pt-3 border-t border-gray-50">
                                                                            {/* Sub-tasks */}
                                                                            {task.subTasks.length > 0 && (
                                                                                <div className="flex items-center gap-1 hover:text-primary transition-colors" title={`${task.subTasks.length} sub - tasks`}>
                                                                                    <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                                                                                    </svg>
                                                                                    <span className="font-medium">{task.subTasks.length}</span>
                                                                                </div>
                                                                            )}

                                                                            {/* Comments */}
                                                                            {task.comments.length > 0 && (
                                                                                <div className="flex items-center gap-1 hover:text-primary transition-colors" title={`${task.comments.length} comments`}>
                                                                                    <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                                                                                    </svg>
                                                                                    <span className="font-medium">{task.comments.length}</span>
                                                                                </div>
                                                                            )}

                                                                            {/* Attachments */}
                                                                            {task.attachments.length > 0 && (
                                                                                <div className="flex items-center gap-1 hover:text-primary transition-colors" title={`${task.attachments.length} attachments`}>
                                                                                    <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" />
                                                                                    </svg>
                                                                                    <span className="font-medium">{task.attachments.length}</span>
                                                                                </div>
                                                                            )}

                                                                            {/* Time Logged */}
                                                                            {task.loggedHours > 0 && (
                                                                                <div className="flex items-center gap-1 hover:text-primary transition-colors" title={`${task.loggedHours}h logged`}>
                                                                                    <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                                                                                    </svg>
                                                                                    <span className="font-medium">{task.loggedHours}h</span>
                                                                                </div>
                                                                            )}

                                                                            {/* Dependencies Warning */}
                                                                            {task.blockedBy.length > 0 && (
                                                                                <div className="flex items-center gap-1 text-red-500 bg-red-50 px-1.5 py-0.5 rounded" title={`Blocked by ${task.blockedBy.length} task(s)`}>
                                                                                    <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                                                                                    </svg>
                                                                                    <span className="font-medium">{task.blockedBy.length}</span>
                                                                                </div>
                                                                            )}
                                                                        </div>
                                                                    </div>
                                                                )}
                                                            </Draggable>
                                                        ))}
                                                        {provided.placeholder}
                                                    </div>
                                                )}
                                            </Droppable>
                                        </div>
                                    );
                                })}
                            </div>
                        </DragDropContext>
                    )}
                </div>
            )}

            {/* Task Modal */}
            {
                showTaskModal && (
                    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={() => setShowTaskModal(false)}>
                        <div className="bg-white border border-gray-200 rounded-2xl p-8 w-full max-w-lg shadow-2xl" onClick={(e) => e.stopPropagation()}>
                            <h2 className="text-2xl font-bold text-gray-900 mb-6">{editingTask ? 'Edit Task' : 'Create New Task'}</h2>
                            <div className="space-y-4">
                                <div>
                                    <label className="block text-sm font-semibold text-gray-700 mb-2">Title</label>
                                    <input
                                        type="text"
                                        value={taskForm.content}
                                        onChange={(e) => setTaskForm({ ...taskForm, content: e.target.value })}
                                        className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-gray-900 focus:border-primary focus:ring-2 focus:ring-primary/10 outline-none transition-all"
                                        placeholder="Enter task title..."
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-semibold text-gray-700 mb-2">Description</label>
                                    <textarea
                                        value={taskForm.description}
                                        onChange={(e) => setTaskForm({ ...taskForm, description: e.target.value })}
                                        className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-gray-900 focus:border-primary focus:ring-2 focus:ring-primary/10 outline-none resize-none transition-all"
                                        rows={3}
                                        placeholder="Add description..."
                                    />
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <label className="block text-sm font-semibold text-gray-700 mb-2">Priority</label>
                                        <select
                                            value={taskForm.priority}
                                            onChange={(e) => setTaskForm({ ...taskForm, priority: e.target.value as 'low' | 'medium' | 'high' })}
                                            className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-gray-900 focus:border-primary focus:ring-2 focus:ring-primary/10 outline-none transition-all"
                                        >
                                            <option value="low">Low</option>
                                            <option value="medium">Medium</option>
                                            <option value="high">High</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label className="block text-sm font-semibold text-gray-700 mb-2">Assignee</label>
                                        <input
                                            type="text"
                                            value={taskForm.assignee}
                                            onChange={(e) => setTaskForm({ ...taskForm, assignee: e.target.value })}
                                            className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-gray-900 focus:border-primary focus:ring-2 focus:ring-primary/10 outline-none transition-all"
                                            placeholder="JD"
                                        />
                                    </div>
                                </div>
                                <div>
                                    <label className="block text-sm font-semibold text-gray-700 mb-2">Due Date</label>
                                    <input
                                        type="text"
                                        value={taskForm.dueDate}
                                        onChange={(e) => setTaskForm({ ...taskForm, dueDate: e.target.value })}
                                        className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-gray-900 focus:border-primary focus:ring-2 focus:ring-primary/10 outline-none transition-all"
                                        placeholder="Tomorrow"
                                    />
                                </div>
                            </div>
                            <div className="flex gap-3 mt-6">
                                <button onClick={handleSubmit} className="flex-1 bg-primary hover:bg-blue-600 text-white px-5 py-2.5 rounded-xl font-semibold transition-all shadow-sm hover:shadow-md">
                                    {editingTask ? 'Update Task' : 'Create Task'}
                                </button>
                                <button onClick={() => setShowTaskModal(false)} className="flex-1 bg-white hover:bg-gray-100 text-gray-700 px-5 py-2.5 rounded-xl font-semibold transition-all border-2 border-gray-200">
                                    Cancel
                                </button>
                            </div>
                        </div>
                    </div>
                )
            }

            {/* Task Details Panel */}
            {
                selectedTask && (
                    <TaskDetailsPanel
                        task={selectedTask}
                        isOpen={showDetailsPanel}
                        onClose={() => setShowDetailsPanel(false)}
                    />
                )
            }

            {/* Filter Modal */}
            <FilterModal
                isOpen={showFilterModal}
                onClose={() => setShowFilterModal(false)}
                onApplyFilters={handleApplyFilters}
                currentFilters={activeFilters}
            />
        </div >
    );
};

