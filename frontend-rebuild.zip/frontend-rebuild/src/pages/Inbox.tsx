import { useState } from 'react';
import { Bell, Check, Inbox as InboxIcon } from 'lucide-react';
import clsx from 'clsx';
import { useData } from '../context/DataContext';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';

export const Inbox = () => {
    const { notifications, markAsRead } = useData();
    const [filter, setFilter] = useState<'all' | 'unread'>('all');

    const filteredNotifications = notifications.filter(n => {
        if (filter === 'unread') return !n.read;
        return true;
    });

    return (
        <div className="h-full flex flex-col max-w-5xl mx-auto bg-white">
            <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-3">
                    <h1 className="text-3xl font-bold text-gray-900">Inbox</h1>
                    <Badge variant="secondary">{notifications.filter(n => !n.read).length} unread</Badge>
                </div>
                <div className="flex items-center gap-2">
                    <button
                        onClick={() => setFilter('all')}
                        className={clsx(
                            "px-4 py-2 rounded-xl text-sm font-semibold transition-all",
                            filter === 'all' ? "bg-primary text-white shadow-sm" : "bg-white text-gray-600 hover:bg-gray-100 border border-gray-200"
                        )}
                    >
                        All
                    </button>
                    <button
                        onClick={() => setFilter('unread')}
                        className={clsx(
                            "px-4 py-2 rounded-xl text-sm font-semibold transition-all",
                            filter === 'unread' ? "bg-primary text-white shadow-sm" : "bg-white text-gray-600 hover:bg-gray-100 border border-gray-200"
                        )}
                    >
                        Unread
                    </button>
                    <div className="w-px h-5 bg-gray-200 mx-2" />
                    <button className="p-2 hover:bg-gray-100 rounded-xl transition-colors text-gray-600">
                        <Check className="w-4 h-4" />
                    </button>
                </div>
            </div>

            <div className="space-y-3">
                {filteredNotifications.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-20 text-gray-400">
                        <InboxIcon className="w-16 h-16 mb-4 opacity-50" />
                        <p className="text-lg font-medium">You're all caught up!</p>
                    </div>
                ) : (
                    filteredNotifications.map(notification => (
                        <div
                            key={notification.id}
                            className={clsx(
                                "bg-white rounded-2xl border p-5 flex gap-4 transition-all hover:shadow-md cursor-pointer",
                                notification.read ? "border-gray-200 opacity-75" : "border-primary/30 shadow-sm ring-1 ring-primary/10"
                            )}
                        >
                            <div className={clsx(
                                "w-12 h-12 rounded-xl flex items-center justify-center shrink-0 shadow-sm",
                                notification.type === 'mention' ? "bg-blue-50 text-blue-600" :
                                    notification.type === 'assignment' ? "bg-green-50 text-green-600" :
                                        "bg-gray-100 text-gray-600"
                            )}>
                                <Bell className="w-5 h-5" />
                            </div>

                            <div className="flex-1 min-w-0">
                                <div className="flex items-start justify-between mb-1">
                                    <h3 className={clsx("font-semibold text-gray-900", !notification.read && "font-bold")}>
                                        {notification.title}
                                    </h3>
                                    <span className="text-xs text-gray-400 whitespace-nowrap ml-4">{notification.timestamp}</span>
                                </div>
                                <p className="text-sm text-gray-600 mb-3">{notification.message}</p>

                                {!notification.read && (
                                    <button
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            markAsRead(notification.id);
                                        }}
                                        className="px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg text-xs font-medium transition-colors"
                                    >
                                        Mark as read
                                    </button>
                                )}
                            </div>
                        </div>
                    ))
                )}
            </div>
        </div>
    );
};
