import { Mail, MoreHorizontal, Circle, Search, UserPlus, Filter } from 'lucide-react';
import { useData } from '../context/DataContext';

export const Team = () => {
    const { teamMembers } = useData();

    return (
        <div className="h-full flex flex-col bg-white">
            {/* Header Section */}
            <div className="mb-8">
                <div className="flex items-center justify-between mb-6">
                    <div>
                        <h1 className="text-3xl font-bold text-gray-900">Team Members</h1>
                        <p className="text-sm text-gray-500 mt-1">Manage and collaborate with your team</p>
                    </div>
                    <button className="flex items-center gap-2 bg-white hover:bg-gray-50 border-2 border-primary text-primary px-5 py-2.5 rounded-xl text-sm font-semibold transition-all shadow-sm hover:shadow-md">
                        <UserPlus className="w-4 h-4" />
                        Invite Member
                    </button>
                </div>

                {/* Search and Filter Bar */}
                <div className="flex items-center gap-3">
                    <div className="relative flex-1 max-w-md">
                        <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
                        <input
                            type="text"
                            placeholder="Search members..."
                            className="w-full bg-white border border-gray-200 rounded-xl pl-10 pr-4 py-2.5 text-sm text-gray-900 placeholder-gray-400 focus:border-primary focus:ring-2 focus:ring-primary/10 outline-none transition-all"
                        />
                    </div>
                    <button className="flex items-center gap-2 bg-white hover:bg-gray-50 border border-gray-200 text-gray-700 px-4 py-2.5 rounded-xl text-sm font-medium transition-all">
                        <Filter className="w-4 h-4" />
                        Filters
                    </button>
                </div>
            </div>

            {/* Team Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {teamMembers.map((member) => (
                    <div
                        key={member.id}
                        className="bg-white rounded-2xl border border-gray-200 p-5 hover:shadow-lg hover:border-gray-300 transition-all duration-200 group cursor-pointer"
                    >
                        <div className="flex items-start gap-4">
                            {/* Avatar */}
                            <div
                                className="w-14 h-14 rounded-xl flex items-center justify-center text-white text-lg font-bold shadow-sm ring-2 ring-white flex-shrink-0"
                                style={{ backgroundColor: member.avatar }}
                            >
                                {member.name.substring(0, 2)}
                            </div>

                            {/* Member Info */}
                            <div className="flex-1 min-w-0">
                                <div className="flex items-start justify-between mb-1">
                                    <div className="flex-1 min-w-0">
                                        <h3 className="font-bold text-gray-900 truncate text-base">{member.name}</h3>
                                        <p className="text-sm text-gray-500 mt-0.5">{member.role}</p>
                                    </div>
                                    <button className="text-gray-400 hover:text-gray-600 opacity-0 group-hover:opacity-100 transition-opacity p-1 hover:bg-gray-100 rounded-lg">
                                        <MoreHorizontal className="w-4 h-4" />
                                    </button>
                                </div>

                                {/* Status and Actions */}
                                <div className="flex items-center gap-3 mt-4">
                                    <div className="flex items-center gap-1.5 text-xs font-medium">
                                        <Circle
                                            className={`w-2 h-2 fill-current ${member.status === 'online' ? 'text-green-500' :
                                                member.status === 'busy' ? 'text-red-500' : 'text-gray-400'
                                                }`}
                                        />
                                        <span className={`capitalize ${member.status === 'online' ? 'text-green-600' :
                                            member.status === 'busy' ? 'text-red-600' : 'text-gray-500'
                                            }`}>
                                            {member.status}
                                        </span>
                                    </div>
                                    <div className="w-px h-3 bg-gray-200" />
                                    <a
                                        href={`mailto:${member.email}`}
                                        className="text-xs text-primary hover:text-blue-700 font-medium flex items-center gap-1 transition-colors"
                                    >
                                        <Mail className="w-3 h-3" />
                                        Email
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};
