import { useState } from 'react';
import { Users, Briefcase, FileText, Target, BarChart3, List as ListIcon, Calendar as CalendarIcon } from 'lucide-react';
import {
    StatsCard,
    TimelineView,
    SpreadsheetView,
    PerformanceChart,
    WorkloadDistribution,
    ActivityFeed,
    FocusWidget,
    ProjectHealth,
    MilestoneTracker,
    StatsDetailModal
} from '../components/dashboard';
import { useData } from '../context/DataContext';
import clsx from 'clsx';

type ViewMode = 'timeline' | 'spreadsheet' | 'analytics';

export const Dashboard = () => {
    const { data, projects } = useData();
    const [viewMode, setViewMode] = useState<ViewMode>('timeline');
    const [selectedStat, setSelectedStat] = useState<'employees' | 'projects' | 'tasks' | 'completion' | null>(null);

    // Calculate stats
    const allTasks = Object.values(data.tasks);
    const completedTasks = allTasks.filter(t => t.status === 'Done' || t.completed);
    // const activeTasks = allTasks.filter(t => !t.completed && !t.archived); // Unused
    const completionRate = allTasks.length > 0 ? ((completedTasks.length / allTasks.length) * 100).toFixed(1) : '0';

    const stats = [
        {
            title: 'Active Employees',
            value: '12',
            icon: <Users className="w-6 h-6" />,
            color: 'black' as const,
            onClick: () => setSelectedStat('employees')
        },
        {
            title: 'Active Projects',
            value: projects.length,
            icon: <Briefcase className="w-6 h-6" />,
            color: 'black' as const,
            onClick: () => setSelectedStat('projects')
        },
        {
            title: 'Total Tasks',
            value: allTasks.length,
            icon: <FileText className="w-6 h-6" />,
            color: 'black' as const,
            onClick: () => setSelectedStat('tasks')
        },
        {
            title: 'Completion Rate',
            value: `${completionRate}%`,
            icon: <Target className="w-6 h-6" />,
            color: 'black' as const,
            onClick: () => setSelectedStat('completion')
        },
    ];

    // Mock team members for now until we have real data in context
    const mockTeamMembers = [
        { id: '1', name: 'Sarah Johnson', status: 'online' },
        { id: '2', name: 'Mike Chen', status: 'busy' },
        { id: '3', name: 'Emma Davis', status: 'offline' },
        { id: '4', name: 'James Wilson', status: 'online' },
        { id: '5', name: 'Lisa Anderson', status: 'online' },
    ];

    return (
        <div className="h-full flex flex-col bg-white overflow-hidden">
            {/* Header */}
            <div className="p-6 pb-4 border-b border-gray-200">
                <div className="flex items-center justify-between mb-6">
                    <div>
                        <h1 className="text-3xl font-bold text-gray-900 mb-1">Welcome Back, David! 👋</h1>
                        <p className="text-gray-500">Stay on top of your tasks, monitor progress, and track status.</p>
                    </div>

                    {/* View Switcher */}
                    <div className="flex items-center gap-1 bg-gray-50 border border-gray-200 rounded-xl p-1 shadow-sm">
                        <button
                            onClick={() => setViewMode('timeline')}
                            className={clsx(
                                'flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-all',
                                viewMode === 'timeline' ? 'bg-primary text-white shadow-sm' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                            )}
                        >
                            <BarChart3 className="w-4 h-4" />
                            Timeline
                        </button>
                        <button
                            onClick={() => setViewMode('spreadsheet')}
                            className={clsx(
                                'flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-all',
                                viewMode === 'spreadsheet' ? 'bg-primary text-white shadow-sm' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                            )}
                        >
                            <ListIcon className="w-4 h-4" />
                            Spreadsheet
                        </button>
                        <button
                            onClick={() => setViewMode('analytics')}
                            className={clsx(
                                'flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-all',
                                viewMode === 'analytics' ? 'bg-primary text-white shadow-sm' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                            )}
                        >
                            <CalendarIcon className="w-4 h-4" />
                            Analytics
                        </button>
                    </div>
                </div>

                {/* Stats Cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    {stats.map((stat, i) => (
                        <StatsCard key={i} {...stat} />
                    ))}
                </div>
            </div>

            {/* Main Content Area */}
            <div className="flex-1 overflow-hidden">
                {viewMode === 'timeline' && <TimelineView />}
                {viewMode === 'spreadsheet' && <SpreadsheetView />}
                {viewMode === 'analytics' && (
                    <div className="h-full overflow-y-auto p-6">
                        <div className="grid grid-cols-12 gap-6 max-w-[1600px] mx-auto">
                            {/* Left Column - Charts & Analytics */}
                            <div className="col-span-8 space-y-6">
                                <ProjectHealth projects={projects} />
                                <PerformanceChart tasks={allTasks} />
                                <WorkloadDistribution tasks={allTasks} />
                            </div>

                            {/* Right Column - Activity & Focus */}
                            <div className="col-span-4 space-y-6">
                                <FocusWidget tasks={allTasks} />
                                <MilestoneTracker />
                                <ActivityFeed />
                            </div>
                        </div>
                    </div>
                )}
            </div>

            {/* Drill-down Modal */}
            <StatsDetailModal
                isOpen={!!selectedStat}
                onClose={() => setSelectedStat(null)}
                type={selectedStat}
                data={{
                    projects,
                    tasks: allTasks,
                    teamMembers: mockTeamMembers
                }}
            />
        </div>
    );
};
