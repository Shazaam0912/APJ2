import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';

// Advanced Task Management Interfaces
export interface TimeEntry {
    id: string;
    userId: string;
    userName: string;
    hours: number;
    date: string;
    description: string;
}

export interface Comment {
    id: string;
    userId: string;
    userName: string;
    userAvatar?: string;
    content: string;
    mentions: string[];
    createdAt: string;
    updatedAt?: string;
    edited: boolean;
}

export interface ActivityEntry {
    id: string;
    userId: string;
    userName: string;
    action: 'created' | 'updated' | 'commented' | 'moved' | 'assigned' | 'completed' | 'archived';
    field?: string;
    oldValue?: string;
    newValue?: string;
    timestamp: string;
}

export interface Attachment {
    id: string;
    name: string;
    size: number;
    type: string;
    url: string;
    uploadedBy: string;
    uploadedByName: string;
    uploadedAt: string;
}

export interface RecurrenceRule {
    frequency: 'daily' | 'weekly' | 'monthly';
    interval: number;
    endDate?: string;
    count?: number;
}

export interface TeamMember {
    id: string;
    name: string;
    initials?: string; // Made optional for flexibility
    email?: string;
    avatar?: string; // Made optional for flexibility
    role?: string;
    status?: 'online' | 'busy' | 'offline';
}

// Phase 7: Board Configuration
export interface BoardConfig {
    id: string;
    projectId: string;
    name: string;
    swimlaneGroupBy: 'none' | 'assignee' | 'priority' | 'label';
    showWipLimits: boolean;
    columnLimits: Record<string, number>; // columnId -> limit
    createdAt: string;
}

// Phase 7: Sprint Management
export interface Sprint {
    id: string;
    name: string;
    goal?: string;
    startDate: string;
    endDate: string;
    status: 'planning' | 'active' | 'completed';
    taskIds: string[];
    velocity?: number; // Story points completed
    capacity?: number; // Team capacity
}

// Phase 7: Saved Filters
export interface SavedFilter {
    id: string;
    name: string;
    icon?: string;
    criteria: {
        assignees?: string[];
        priorities?: string[];
        labels?: string[];
        dueDateRange?: { start: string; end: string };
        hasAttachments?: boolean;
        hasComments?: boolean;
    };
    isDefault?: boolean;
    createdBy: string;
}

// Phase 7: Board Template
export interface BoardTemplate {
    id: string;
    name: string;
    description: string;
    category: 'software' | 'marketing' | 'hr' | 'custom';
    columns: Array<{
        title: string;
        wipLimit?: number;
    }>;
    defaultLabels?: string[];
    defaultWorkflow?: string;
    icon?: string;
}

export interface Task {
    id: string;
    content: string;
    priority: 'low' | 'medium' | 'high';
    assignee?: string;
    dueDate?: string;
    description?: string;

    // Sub-tasks
    parentId?: string;
    subTasks: string[];

    // Dependencies
    blockedBy: string[];
    blocking: string[];

    // Time Tracking
    estimatedHours?: number;
    loggedHours: number;
    timeEntries: TimeEntry[];

    // Comments & Activity
    comments: Comment[];
    activityLog: ActivityEntry[];

    // Attachments
    attachments: Attachment[];

    // Custom Fields (extensible)
    customFields: Record<string, any>;

    // Metadata
    tags: string[];
    createdAt: string;
    updatedAt: string;
    createdBy: string;

    // Recurring
    isRecurring: boolean;
    recurrenceRule?: RecurrenceRule;

    // Phase 7: Sprint fields
    sprintId?: string;
    storyPoints?: number;
    isBacklog?: boolean;

    // Phase 7: Card covers
    coverImage?: string; // URL or color/gradient
    coverType?: 'image' | 'color' | 'gradient';
    templateId?: string;

    // Relations
    relatedTasks: string[];

    // Status
    completed: boolean;
    archived: boolean;
    status: string;
}

export interface Column {
    id: string;
    title: string;
    taskIds: string[];

    // Phase 7: WIP Limits
    wipLimit?: number;
    showWipWarning?: boolean;
}

export interface BoardData {
    tasks: Record<string, Task>;
    columns: Record<string, Column>;
    columnOrder: string[];
}

// Chat Types
export interface Message {
    id: string;
    senderId: string;
    content: string;
    timestamp: string;
    reactions: Record<string, number>;
    read?: boolean;
    relatedTaskId?: string;
    relatedProjectId?: string;
    type?: 'chat' | 'mention' | 'assignment' | 'comment';
}

export interface Channel {
    id: string;
    name: string;
    type: 'public' | 'private' | 'dm';
    messages: Message[];
    unreadCount?: number;
}

// Calendar Types
export interface CalendarEvent {
    id: string;
    title: string;
    start: string; // ISO string
    end: string;   // ISO string
    type: 'meeting' | 'deadline' | 'reminder';
    description?: string;
}

// Inbox Types
export interface Notification {
    id: string;
    title: string;
    message: string;
    type: 'mention' | 'assignment' | 'system' | 'chat' | 'comment';
    read: boolean;
    timestamp: string;
    relatedMessageId?: string;
    relatedTaskId?: string;
    relatedProjectId?: string;
    channelId?: string;
    actionUrl?: string; // For navigation
}

// Document Types
export interface Document {
    id: string;
    title: string;
    content: string;
    folderId?: string;
    updatedAt: string;
}

export interface Folder {
    id: string;
    name: string;
    parentId?: string;
}

// Phase 2: Project Management
export interface Project {
    id: string;
    name: string;
    key: string;
    description: string;
    boardData: BoardData;
    members: string[];
    createdAt: string;
    category?: string;
    template?: string;
}

export type ActivePage = 'dashboard' | 'projects' | 'inbox' | 'chat' | 'documents' | 'calendar' | 'team' | 'settings' | 'api-test';

interface DataContextType {
    // Project State
    projects: Project[];
    activeProjectId: string;
    createProject: (project: Omit<Project, 'id' | 'createdAt' | 'boardData' | 'members'>) => void;
    switchProject: (projectId: string) => void;

    data: BoardData;
    activePage: ActivePage;
    setActivePage: (page: ActivePage) => void;
    moveTask: (result: any) => void;
    addTask: (columnId: string, task: Omit<Task, 'id' | 'createdAt' | 'updatedAt' | 'createdBy' | 'subTasks' | 'blockedBy' | 'blocking' | 'loggedHours' | 'timeEntries' | 'comments' | 'activityLog' | 'attachments' | 'customFields' | 'relatedTasks' | 'completed' | 'archived' | 'status' | 'isRecurring'>) => void;
    updateTask: (taskId: string, updates: Partial<Task>) => void;
    deleteTask: (taskId: string) => void;
    addSubTask: (parentId: string, content: string) => void;
    toggleSubTask: (taskId: string) => void;
    addComment: (taskId: string, comment: Omit<Comment, 'id' | 'timestamp'>) => void;
    addTimeEntry: (taskId: string, entry: Omit<TimeEntry, 'id'>) => void;
    updateCustomField: (taskId: string, fieldName: string, value: any) => void;
    addDependency: (taskId: string, dependencyId: string) => void;
    removeDependency: (taskId: string, dependencyId: string) => void;
    addAttachment: (taskId: string, attachment: Omit<Attachment, 'id' | 'uploadedAt'>) => void;
    createRecurringTask: (task: Omit<Task, 'id' | 'createdAt' | 'updatedAt' | 'createdBy' | 'subTasks' | 'blockedBy' | 'blocking' | 'loggedHours' | 'timeEntries' | 'comments' | 'activityLog' | 'attachments' | 'customFields' | 'tags' | 'relatedTasks' | 'completed' | 'archived' | 'status'>, recurrence: RecurrenceRule) => void;

    // Chat
    channels: Channel[];
    activeChannelId: string;
    setActiveChannelId: (id: string) => void;
    addMessage: (channelId: string, content: string, metadata?: { relatedTaskId?: string; relatedProjectId?: string; type?: Message['type'] }) => void;
    markMessageAsRead: (channelId: string, messageId: string) => void;

    // Calendar
    events: CalendarEvent[];
    addEvent: (event: Omit<CalendarEvent, 'id'>) => void;
    updateEvent: (id: string, updates: Partial<CalendarEvent>) => void;
    deleteEvent: (id: string) => void;

    // Inbox
    notifications: Notification[];
    markAsRead: (notificationId: string) => void;
    markAllAsRead: () => void;

    // Documents
    documents: Document[];
    folders: Folder[];
    activeDocId: string | null;
    setActiveDocId: (id: string | null) => void;
    addDocument: (doc: Omit<Document, 'id' | 'updatedAt'>) => void;
    createDocument: (title: string, folderId?: string) => void;
    updateDocument: (id: string, updates: Partial<Document>) => void;

    // Team Members (Phase 4)
    teamMembers: TeamMember[];

    // Phase 7C: Sprint Management
    sprints: Sprint[];
    activeSprint: Sprint | null;
    createSprint: (sprint: Omit<Sprint, 'id'>) => void;
    startSprint: (sprintId: string) => void;
    completeSprint: (sprintId: string) => void;
    moveTaskToSprint: (taskId: string, sprintId: string | null) => void;
    moveTaskToBacklog: (taskId: string) => void;
    updateTaskStoryPoints: (taskId: string, points: number | undefined) => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

const initialData: BoardData = {
    tasks: {
        'task-1': {
            id: 'task-1',
            content: 'Partone Consultancy Website',
            priority: 'high',
            assignee: 'user-1',
            dueDate: 'March 21, 2025',
            status: 'col-1',
            description: 'New Homepage',
            subTasks: [],
            blockedBy: [],
            blocking: [],
            loggedHours: 0,
            timeEntries: [],
            comments: Array(13).fill({}),
            activityLog: [],
            attachments: [],
            customFields: { 'ID': 'WEB-21' },
            tags: ['Urgent'],
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            createdBy: 'JD',
            isRecurring: false,
            relatedTasks: [],
            completed: false,
            archived: false,
            storyPoints: 13
        },
        'task-2': {
            id: 'task-2',
            content: 'Design Wireframes - Homepage',
            priority: 'medium',
            assignee: 'user-2',
            dueDate: 'Jan 12, 2025',
            status: 'col-1',
            description: 'New Homepage',
            subTasks: [],
            blockedBy: [],
            blocking: [],
            loggedHours: 0,
            timeEntries: [],
            comments: Array(8).fill({}),
            activityLog: [],
            attachments: [],
            customFields: { 'ID': 'WEB-68' },
            tags: ['Medium'],
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            createdBy: 'JD',
            isRecurring: false,
            relatedTasks: [],
            completed: false,
            archived: false,
            storyPoints: 8
        },
        'task-3': {
            id: 'task-3',
            content: 'Modify Content for Homepage',
            priority: 'high',
            assignee: 'user-3',
            dueDate: 'May 23, 2025',
            status: 'col-2',
            description: 'New Homepage',
            subTasks: [],
            blockedBy: [],
            blocking: [],
            loggedHours: 0,
            timeEntries: [],
            comments: Array(16).fill({}),
            activityLog: [],
            attachments: [],
            customFields: { 'ID': 'WEB-28' },
            tags: ['Urgent'],
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            createdBy: 'JD',
            isRecurring: false,
            relatedTasks: [],
            completed: false,
            archived: false,
            storyPoints: 16
        },
        'task-4': {
            id: 'task-4',
            content: 'MTC Design Approval',
            priority: 'low',
            assignee: 'user-4',
            dueDate: 'March 10, 2025',
            status: 'col-3',
            description: 'New Homepage',
            subTasks: [],
            blockedBy: [],
            blocking: [],
            loggedHours: 0,
            timeEntries: [],
            comments: Array(10).fill({}),
            activityLog: [],
            attachments: [],
            customFields: { 'ID': 'WEB-12' },
            tags: ['Low'],
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            createdBy: 'JD',
            isRecurring: false,
            relatedTasks: [],
            completed: true,
            archived: false,
            storyPoints: 10
        },
        'task-5': {
            id: 'task-5',
            content: 'Nexa Components Revision',
            priority: 'medium',
            assignee: 'user-5',
            dueDate: 'March 29, 2025',
            status: 'col-3',
            description: 'UI - Design System',
            subTasks: [],
            blockedBy: [],
            blocking: [],
            loggedHours: 0,
            timeEntries: [],
            comments: Array(28).fill({}),
            activityLog: [],
            attachments: [],
            customFields: { 'ID': 'WEB-97' },
            tags: ['Medium'],
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            createdBy: 'JD',
            isRecurring: false,
            relatedTasks: [],
            completed: true,
            archived: false,
            storyPoints: 28
        },
        'task-6': {
            id: 'task-6',
            content: 'V0.1 Components Design System',
            priority: 'high',
            assignee: 'user-1',
            dueDate: 'March 20, 2025',
            status: 'col-4',
            description: 'Components & Elements',
            subTasks: [],
            blockedBy: [],
            blocking: [],
            loggedHours: 0,
            timeEntries: [],
            comments: Array(14).fill({}),
            activityLog: [],
            attachments: [],
            customFields: { 'ID': 'WEB-88' },
            tags: ['Urgent'],
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            createdBy: 'JD',
            isRecurring: false,
            relatedTasks: [],
            completed: false,
            archived: false,
            storyPoints: 14
        },
    },
    columns: {
        'col-1': { id: 'col-1', title: 'Not Started', taskIds: ['task-1', 'task-2'], wipLimit: 24 },
        'col-2': { id: 'col-2', title: 'Pending', taskIds: ['task-3'], wipLimit: 24 },
        'col-3': { id: 'col-3', title: 'Completed', taskIds: ['task-4', 'task-5'], wipLimit: 24 },
        'col-4': { id: 'col-4', title: 'Under Review', taskIds: ['task-6'], wipLimit: 24 },
    },
    columnOrder: ['col-1', 'col-2', 'col-3', 'col-4'],
};

const initialChannels: Channel[] = [
    {
        id: 'general',
        name: 'General',
        type: 'public',
        messages: [
            { id: 'm1', senderId: 'JD', content: 'Hey everyone! How is the new feature coming along?', timestamp: '10:00 AM', reactions: { '👍': 2 } },
            { id: 'm2', senderId: 'AS', content: 'Almost done, just fixing a few bugs.', timestamp: '10:05 AM', reactions: { '🚀': 1 } },
        ],
        unreadCount: 0
    },
    {
        id: 'design',
        name: 'Design Team',
        type: 'private',
        messages: [],
        unreadCount: 2
    },
    {
        id: 'dm-jd',
        name: 'John Doe',
        type: 'dm',
        messages: [],
        unreadCount: 0
    }
];

const initialEvents: CalendarEvent[] = [
    { id: 'e1', title: 'Team Standup', start: new Date().toISOString(), end: new Date(Date.now() + 3600000).toISOString(), type: 'meeting' },
    { id: 'e2', title: 'Project Deadline', start: new Date(Date.now() + 86400000).toISOString(), end: new Date(Date.now() + 86400000).toISOString(), type: 'deadline' },
];

const initialNotifications: Notification[] = [
    { id: 'n1', title: 'New Task Assigned', message: 'You have been assigned to "Design new landing page"', type: 'assignment', read: false, timestamp: '10 mins ago' },
    { id: 'n2', title: 'Mentioned in Chat', message: 'Alice mentioned you in #general', type: 'mention', read: false, timestamp: '1 hour ago' },
    { id: 'n3', title: 'System Update', message: 'The platform will be down for maintenance tonight.', type: 'system', read: true, timestamp: 'Yesterday' },
];

const initialDocs: Document[] = [
    { id: 'd1', title: 'Project Overview', content: '# Project Overview\n\nThis is the main documentation for our project.', updatedAt: '2 days ago' },
    { id: 'd2', title: 'API Reference', content: '# API Reference\n\nEndpoints and usage guide.', folderId: 'f1', updatedAt: '1 week ago' },
];

const initialFolders: Folder[] = [
    { id: 'f1', name: 'Technical Specs' },
];

// Team Members for @mentions and Team page
const mentionTeamMembers: TeamMember[] = [
    { id: 'JD', name: 'John Doe', initials: 'JD', role: 'Product Manager', avatar: '#5A8FF6', status: 'online', email: 'john@example.com' },
    { id: 'AS', name: 'Alice Smith', initials: 'AS', role: 'Frontend Dev', avatar: '#EF86AA', status: 'busy', email: 'alice@example.com' },
    { id: 'MK', name: 'Mike Kerr', initials: 'MK', role: 'Backend Dev', avatar: '#709A3F', status: 'offline', email: 'mike@example.com' },
    { id: 'user-1', name: 'John Doe', initials: 'JD', email: 'john@example.com' },
    { id: 'user-2', name: 'Alice Smith', initials: 'AS', email: 'alice@example.com' },
    { id: 'user-3', name: 'Bob Johnson', initials: 'BJ', email: 'bob@example.com' },
    { id: 'user-4', name: 'Carol White', initials: 'CW', email: 'carol@example.com' },
    { id: 'user-5', name: 'David Brown', initials: 'DB', email: 'david@example.com' },
];

export const DataProvider = ({ children }: { children: ReactNode }) => {
    // Initialize Projects (Migration from old boardData if needed)
    const [projects, setProjects] = useState<Project[]>(() => {
        const savedProjects = localStorage.getItem('projects');
        if (savedProjects) return JSON.parse(savedProjects);

        const savedBoard = localStorage.getItem('boardData');
        const initialBoard = savedBoard ? JSON.parse(savedBoard) : initialData;

        return [{
            id: 'proj-1',
            name: 'Website Redesign',
            key: 'WEB',
            description: 'Main website overhaul project',
            boardData: initialBoard,
            members: ['JD', 'AS', 'MK'],
            createdAt: new Date().toISOString(),
            category: 'software',
            template: 'kanban'
        }];
    });

    const [activeProjectId, setActiveProjectId] = useState<string>(() => {
        return localStorage.getItem('activeProjectId') || projects[0]?.id || 'proj-1';
    });

    // Initialize data from active project
    const [data, setData] = useState<BoardData>(() => {
        const project = projects.find(p => p.id === activeProjectId) || projects[0];
        return project.boardData;
    });

    // Sync data changes back to the active project in the projects list
    useEffect(() => {
        setProjects(prev => prev.map(p =>
            p.id === activeProjectId ? { ...p, boardData: data } : p
        ));
    }, [data]);

    // Persist projects and active ID
    useEffect(() => {
        localStorage.setItem('projects', JSON.stringify(projects));
        localStorage.setItem('activeProjectId', activeProjectId);
        // Also keep boardData synced for backward compatibility/safety
        localStorage.setItem('boardData', JSON.stringify(data));
    }, [projects, activeProjectId, data]);

    const createProject = (projectData: Omit<Project, 'id' | 'createdAt' | 'boardData' | 'members'>) => {
        const newProject: Project = {
            ...projectData,
            id: `proj-${Date.now()}`,
            createdAt: new Date().toISOString(),
            members: ['current-user'],
            boardData: initialData // Start with fresh template
        };
        setProjects(prev => [...prev, newProject]);
        switchProject(newProject.id);
    };

    const switchProject = (projectId: string) => {
        const project = projects.find(p => p.id === projectId);
        if (project) {
            setActiveProjectId(projectId);
            setData(project.boardData);
            setActivePage('dashboard');
        }
    };

    const [activePage, setActivePage] = useState<ActivePage>('dashboard');

    const [channels, setChannels] = useState<Channel[]>(initialChannels);
    const [activeChannelId, setActiveChannelId] = useState<string>(channels[0]?.id || '');

    // Calendar State
    const [events, setEvents] = useState<CalendarEvent[]>(initialEvents);

    // Inbox State
    const [notifications, setNotifications] = useState<Notification[]>(initialNotifications);

    const [documents, setDocuments] = useState<Document[]>(initialDocs);
    const [folders] = useState<Folder[]>(initialFolders);
    const [activeDocId, setActiveDocId] = useState<string | null>(null);

    // Task Actions
    const addTask = (columnId: string, taskData: Partial<Task>) => {
        const id = `task-${Date.now()}`;
        const now = new Date().toISOString();

        const newTask: Task = {
            id,
            content: taskData.content || '',
            priority: taskData.priority || 'medium',
            assignee: taskData.assignee,
            dueDate: taskData.dueDate,
            description: taskData.description,
            status: columnId,

            // Sub-tasks
            parentId: taskData.parentId,
            subTasks: [],

            // Dependencies
            blockedBy: [],
            blocking: [],

            // Time Tracking
            estimatedHours: taskData.estimatedHours,
            loggedHours: 0,
            timeEntries: [],

            // Comments & Activity
            comments: [],
            activityLog: [{
                id: `activity-${Date.now()}`,
                userId: taskData.createdBy || 'current-user',
                userName: taskData.createdBy || 'Current User',
                action: 'created',
                timestamp: now
            }],

            // Attachments
            attachments: [],

            // Custom Fields
            customFields: taskData.customFields || {},

            // Metadata
            tags: taskData.tags || [],
            createdAt: now,
            updatedAt: now,
            createdBy: taskData.createdBy || 'current-user',

            // Recurring
            isRecurring: false,
            recurrenceRule: taskData.recurrenceRule,
            templateId: taskData.templateId,

            // Relations
            relatedTasks: [],

            // Status
            completed: false,
            archived: false
        };
        setData((prev) => {
            const column = prev.columns[columnId];
            return {
                ...prev,
                tasks: { ...prev.tasks, [id]: newTask },
                columns: { ...prev.columns, [columnId]: { ...column, taskIds: [...column.taskIds, id] } },
            };
        });
    };

    const updateTask = (taskId: string, updates: Partial<Task>) => {
        setData((prev) => ({
            ...prev,
            tasks: {
                ...prev.tasks,
                [taskId]: {
                    ...prev.tasks[taskId],
                    ...updates,
                    updatedAt: new Date().toISOString()
                }
            }
        }));
    };

    const deleteTask = (id: string) => {
        setData((prev) => {
            const task = prev.tasks[id];
            const newTasks = { ...prev.tasks };
            delete newTasks[id];

            // Remove from parent's subTasks if it's a subtask
            if (task.parentId) {
                const parent = newTasks[task.parentId];
                if (parent) {
                    newTasks[task.parentId] = {
                        ...parent,
                        subTasks: parent.subTasks.filter(subId => subId !== id)
                    };
                }
            }

            const newColumns = { ...prev.columns };
            for (const colId in newColumns) {
                newColumns[colId].taskIds = newColumns[colId].taskIds.filter(taskId => taskId !== id);
            }
            return { ...prev, tasks: newTasks, columns: newColumns };
        });
    };

    const moveTask = (result: any) => {
        const { destination, source, draggableId } = result;
        if (!destination) return;
        if (destination.droppableId === source.droppableId && destination.index === source.index) return;

        const start = data.columns[source.droppableId];
        const finish = data.columns[destination.droppableId];

        if (start === finish) {
            const newTaskIds = Array.from(start.taskIds);
            newTaskIds.splice(source.index, 1);
            newTaskIds.splice(destination.index, 0, draggableId);
            const newColumn = { ...start, taskIds: newTaskIds };
            setData((prev) => ({ ...prev, columns: { ...prev.columns, [newColumn.id]: newColumn } }));
            return;
        }

        const startTaskIds = Array.from(start.taskIds);
        startTaskIds.splice(source.index, 1);
        const newStart = { ...start, taskIds: startTaskIds };

        const finishTaskIds = Array.from(finish.taskIds);
        finishTaskIds.splice(destination.index, 0, draggableId);
        const newFinish = { ...finish, taskIds: finishTaskIds };

        const updatedTask = { ...data.tasks[draggableId], status: finish.id };
        setData((prev) => ({
            ...prev,
            tasks: { ...prev.tasks, [draggableId]: updatedTask },
            columns: { ...prev.columns, [newStart.id]: newStart, [newFinish.id]: newFinish },
        }));
    };

    // Advanced Task Management Methods
    const addSubTask = (parentId: string, content: string) => {
        const parent = data.tasks[parentId];
        if (!parent) return;

        const subTaskId = `task-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
        const now = new Date().toISOString();

        const newSubTask: Task = {
            id: subTaskId,
            content: content,
            priority: parent.priority,
            status: parent.status,
            parentId: parentId,
            subTasks: [],
            blockedBy: [],
            blocking: [],
            loggedHours: 0,
            timeEntries: [],
            comments: [],
            activityLog: [{
                id: `activity-${Date.now()}`,
                userId: 'current-user',
                userName: 'Current User',
                action: 'created',
                timestamp: now
            }],
            attachments: [],
            customFields: {},
            tags: [],
            createdAt: now,
            updatedAt: now,
            createdBy: 'current-user',
            isRecurring: false,
            relatedTasks: [],
            completed: false,
            archived: false
        };

        setData({
            ...data,
            tasks: {
                ...data.tasks,
                [subTaskId]: newSubTask,
                [parentId]: {
                    ...parent,
                    subTasks: [...parent.subTasks, subTaskId]
                }
            }
            // Don't add to columns - sub-tasks only appear under parent
        });
    };

    const addComment = (taskId: string, commentData: Omit<Comment, 'id' | 'createdAt'>) => {
        const now = new Date().toISOString();
        setData((prev) => ({
            ...prev,
            tasks: {
                ...prev.tasks,
                [taskId]: {
                    ...prev.tasks[taskId],
                    comments: [...prev.tasks[taskId].comments, { ...commentData, id: `comment-${Date.now()}`, createdAt: now, edited: false }],
                    updatedAt: now
                }
            }
        }));
    };

    const logTime = (taskId: string, entryData: Omit<TimeEntry, 'id'>) => {
        setData((prev) => {
            const task = prev.tasks[taskId];
            return {
                ...prev,
                tasks: {
                    ...prev.tasks,
                    [taskId]: {
                        ...task,
                        timeEntries: [...task.timeEntries, { ...entryData, id: `time-${Date.now()}` }],
                        loggedHours: task.loggedHours + entryData.hours,
                        updatedAt: new Date().toISOString()
                    }
                }
            };
        });
    };

    const addAttachment = (taskId: string, fileData: Omit<Attachment, 'id' | 'uploadedAt'>) => {
        const now = new Date().toISOString();
        setData((prev) => ({
            ...prev,
            tasks: {
                ...prev.tasks,
                [taskId]: {
                    ...prev.tasks[taskId],
                    attachments: [...prev.tasks[taskId].attachments, { ...fileData, id: `attach-${Date.now()}`, uploadedAt: now }],
                    updatedAt: now
                }
            }
        }));
    };



    const updateCustomField = (taskId: string, fieldName: string, value: any) => {
        setData((prev) => ({
            ...prev,
            tasks: {
                ...prev.tasks,
                [taskId]: {
                    ...prev.tasks[taskId],
                    customFields: { ...prev.tasks[taskId].customFields, [fieldName]: value },
                    updatedAt: new Date().toISOString()
                }
            }
        }));
    };



    // Chat Actions
    const sendMessage = (channelId: string, content: string, metadata?: { relatedTaskId?: string; relatedProjectId?: string; type?: Message['type'] }) => {
        const messageId = `m-${Date.now()}`;
        const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

        // Add message to channel
        setChannels(prev => prev.map(ch => {
            if (ch.id === channelId) {
                return {
                    ...ch,
                    messages: [...ch.messages, {
                        id: messageId,
                        senderId: 'Me',
                        content,
                        timestamp,
                        reactions: {},
                        read: true, // own messages are read
                        ...metadata
                    }],
                    unreadCount: 0
                };
            }
            return ch;
        }));

        // Create notification if it's a mention or important message
        if (metadata?.type === 'mention' || metadata?.type === 'assignment') {
            setNotifications(prev => [{
                id: `notif-${Date.now()}`,
                title: metadata.type === 'mention' ? 'New mention' : 'New assignment',
                message: content.length > 50 ? content.substring(0, 50) + '...' : content,
                type: metadata.type as 'mention' | 'assignment',
                read: false,
                timestamp,
                relatedMessageId: messageId,
                channelId,
                relatedTaskId: metadata.relatedTaskId,
                relatedProjectId: metadata.relatedProjectId,
                actionUrl: `/chat?channel=${channelId}&message=${messageId}`
            }, ...prev]);
        }
    };

    const markMessageAsRead = (channelId: string, messageId: string) => {
        // Mark message as read
        setChannels(prev => prev.map(ch => {
            if (ch.id === channelId) {
                return {
                    ...ch,
                    messages: ch.messages.map(m => m.id === messageId ? { ...m, read: true } : m),
                    unreadCount: Math.max(0, (ch.unreadCount || 0) - 1)
                };
            }
            return ch;
        }));

        // Mark related notification as read
        setNotifications(prev => prev.map(n =>
            n.relatedMessageId === messageId ? { ...n, read: true } : n
        ));
    };

    // Calendar Actions
    const addEvent = (eventData: Omit<CalendarEvent, 'id'>) => {
        const newEvent: CalendarEvent = { ...eventData, id: `e-${Date.now()}` };
        setEvents(prev => [...prev, newEvent]);
    };

    const updateEvent = (id: string, updates: Partial<CalendarEvent>) => {
        setEvents(prev => prev.map(e => e.id === id ? { ...e, ...updates } : e));
    };

    const deleteEvent = (id: string) => {
        setEvents(prev => prev.filter(e => e.id !== id));
    };

    // Inbox Actions
    const markAsRead = (id: string) => {
        setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));

        // If notification has a related message, mark that as read too
        const notif = notifications.find(n => n.id === id);
        if (notif?.relatedMessageId && notif.channelId) {
            setChannels(prev => prev.map(ch => {
                if (ch.id === notif.channelId) {
                    return {
                        ...ch,
                        messages: ch.messages.map(m => m.id === notif.relatedMessageId ? { ...m, read: true } : m)
                    };
                }
                return ch;
            }));
        }
    };

    const markAllAsRead = () => {
        setNotifications(prev => prev.map(n => ({ ...n, read: true })));
    };

    // Document Actions
    const createDocument = (title: string, folderId?: string) => {
        const newDoc: Document = {
            id: `d-${Date.now()}`,
            title,
            content: '# New Document',
            folderId,
            updatedAt: 'Just now'
        };
        setDocuments(prev => [...prev, newDoc]);
    };

    const updateDocument = (id: string, updates: Partial<Document>) => {
        setDocuments(prev => prev.map(d => d.id === id ? { ...d, ...updates, updatedAt: 'Just now' } : d));
    };

    const addDocument = (doc: Omit<Document, 'id' | 'updatedAt'>) => {
        createDocument(doc.title, doc.folderId);
    };

    // Stub implementations for missing functions
    const toggleSubTask = (taskId: string) => {
        const now = new Date().toISOString();
        setData((prev) => ({
            ...prev,
            tasks: {
                ...prev.tasks,
                [taskId]: {
                    ...prev.tasks[taskId],
                    completed: !prev.tasks[taskId].completed,
                    updatedAt: now
                }
            }
        }));
    };

    const addDependency = (taskId: string, dependencyId: string) => {
        const now = new Date().toISOString();
        setData((prev) => ({
            ...prev,
            tasks: {
                ...prev.tasks,
                [taskId]: {
                    ...prev.tasks[taskId],
                    blockedBy: [...prev.tasks[taskId].blockedBy, dependencyId],
                    updatedAt: now
                }
            }
        }));
    };

    const removeDependency = (taskId: string, dependencyId: string) => {
        const now = new Date().toISOString();
        setData((prev) => ({
            ...prev,
            tasks: {
                ...prev.tasks,
                [taskId]: {
                    ...prev.tasks[taskId],
                    blockedBy: prev.tasks[taskId].blockedBy.filter(id => id !== dependencyId),
                    updatedAt: now
                }
            }
        }));
    };

    const createRecurringTask = (task: Omit<Task, 'id' | 'createdAt' | 'updatedAt' | 'createdBy' | 'subTasks' | 'blockedBy' | 'blocking' | 'loggedHours' | 'timeEntries' | 'comments' | 'activityLog' | 'attachments' | 'customFields' | 'tags' | 'relatedTasks' | 'completed' | 'archived' | 'status'>, recurrence: RecurrenceRule) => {
        // Implementation for recurring tasks would go here
        console.log('Creating recurring task:', task, recurrence);
    };

    // Sprint Management (Phase 7C)
    const [sprints, setSprints] = useState<Sprint[]>([]);

    // Compute active sprint
    const activeSprint = sprints.find(s => s.status === 'active') || null;

    const createSprint = (sprint: Omit<Sprint, 'id'>) => {
        const newSprint: Sprint = {
            ...sprint,
            id: `sprint-${Date.now()}`,
            taskIds: [],
            velocity: 0
        };
        setSprints(prev => [...prev, newSprint]);
    };

    const startSprint = (sprintId: string) => {
        setSprints(prev => prev.map(sprint => {
            // Only one sprint can be active at a time
            if (sprint.id === sprintId) {
                return { ...sprint, status: 'active' as const };
            }
            // Deactivate other sprints
            if (sprint.status === 'active') {
                return { ...sprint, status: 'planning' as const };
            }
            return sprint;
        }));
    };

    const completeSprint = (sprintId: string) => {
        setSprints(prev => prev.map(sprint => {
            if (sprint.id === sprintId) {
                // Calculate velocity (total story points of completed tasks)
                const sprintTasks = sprint.taskIds
                    .map(id => data.tasks[id])
                    .filter(Boolean);
                const completedPoints = sprintTasks
                    .filter(task => task.completed)
                    .reduce((sum, task) => sum + (task.storyPoints || 0), 0);

                return {
                    ...sprint,
                    status: 'completed' as const,
                    velocity: completedPoints
                };
            }
            return sprint;
        }));
    };

    const moveTaskToSprint = (taskId: string, sprintId: string | null) => {
        const now = new Date().toISOString();

        // Remove task from all sprints first
        setSprints(prev => prev.map(sprint => ({
            ...sprint,
            taskIds: sprint.taskIds.filter(id => id !== taskId)
        })));

        // Add to new sprint if specified
        if (sprintId) {
            setSprints(prev => prev.map(sprint => {
                if (sprint.id === sprintId) {
                    return {
                        ...sprint,
                        taskIds: [...sprint.taskIds, taskId]
                    };
                }
                return sprint;
            }));
        }

        // Update task
        setData(prev => ({
            ...prev,
            tasks: {
                ...prev.tasks,
                [taskId]: {
                    ...prev.tasks[taskId],
                    sprintId: sprintId || undefined,
                    isBacklog: !sprintId,
                    updatedAt: now
                }
            }
        }));
    };

    const moveTaskToBacklog = (taskId: string) => {
        moveTaskToSprint(taskId, null);
    };

    const updateTaskStoryPoints = (taskId: string, points: number | undefined) => {
        const now = new Date().toISOString();
        setData((prev) => ({
            ...prev,
            tasks: {
                ...prev.tasks,
                [taskId]: {
                    ...prev.tasks[taskId],
                    storyPoints: points,
                    updatedAt: now
                }
            }
        }));
    };

    return (
        <DataContext.Provider value={{
            projects,
            activeProjectId,
            createProject,
            switchProject,
            data,
            activePage,
            setActivePage,
            moveTask,
            addTask,
            updateTask,
            deleteTask,
            addSubTask,
            toggleSubTask,
            addComment,
            addTimeEntry: logTime,
            updateCustomField,
            addDependency,
            removeDependency,
            addAttachment,
            createRecurringTask,
            // Chat
            channels,
            activeChannelId,
            setActiveChannelId,
            addMessage: sendMessage,
            markMessageAsRead,

            // Calendar
            events,
            addEvent,
            updateEvent,
            deleteEvent,
            notifications,
            markAsRead,
            markAllAsRead,
            documents,
            folders,
            activeDocId,
            setActiveDocId,
            addDocument,
            createDocument,
            updateDocument,
            teamMembers: mentionTeamMembers,
            sprints,
            activeSprint,
            createSprint,
            startSprint,
            completeSprint,
            moveTaskToSprint,
            moveTaskToBacklog,
            updateTaskStoryPoints
        }}>
            {children}
        </DataContext.Provider>
    );
};

export const useData = () => {
    const context = useContext(DataContext);
    if (!context) throw new Error('useData must be used within a DataProvider');
    return context;
};
