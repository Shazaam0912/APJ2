import { formatDistanceToNow } from 'date-fns';

export const formatTimestamp = (timestamp: string | Date): string => {
    try {
        const date = typeof timestamp === 'string' ? new Date(timestamp) : timestamp;
        return formatDistanceToNow(date, { addSuffix: true });
    } catch {
        return 'Just now';
    }
};

export const formatDate = (date: string | Date | undefined): string => {
    if (!date) return 'No date set';

    try {
        const d = typeof date === 'string' ? new Date(date) : date;
        return d.toLocaleDateString('en-US', {
            month: 'short',
            day: 'numeric',
            year: 'numeric'
        });
    } catch {
        return 'Invalid date';
    }
};

export const formatDateTime = (timestamp: string | Date): string => {
    try {
        const date = typeof timestamp === 'string' ? new Date(timestamp) : timestamp;
        return date.toLocaleString('en-US', {
            month: 'short',
            day: 'numeric',
            hour: 'numeric',
            minute: '2-digit',
            hour12: true
        });
    } catch {
        return 'Just now';
    }
};
