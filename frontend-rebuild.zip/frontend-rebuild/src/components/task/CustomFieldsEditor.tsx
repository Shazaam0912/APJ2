import { useState } from 'react';
import { Plus, X, Type } from 'lucide-react';
import { useData, type Task } from '../../context/DataContext';

interface CustomFieldsEditorProps {
    task: Task;
}

type FieldType = 'text' | 'number' | 'date' | 'boolean';

export const CustomFieldsEditor = ({ task }: CustomFieldsEditorProps) => {
    const { updateCustomField } = useData();
    const [isAdding, setIsAdding] = useState(false);
    const [newFieldName, setNewFieldName] = useState('');
    const [newFieldType, setNewFieldType] = useState<FieldType>('text');
    const [newFieldValue, setNewFieldValue] = useState('');

    const handleAdd = () => {
        if (newFieldName.trim()) {
            let value: any = newFieldValue;

            if (newFieldType === 'number') value = parseFloat(newFieldValue) || 0;
            if (newFieldType === 'boolean') value = newFieldValue === 'true';

            updateCustomField(task.id, newFieldName, value);
            setNewFieldName('');
            setNewFieldValue('');
            setIsAdding(false);
        }
    };

    const renderFieldValue = (key: string, value: any) => {
        if (typeof value === 'boolean') {
            return (
                <div className="flex items-center gap-2">
                    <input
                        type="checkbox"
                        checked={value}
                        onChange={(e) => updateCustomField(task.id, key, e.target.checked)}
                        className="w-4 h-4 rounded border-border bg-background text-primary focus:ring-primary"
                    />
                    <span className="text-sm text-white">{value ? 'Yes' : 'No'}</span>
                </div>
            );
        }

        if (key.toLowerCase().includes('date')) {
            return (
                <input
                    type="date"
                    value={value}
                    onChange={(e) => updateCustomField(task.id, key, e.target.value)}
                    className="px-3 py-1 bg-background border border-border rounded text-white focus:outline-none focus:border-primary"
                />
            );
        }

        if (typeof value === 'number') {
            return (
                <input
                    type="number"
                    value={value}
                    onChange={(e) => updateCustomField(task.id, key, parseFloat(e.target.value) || 0)}
                    className="px-3 py-1 bg-background border border-border rounded text-white focus:outline-none focus:border-primary"
                />
            );
        }

        return (
            <input
                type="text"
                value={value}
                onChange={(e) => updateCustomField(task.id, key, e.target.value)}
                className="px-3 py-1 bg-background border border-border rounded text-white focus:outline-none focus:border-primary"
            />
        );
    };

    const customFieldEntries = Object.entries(task.customFields);

    return (
        <div className="space-y-4">
            {/* Existing Fields */}
            {customFieldEntries.length === 0 ? (
                <div className="text-center py-8 text-muted">
                    <Type className="w-12 h-12 mx-auto mb-2 opacity-50" />
                    <p>No custom fields yet</p>
                    <p className="text-xs mt-1">Add fields to extend task properties</p>
                </div>
            ) : (
                <div className="space-y-3">
                    {customFieldEntries.map(([key, value]) => (
                        <div key={key} className="flex items-center justify-between p-3 bg-background rounded-lg">
                            <div className="flex-1">
                                <label className="block text-sm font-medium text-muted mb-1">{key}</label>
                                {renderFieldValue(key, value)}
                            </div>
                            <button
                                onClick={() => updateCustomField(task.id, key, undefined)}
                                className="p-1 hover:bg-hover rounded transition-colors ml-2"
                                title="Remove field"
                            >
                                <X className="w-4 h-4 text-muted hover:text-red-400" />
                            </button>
                        </div>
                    ))}
                </div>
            )}

            {/* Add New Field */}
            {isAdding ? (
                <div className="p-4 bg-background rounded-lg space-y-3">
                    <div>
                        <label className="block text-sm font-medium text-muted mb-2">Field Name</label>
                        <input
                            type="text"
                            value={newFieldName}
                            onChange={(e) => setNewFieldName(e.target.value)}
                            placeholder="e.g., Client Name, Budget, Launch Date"
                            className="w-full px-3 py-2 bg-surface border border-border rounded-lg text-white placeholder-muted focus:outline-none focus:border-primary"
                            autoFocus
                        />
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-muted mb-2">Field Type</label>
                        <select
                            value={newFieldType}
                            onChange={(e) => setNewFieldType(e.target.value as FieldType)}
                            className="w-full px-3 py-2 bg-surface border border-border rounded-lg text-white focus:outline-none focus:border-primary"
                        >
                            <option value="text">Text</option>
                            <option value="number">Number</option>
                            <option value="date">Date</option>
                            <option value="boolean">Yes/No</option>
                        </select>
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-muted mb-2">Initial Value</label>
                        {newFieldType === 'boolean' ? (
                            <select
                                value={newFieldValue}
                                onChange={(e) => setNewFieldValue(e.target.value)}
                                className="w-full px-3 py-2 bg-surface border border-border rounded-lg text-white focus:outline-none focus:border-primary"
                            >
                                <option value="false">No</option>
                                <option value="true">Yes</option>
                            </select>
                        ) : (
                            <input
                                type={newFieldType === 'number' ? 'number' : newFieldType === 'date' ? 'date' : 'text'}
                                value={newFieldValue}
                                onChange={(e) => setNewFieldValue(e.target.value)}
                                placeholder={`Enter ${newFieldType} value`}
                                className="w-full px-3 py-2 bg-surface border border-border rounded-lg text-white placeholder-muted focus:outline-none focus:border-primary"
                            />
                        )}
                    </div>

                    <div className="flex gap-2">
                        <button
                            onClick={handleAdd}
                            disabled={!newFieldName.trim()}
                            className="flex-1 px-4 py-2 bg-primary hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-lg font-medium transition-colors"
                        >
                            Add Field
                        </button>
                        <button
                            onClick={() => {
                                setIsAdding(false);
                                setNewFieldName('');
                                setNewFieldValue('');
                            }}
                            className="px-4 py-2 bg-surface hover:bg-hover text-white rounded-lg transition-colors"
                        >
                            Cancel
                        </button>
                    </div>
                </div>
            ) : (
                <button
                    onClick={() => setIsAdding(true)}
                    className="w-full flex items-center justify-center gap-2 px-4 py-3 text-primary hover:bg-primary/10 rounded-lg transition-colors border-2 border-dashed border-border hover:border-primary"
                >
                    <Plus className="w-5 h-5" />
                    <span className="font-medium">Add Custom Field</span>
                </button>
            )}

            {/* Preset Templates */}
            <div className="p-3 bg-background/50 rounded-lg border border-border/50">
                <p className="text-xs text-muted mb-2">Quick Add:</p>
                <div className="flex flex-wrap gap-2">
                    {['Client Name', 'Budget', 'URL', 'Version'].map((preset) => (
                        <button
                            key={preset}
                            onClick={() => {
                                setNewFieldName(preset);
                                setNewFieldType('text');
                                setIsAdding(true);
                            }}
                            className="px-2 py-1 bg-surface hover:bg-hover text-xs text-muted hover:text-white rounded transition-colors"
                        >
                            + {preset}
                        </button>
                    ))}
                </div>
            </div>
        </div>
    );
};
