import { useState } from 'react';
import { Plus, Check } from 'lucide-react';
import { useData, type Task } from '../../context/DataContext';

interface SubTaskListProps {
    task: Task;
}

export const SubTaskList = ({ task }: SubTaskListProps) => {
    const { data, addSubTask } = useData();
    const [newSubTask, setNewSubTask] = useState('');
    const [isAdding, setIsAdding] = useState(false);

    const subTasks = task.subTasks.map((id) => data.tasks[id]).filter(Boolean);
    const completedCount = subTasks.filter((st) => st.completed).length;

    const handleAdd = () => {
        if (newSubTask.trim()) {
            addSubTask(task.id, {
                content: newSubTask,
                priority: task.priority,
                createdBy: 'current-user'
            });
            setNewSubTask('');
            setIsAdding(false);
        }
    };

    return (
        <div className="space-y-4">
            {/* Progress */}
            {subTasks.length > 0 && (
                <div>
                    <div className="flex items-center justify-between mb-2">
                        <span className="text-sm text-muted">Progress</span>
                        <span className="text-sm font-medium text-white">
                            {completedCount}/{subTasks.length} completed
                        </span>
                    </div>
                    <div className="h-2 bg-background rounded-full overflow-hidden">
                        <div
                            className="h-full bg-primary transition-all"
                            style={{ width: `${subTasks.length ? (completedCount / subTasks.length) * 100 : 0}%` }}
                        />
                    </div>
                </div>
            )}

            {/* Sub-task List */}
            <div className="space-y-2">
                {subTasks.map((subTask) => (
                    <div
                        key={subTask.id}
                        className="flex items-start gap-3 p-3 bg-background rounded-lg hover:bg-hover transition-colors"
                    >
                        <button
                            className={`mt-0.5 w-5 h-5 rounded border-2 flex items-center justify-center transition-colors ${subTask.completed
                                    ? 'bg-primary border-primary'
                                    : 'border-border hover:border-primary'
                                }`}
                        >
                            {subTask.completed && <Check className="w-3 h-3 text-white" />}
                        </button>
                        <div className="flex-1">
                            <p className={`text-sm ${subTask.completed ? 'line-through text-muted' : 'text-white'}`}>
                                {subTask.content}
                            </p>
                            {subTask.assignee && (
                                <p className="text-xs text-muted mt-1">Assigned to {subTask.assignee}</p>
                            )}
                        </div>
                    </div>
                ))}
            </div>

            {/* Add New */}
            {isAdding ? (
                <div className="flex gap-2">
                    <input
                        type="text"
                        value={newSubTask}
                        onChange={(e) => setNewSubTask(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleAdd()}
                        placeholder="Sub-task title..."
                        className="flex-1 px-3 py-2 bg-background border border-border rounded-lg text-white placeholder-muted focus:outline-none focus:border-primary"
                        autoFocus
                    />
                    <button
                        onClick={handleAdd}
                        className="px-4 py-2 bg-primary hover:bg-blue-600 text-white rounded-lg font-medium transition-colors"
                    >
                        Add
                    </button>
                    <button
                        onClick={() => {
                            setIsAdding(false);
                            setNewSubTask('');
                        }}
                        className="px-4 py-2 bg-background hover:bg-hover text-white rounded-lg transition-colors"
                    >
                        Cancel
                    </button>
                </div>
            ) : (
                <button
                    onClick={() => setIsAdding(true)}
                    className="flex items-center gap-2 px-4 py-2 text-primary hover:bg-primary/10 rounded-lg transition-colors"
                >
                    <Plus className="w-4 h-4" />
                    <span className="text-sm font-medium">Add Sub-task</span>
                </button>
            )}
        </div>
    );
};
