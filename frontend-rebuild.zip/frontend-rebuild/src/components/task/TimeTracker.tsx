import { useState } from 'react';
import { Plus, Clock } from 'lucide-react';
import { useData, type Task } from '../../context/DataContext';

interface TimeTrackerProps {
    task: Task;
}

export const TimeTracker = ({ task }: TimeTrackerProps) => {
    const { logTime } = useData();
    const [isLogging, setIsLogging] = useState(false);
    const [hours, setHours] = useState('');
    const [description, setDescription] = useState('');

    const handleLog = () => {
        const hoursNum = parseFloat(hours);
        if (hoursNum > 0 && description.trim()) {
            logTime(task.id, {
                userId: 'current-user',
                userName: 'Current User',
                hours: hoursNum,
                date: new Date().toISOString(),
                description
            });
            setHours('');
            setDescription('');
            setIsLogging(false);
        }
    };

    const progressPercentage = task.estimatedHours
        ? Math.min((task.loggedHours / task.estimatedHours) * 100, 100)
        : 0;

    return (
        <div className="space-y-6">
            {/* Summary */}
            <div className="grid grid-cols-3 gap-4">
                <div className="p-4 bg-background rounded-lg">
                    <p className="text-sm text-muted mb-1">Estimated</p>
                    <p className="text-2xl font-bold text-white">
                        {task.estimatedHours || 0}<span className="text-sm text-muted">h</span>
                    </p>
                </div>
                <div className="p-4 bg-background rounded-lg">
                    <p className="text-sm text-muted mb-1">Logged</p>
                    <p className="text-2xl font-bold text-primary">
                        {task.loggedHours}<span className="text-sm text-muted">h</span>
                    </p>
                </div>
                <div className="p-4 bg-background rounded-lg">
                    <p className="text-sm text-muted mb-1">Remaining</p>
                    <p className="text-2xl font-bold text-white">
                        {Math.max((task.estimatedHours || 0) - task.loggedHours, 0)}
                        <span className="text-sm text-muted">h</span>
                    </p>
                </div>
            </div>

            {/* Progress Bar */}
            {task.estimatedHours && (
                <div>
                    <div className="flex items-center justify-between mb-2">
                        <span className="text-sm text-muted">Progress</span>
                        <span className="text-sm font-medium text-white">{progressPercentage.toFixed(0)}%</span>
                    </div>
                    <div className="h-2 bg-background rounded-full overflow-hidden">
                        <div
                            className={`h-full transition-all ${task.loggedHours > (task.estimatedHours || 0) ? 'bg-red-500' : 'bg-primary'
                                }`}
                            style={{ width: `${progressPercentage}%` }}
                        />
                    </div>
                    {task.loggedHours > (task.estimatedHours || 0) && (
                        <p className="text-xs text-red-400 mt-1">Over estimate by {(task.loggedHours - (task.estimatedHours || 0)).toFixed(1)}h</p>
                    )}
                </div>
            )}

            {/* Time Entries */}
            <div className="space-y-2">
                <h3 className="text-sm font-medium text-white">Time Entries</h3>
                {task.timeEntries.length === 0 ? (
                    <div className="text-center py-8 text-muted">
                        <Clock className="w-12 h-12 mx-auto mb-2 opacity-50" />
                        <p>No time logged yet</p>
                    </div>
                ) : (
                    task.timeEntries.map((entry) => (
                        <div key={entry.id} className="flex justify-between items-start p-3 bg-background rounded-lg">
                            <div className="flex-1">
                                <p className="text-sm text-white font-medium">{entry.description}</p>
                                <p className="text-xs text-muted mt-1">
                                    {entry.userName} · {new Date(entry.date).toLocaleDateString()}
                                </p>
                            </div>
                            <span className="text-lg font-bold text-primary">{entry.hours}h</span>
                        </div>
                    ))
                )}
            </div>

            {/* Log Time */}
            {isLogging ? (
                <div className="space-y-3 p-4 bg-background rounded-lg">
                    <div>
                        <label className="block text-sm font-medium text-muted mb-2">Hours</label>
                        <input
                            type="number"
                            value={hours}
                            onChange={(e) => setHours(e.target.value)}
                            placeholder="0.0"
                            step="0.5"
                            min="0"
                            className="w-full px-3 py-2 bg-surface border border-border rounded-lg text-white placeholder-muted focus:outline-none focus:border-primary"
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-muted mb-2">Description</label>
                        <input
                            type="text"
                            value={description}
                            onChange={(e) => setDescription(e.target.value)}
                            placeholder="What did you work on?"
                            className="w-full px-3 py-2 bg-surface border border-border rounded-lg text-white placeholder-muted focus:outline-none focus:border-primary"
                        />
                    </div>
                    <div className="flex gap-2">
                        <button
                            onClick={handleLog}
                            className="flex-1 px-4 py-2 bg-primary hover:bg-blue-600 text-white rounded-lg font-medium transition-colors"
                        >
                            Log Time
                        </button>
                        <button
                            onClick={() => {
                                setIsLogging(false);
                                setHours('');
                                setDescription('');
                            }}
                            className="px-4 py-2 bg-surface hover:bg-hover text-white rounded-lg transition-colors"
                        >
                            Cancel
                        </button>
                    </div>
                </div>
            ) : (
                <button
                    onClick={() => setIsLogging(true)}
                    className="w-full flex items-center justify-center gap-2 px-4 py-3 text-primary hover:bg-primary/10 rounded-lg transition-colors border-2 border-dashed border-border hover:border-primary"
                >
                    <Plus className="w-5 h-5" />
                    <span className="font-medium">Log Time</span>
                </button>
            )}
        </div>
    );
};
