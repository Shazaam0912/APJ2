import { useState } from 'react';
import { AlertCircle, Link2 } from 'lucide-react';
import { useData, type Task } from '../../context/DataContext';

interface DependencyGraphProps {
    task: Task;
}

export const DependencyGraph = ({ task }: DependencyGraphProps) => {
    const { data, updateDependencies } = useData();
    const [isAdding, setIsAdding] = useState(false);
    const [selectedTaskId, setSelectedTaskId] = useState('');
    const [dependencyType, setDependencyType] = useState<'blocks' | 'blocked-by'>('blocks');

    const blockedByTasks = task.blockedBy.map((id) => data.tasks[id]).filter(Boolean);
    const blockingTasks = task.blocking.map((id) => data.tasks[id]).filter(Boolean);
    const availableTasks = Object.values(data.tasks).filter(
        (t) => t.id !== task.id && !task.blockedBy.includes(t.id) && !task.blocking.includes(t.id)
    );

    const handleAdd = () => {
        if (!selectedTaskId) return;

        const newBlockedBy = dependencyType === 'blocked-by'
            ? [...task.blockedBy, selectedTaskId]
            : task.blockedBy;
        const newBlocking = dependencyType === 'blocks'
            ? [...task.blocking, selectedTaskId]
            : task.blocking;

        updateDependencies(task.id, newBlockedBy, newBlocking);
        setIsAdding(false);
        setSelectedTaskId('');
    };

    return (
        <div className="space-y-6">
            {/* Blocked By */}
            <div>
                <h3 className="text-sm font-medium text-white mb-3 flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 text-red-400" />
                    Blocked By
                </h3>
                {blockedByTasks.length === 0 ? (
                    <p className="text-sm text-muted">This task is not blocked by any other tasks</p>
                ) : (
                    <div className="space-y-2">
                        {blockedByTasks.map((dep) => (
                            <div key={dep.id} className="flex items-center gap-3 p-3 bg-red-500/10 border border-red-500/20 rounded-lg">
                                <div className="w-2 h-2 rounded-full bg-red-400 flex-shrink-0" />
                                <div className="flex-1">
                                    <p className="text-sm text-white">{dep.content}</p>
                                    <p className="text-xs text-muted">Status: {data.columns[dep.status]?.title || 'Unknown'}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>

            {/* Blocking */}
            <div>
                <h3 className="text-sm font-medium text-white mb-3 flex items-center gap-2">
                    <Link2 className="w-4 h-4 text-yellow-400" />
                    Blocking
                </h3>
                {blockingTasks.length === 0 ? (
                    <p className="text-sm text-muted">This task is not blocking any other tasks</p>
                ) : (
                    <div className="space-y-2">
                        {blockingTasks.map((dep) => (
                            <div key={dep.id} className="flex items-center gap-3 p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
                                <div className="w-2 h-2 rounded-full bg-yellow-400 flex-shrink-0" />
                                <div className="flex-1">
                                    <p className="text-sm text-white">{dep.content}</p>
                                    <p className="text-xs text-muted">Status: {data.columns[dep.status]?.title || 'Unknown'}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>

            {/* Add Dependency */}
            {isAdding ? (
                <div className="p-4 bg-background rounded-lg space-y-3">
                    <div>
                        <label className="block text-sm font-medium text-muted mb-2">Dependency Type</label>
                        <select
                            value={dependencyType}
                            onChange={(e) => setDependencyType(e.target.value as 'blocks' | 'blocked-by')}
                            className="w-full px-3 py-2 bg-surface border border-border rounded-lg text-white focus:outline-none focus:border-primary"
                        >
                            <option value="blocked-by">This task is blocked by...</option>
                            <option value="blocks">This task blocks...</option>
                        </select>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-muted mb-2">Task</label>
                        <select
                            value={selectedTaskId}
                            onChange={(e) => setSelectedTaskId(e.target.value)}
                            className="w-full px-3 py-2 bg-surface border border-border rounded-lg text-white focus:outline-none focus:border-primary"
                        >
                            <option value="">Select a task...</option>
                            {availableTasks.map((t) => (
                                <option key={t.id} value={t.id}>
                                    {t.content}
                                </option>
                            ))}
                        </select>
                    </div>
                    <div className="flex gap-2">
                        <button
                            onClick={handleAdd}
                            disabled={!selectedTaskId}
                            className="flex-1 px-4 py-2 bg-primary hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-lg font-medium transition-colors"
                        >
                            Add Dependency
                        </button>
                        <button
                            onClick={() => {
                                setIsAdding(false);
                                setSelectedTaskId('');
                            }}
                            className="px-4 py-2 bg-surface hover:bg-hover text-white rounded-lg transition-colors"
                        >
                            Cancel
                        </button>
                    </div>
                </div>
            ) : (
                <button
                    onClick={() => setIsAdding(true)}
                    className="w-full px-4 py-3 text-primary hover:bg-primary/10 rounded-lg transition-colors border-2 border-dashed border-border hover:border-primary"
                >
                    Add Dependency
                </button>
            )}
        </div>
    );
};
