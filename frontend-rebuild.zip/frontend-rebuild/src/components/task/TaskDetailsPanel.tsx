import { useState } from 'react';
import { X, CheckSquare, MessageCircle, Clock, Paperclip, GitBranch, Activity } from 'lucide-react';
import clsx from 'clsx';
import { type Task } from '../../context/DataContext';
import { SubTaskList } from './SubTaskList';
import { CommentThread } from './CommentThread';
import { TimeTracker } from './TimeTracker';
import { AttachmentList } from './AttachmentList';
import { DependencyGraph } from './DependencyGraph';

interface TaskDetailsPanelProps {
    task: Task;
    isOpen: boolean;
    onClose: () => void;
}

type TabType = 'overview' | 'subtasks' | 'comments' | 'time' | 'attachments' | 'dependencies' | 'activity';

export const TaskDetailsPanel = ({ task, isOpen, onClose }: TaskDetailsPanelProps) => {
    const [activeTab, setActiveTab] = useState<TabType>('overview');

    const tabs = [
        { id: 'overview', label: 'Overview', icon: Activity },
        { id: 'subtasks', label: 'Sub-tasks', icon: CheckSquare, count: task.subTasks.length },
        { id: 'comments', label: 'Comments', icon: MessageCircle, count: task.comments.length },
        { id: 'time', label: 'Time', icon: Clock, badge: `${task.loggedHours}h` },
        { id: 'attachments', label: 'Files', icon: Paperclip, count: task.attachments.length },
        { id: 'dependencies', label: 'Dependencies', icon: GitBranch },
        { id: 'activity', label: 'Activity', icon: Activity, count: task.activityLog.length },
    ];

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black/50 z-50 flex justify-end" onClick={onClose}>
            <div
                className="w-full max-w-2xl bg-white border-l border-border flex flex-col h-full shadow-2xl"
                onClick={(e) => e.stopPropagation()}
            >
                {/* Header */}
                <div className="p-6 border-b border-border flex items-center justify-between bg-gray-50/50">
                    <div className="flex items-center gap-3">
                        <div className={clsx(
                            "w-3 h-3 rounded-full",
                            task.status === 'Done' ? 'bg-green-500' :
                                task.status === 'In Progress' ? 'bg-blue-500' : 'bg-gray-300'
                        )} />
                        <h2 className="text-xl font-bold text-gray-900">{task.content}</h2>
                    </div>
                    <button
                        onClick={onClose}
                        className="p-2 hover:bg-gray-100 rounded-lg transition-colors text-gray-500 hover:text-gray-700"
                    >
                        <X className="w-5 h-5" />
                    </button>
                </div>

                {/* Tabs */}
                <div className="flex gap-1 px-6 pt-4 border-b border-border overflow-x-auto bg-white">
                    {tabs.map((tab) => {
                        const Icon = tab.icon;
                        return (
                            <button
                                key={tab.id}
                                onClick={() => setActiveTab(tab.id as TabType)}
                                className={clsx(
                                    'flex items-center gap-2 px-4 py-3 rounded-t-lg transition-colors whitespace-nowrap border-b-2',
                                    activeTab === tab.id
                                        ? 'border-primary text-primary bg-primary/5'
                                        : 'border-transparent text-gray-500 hover:text-gray-700 hover:bg-gray-50'
                                )}
                            >
                                <Icon className="w-4 h-4" />
                                <span className="text-sm font-medium">{tab.label}</span>
                                {tab.count !== undefined && (
                                    <span className={clsx(
                                        "px-1.5 py-0.5 rounded text-xs",
                                        activeTab === tab.id ? "bg-primary/20 text-primary" : "bg-gray-100 text-gray-600"
                                    )}>{tab.count}</span>
                                )}
                                {tab.badge && (
                                    <span className="px-1.5 py-0.5 bg-blue-100 text-blue-700 rounded text-xs font-semibold">
                                        {tab.badge}
                                    </span>
                                )}
                            </button>
                        );
                    })}
                </div>

                {/* Content */}
                <div className="flex-1 overflow-y-auto p-6 bg-white">
                    {activeTab === 'overview' && (
                        <div className="space-y-8">
                            {/* Description Section */}
                            <div className="bg-gray-50 p-4 rounded-xl border border-gray-100">
                                <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Description</label>
                                <p className="text-gray-700 leading-relaxed">{task.description || 'No description provided.'}</p>
                            </div>

                            {/* Visual Widgets Grid */}
                            <div className="grid grid-cols-2 gap-4">
                                {/* Task Progress Widget */}
                                <div className="bg-white border border-gray-200 rounded-xl p-4 shadow-sm">
                                    <div className="flex items-center justify-between mb-4">
                                        <h3 className="text-sm font-semibold text-gray-900">Task Progress</h3>
                                        <span className="text-xs font-medium text-gray-500">{task.subTasks.length} subtasks</span>
                                    </div>
                                    <div className="flex items-center gap-4">
                                        <div className="relative w-16 h-16 flex-shrink-0">
                                            <svg className="w-full h-full transform -rotate-90">
                                                <circle cx="32" cy="32" r="28" stroke="#E5E7EB" strokeWidth="6" fill="transparent" />
                                                <circle
                                                    cx="32" cy="32" r="28" stroke="#3B82F6" strokeWidth="6" fill="transparent"
                                                    strokeDasharray={175}
                                                    strokeDashoffset={175 - (175 * (task.subTasks.length > 0 ? task.subTasks.filter(st => st.completed).length / task.subTasks.length : 0))}
                                                    strokeLinecap="round"
                                                />
                                            </svg>
                                            <div className="absolute inset-0 flex items-center justify-center text-xs font-bold text-gray-700">
                                                {task.subTasks.length > 0 ? Math.round((task.subTasks.filter(st => st.completed).length / task.subTasks.length) * 100) : 0}%
                                            </div>
                                        </div>
                                        <div>
                                            <p className="text-2xl font-bold text-gray-900">
                                                {task.subTasks.filter(st => st.completed).length}<span className="text-gray-400 text-lg">/{task.subTasks.length}</span>
                                            </p>
                                            <p className="text-xs text-gray-500">Subtasks completed</p>
                                        </div>
                                    </div>
                                </div>

                                {/* Time Tracking Widget */}
                                <div className="bg-white border border-gray-200 rounded-xl p-4 shadow-sm">
                                    <div className="flex items-center justify-between mb-4">
                                        <h3 className="text-sm font-semibold text-gray-900">Time Tracking</h3>
                                        <Clock className="w-4 h-4 text-gray-400" />
                                    </div>
                                    <div className="space-y-3">
                                        <div className="flex justify-between text-sm">
                                            <span className="text-gray-600">Logged</span>
                                            <span className="font-medium text-gray-900">{task.loggedHours || 0}h</span>
                                        </div>
                                        <div className="w-full bg-gray-100 rounded-full h-2 overflow-hidden">
                                            <div
                                                className="bg-purple-500 h-full rounded-full"
                                                style={{ width: `${Math.min(((task.loggedHours || 0) / (task.estimatedHours || 1)) * 100, 100)}%` }}
                                            />
                                        </div>
                                        <div className="flex justify-between text-xs text-gray-500">
                                            <span>Est: {task.estimatedHours || 0}h</span>
                                            <span>{task.estimatedHours ? Math.round(((task.loggedHours || 0) / task.estimatedHours) * 100) : 0}% used</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {/* Details Grid */}
                            <div className="grid grid-cols-2 gap-6 pt-4 border-t border-gray-100">
                                <div>
                                    <label className="block text-xs font-medium text-gray-500 mb-1.5">Priority</label>
                                    <span className={clsx(
                                        'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium',
                                        task.priority === 'high' && 'bg-red-50 text-red-700 border border-red-200',
                                        task.priority === 'medium' && 'bg-yellow-50 text-yellow-700 border border-yellow-200',
                                        task.priority === 'low' && 'bg-green-50 text-green-700 border border-green-200'
                                    )}>
                                        {task.priority.toUpperCase()}
                                    </span>
                                </div>

                                <div>
                                    <label className="block text-xs font-medium text-gray-500 mb-1.5">Assignee</label>
                                    <div className="flex items-center gap-2">
                                        <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center text-xs font-bold">
                                            {(task.assignee || 'U').charAt(0)}
                                        </div>
                                        <span className="text-sm text-gray-900">{task.assignee || 'Unassigned'}</span>
                                    </div>
                                </div>

                                <div>
                                    <label className="block text-xs font-medium text-gray-500 mb-1.5">Due Date</label>
                                    <p className="text-sm text-gray-900 font-medium">{task.dueDate || 'No due date'}</p>
                                </div>

                                <div>
                                    <label className="block text-xs font-medium text-gray-500 mb-1.5">Created</label>
                                    <p className="text-sm text-gray-900">{new Date(task.createdAt).toLocaleDateString()}</p>
                                </div>
                            </div>

                            {task.tags.length > 0 && (
                                <div className="pt-4 border-t border-gray-100">
                                    <label className="block text-xs font-medium text-gray-500 mb-2">Tags</label>
                                    <div className="flex flex-wrap gap-2">
                                        {task.tags.map((tag) => (
                                            <span key={tag} className="px-2.5 py-1 bg-gray-100 text-gray-700 rounded-md text-xs font-medium border border-gray-200">
                                                {tag}
                                            </span>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </div>
                    )}

                    {activeTab === 'subtasks' && <SubTaskList task={task} />}
                    {activeTab === 'comments' && <CommentThread task={task} />}
                    {activeTab === 'time' && <TimeTracker task={task} />}
                    {activeTab === 'attachments' && <AttachmentList task={task} />}
                    {activeTab === 'dependencies' && <DependencyGraph task={task} />}
                    {activeTab === 'activity' && (
                        <div className="space-y-4">
                            {task.activityLog.map((entry) => (
                                <div key={entry.id} className="flex gap-3 p-3 bg-gray-50 rounded-lg border border-gray-100">
                                    <div className="flex-1">
                                        <p className="text-sm text-gray-900">
                                            <span className="font-semibold">{entry.userName}</span>
                                            {' '}
                                            <span className="text-gray-600">{entry.action}</span>
                                            {entry.field && <span className="text-gray-600"> {entry.field}</span>}
                                        </p>
                                        {(entry.oldValue || entry.newValue) && (
                                            <p className="text-xs text-gray-500 mt-1 bg-white p-2 rounded border border-gray-100 inline-block">
                                                {entry.oldValue && <span className="line-through text-red-400 mr-2">{entry.oldValue}</span>}
                                                {entry.newValue && <span className="text-green-600 font-medium">{entry.newValue}</span>}
                                            </p>
                                        )}
                                        <p className="text-[10px] text-gray-400 mt-1.5 flex items-center gap-1">
                                            <Clock className="w-3 h-3" />
                                            {new Date(entry.timestamp).toLocaleString()}
                                        </p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};
