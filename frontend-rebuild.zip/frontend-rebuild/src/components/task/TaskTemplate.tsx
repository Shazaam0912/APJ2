import { useState } from 'react';
import { Save, Copy, Star } from 'lucide-react';
import { type Task } from '../../context/DataContext';

interface TaskTemplateProps {
    task: Task;
    onSaveAsTemplate?: () => void;
}

interface Template {
    id: string;
    name: string;
    description: string;
    priority: 'low' | 'medium' | 'high';
    estimatedHours?: number;
    tags: string[];
    customFields: Record<string, any>;
}

// Mock templates (in real app, these would come from context/API)
const mockTemplates: Template[] = [
    {
        id: 'bug-fix',
        name: 'Bug Fix',
        description: 'Standard bug fix template',
        priority: 'high',
        estimatedHours: 2,
        tags: ['bug', 'fix'],
        customFields: { 'Severity': 'Medium', 'Affected Version': '' }
    },
    {
        id: 'feature',
        name: 'New Feature',
        description: 'New feature development',
        priority: 'medium',
        estimatedHours: 8,
        tags: ['feature', 'development'],
        customFields: { 'Spec URL': '', 'Design URL': '' }
    },
    {
        id: 'research',
        name: 'Research Task',
        description: 'Investigation and research',
        priority: 'low',
        estimatedHours: 4,
        tags: ['research', 'analysis'],
        customFields: { 'Resources': '' }
    }
];

export const TaskTemplate = ({ task, onSaveAsTemplate }: TaskTemplateProps) => {
    const [isCreating, setIsCreating] = useState(false);
    const [templateName, setTemplateName] = useState('');
    const [templateDesc, setTemplateDesc] = useState('');

    const handleSaveTemplate = () => {
        if (templateName.trim()) {
            // In real app, this would save to context/API
            console.log('Saving template:', {
                name: templateName,
                description: templateDesc,
                task: task
            });
            setIsCreating(false);
            setTemplateName('');
            setTemplateDesc('');
            onSaveAsTemplate?.();
        }
    };

    const handleApplyTemplate = (template: Template) => {
        // In real app, this would update the task with template values
        console.log('Applying template:', template);
    };

    return (
        <div className="space-y-6">
            {/* Save Current as Template */}
            <div>
                <h3 className="text-sm font-medium text-white mb-3 flex items-center gap-2">
                    <Save className="w-4 h-4 text-primary" />
                    Save as Template
                </h3>

                {isCreating ? (
                    <div className="p-4 bg-background rounded-lg space-y-3">
                        <div>
                            <label className="block text-sm font-medium text-muted mb-2">Template Name</label>
                            <input
                                type="text"
                                value={templateName}
                                onChange={(e) => setTemplateName(e.target.value)}
                                placeholder="e.g., Sprint Planning Task"
                                className="w-full px-3 py-2 bg-surface border border-border rounded-lg text-white placeholder-muted focus:outline-none focus:border-primary"
                                autoFocus
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-muted mb-2">Description (optional)</label>
                            <textarea
                                value={templateDesc}
                                onChange={(e) => setTemplateDesc(e.target.value)}
                                placeholder="Describe when to use this template..."
                                className="w-full px-3 py-2 bg-surface border border-border rounded-lg text-white placeholder-muted focus:outline-none focus:border-primary resize-none"
                                rows={2}
                            />
                        </div>
                        <div className="flex gap-2">
                            <button
                                onClick={handleSaveTemplate}
                                disabled={!templateName.trim()}
                                className="flex-1 px-4 py-2 bg-primary hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-lg font-medium transition-colors"
                            >
                                Save Template
                            </button>
                            <button
                                onClick={() => {
                                    setIsCreating(false);
                                    setTemplateName('');
                                    setTemplateDesc('');
                                }}
                                className="px-4 py-2 bg-surface hover:bg-hover text-white rounded-lg transition-colors"
                            >
                                Cancel
                            </button>
                        </div>
                    </div>
                ) : (
                    <button
                        onClick={() => setIsCreating(true)}
                        className="w-full px-4 py-3 text-primary hover:bg-primary/10 rounded-lg transition-colors border-2 border-dashed border-border hover:border-primary"
                    >
                        Save current task as template
                    </button>
                )}
            </div>

            {/* Available Templates */}
            <div>
                <h3 className="text-sm font-medium text-white mb-3 flex items-center gap-2">
                    <Star className="w-4 h-4 text-yellow-400" />
                    Available Templates
                </h3>

                <div className="space-y-2">
                    {mockTemplates.map((template) => (
                        <div
                            key={template.id}
                            className="p-4 bg-background rounded-lg hover:bg-hover transition-colors group"
                        >
                            <div className="flex items-start justify-between mb-2">
                                <div className="flex-1">
                                    <h4 className="text-sm font-medium text-white">{template.name}</h4>
                                    <p className="text-xs text-muted mt-1">{template.description}</p>
                                </div>
                                <button
                                    onClick={() => handleApplyTemplate(template)}
                                    className="opacity-0 group-hover:opacity-100 px-3 py-1 bg-primary hover:bg-blue-600 text-white text-xs rounded transition-all"
                                >
                                    <Copy className="w-3 h-3 inline mr-1" />
                                    Apply
                                </button>
                            </div>

                            <div className="flex flex-wrap gap-2 mt-3">
                                <span className={`px-2 py-0.5 rounded-full text-xs ${template.priority === 'high' ? 'bg-red-500/20 text-red-400' :
                                        template.priority === 'medium' ? 'bg-yellow-500/20 text-yellow-400' :
                                            'bg-green-500/20 text-green-400'
                                    }`}>
                                    {template.priority}
                                </span>
                                {template.estimatedHours && (
                                    <span className="px-2 py-0.5 bg-primary/20 text-primary rounded-full text-xs">
                                        {template.estimatedHours}h
                                    </span>
                                )}
                                {template.tags.map((tag) => (
                                    <span key={tag} className="px-2 py-0.5 bg-surface text-muted rounded-full text-xs">
                                        {tag}
                                    </span>
                                ))}
                            </div>

                            {Object.keys(template.customFields).length > 0 && (
                                <div className="mt-2 pt-2 border-t border-border/50">
                                    <p className="text-xs text-muted">
                                        Includes {Object.keys(template.customFields).length} custom field{Object.keys(template.customFields).length !== 1 ? 's' : ''}
                                    </p>
                                </div>
                            )}
                        </div>
                    ))}
                </div>
            </div>

            <div className="p-3 bg-background/50 rounded-lg border border-border/50">
                <p className="text-xs text-muted">
                    💡 Templates help you quickly create tasks with pre-filled fields, tags, and custom properties.
                </p>
            </div>
        </div>
    );
};
