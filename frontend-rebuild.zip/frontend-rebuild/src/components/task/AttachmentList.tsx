import { Upload, FileText, Image, File, Download, Trash2 } from 'lucide-react';
import { useData, type Task } from '../../context/DataContext';

interface AttachmentListProps {
    task: Task;
}

export const AttachmentList = ({ task }: AttachmentListProps) => {
    const { addAttachment } = useData();

    const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
        const files = e.target.files;
        if (!files) return;

        // Simulate file upload (in real app, this would upload to server)
        Array.from(files).forEach((file) => {
            addAttachment(task.id, {
                name: file.name,
                size: file.size,
                type: file.type,
                url: URL.createObjectURL(file), // Mock URL
                uploadedBy: 'current-user',
                uploadedByName: 'Current User'
            });
        });
    };

    const getFileIcon = (type: string) => {
        if (type.startsWith('image/')) return Image;
        if (type.includes('pdf')) return FileText;
        return File;
    };

    const formatFileSize = (bytes: number) => {
        if (bytes < 1024) return `${bytes} B`;
        if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
        return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
    };

    return (
        <div className="space-y-4">
            {/* Upload Area */}
            <div className="border-2 border-dashed border-border rounded-lg p-8 text-center hover:border-primary transition-colors">
                <input
                    type="file"
                    id="file-upload"
                    multiple
                    className="hidden"
                    onChange={handleFileSelect}
                />
                <label
                    htmlFor="file-upload"
                    className="cursor-pointer flex flex-col items-center gap-2"
                >
                    <Upload className="w-12 h-12 text-muted" />
                    <p className="text-sm text-white font-medium">Click to upload files</p>
                    <p className="text-xs text-muted">or drag and drop</p>
                    <p className="text-xs text-muted mt-2">Note: Files are simulated (not actually uploaded)</p>
                </label>
            </div>

            {/* Attachments List */}
            <div className="space-y-2">
                {task.attachments.length === 0 ? (
                    <div className="text-center py-8 text-muted">
                        <FileText className="w-12 h-12 mx-auto mb-2 opacity-50" />
                        <p>No attachments yet</p>
                    </div>
                ) : (
                    task.attachments.map((attachment) => {
                        const Icon = getFileIcon(attachment.type);
                        return (
                            <div
                                key={attachment.id}
                                className="flex items-center gap-3 p-3 bg-background rounded-lg hover:bg-hover transition-colors group"
                            >
                                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                                    <Icon className="w-5 h-5 text-primary" />
                                </div>
                                <div className="flex-1 min-w-0">
                                    <p className="text-sm font-medium text-white truncate">{attachment.name}</p>
                                    <p className="text-xs text-muted">
                                        {formatFileSize(attachment.size)} · Uploaded by {attachment.uploadedByName}
                                        {' · '}
                                        {new Date(attachment.uploadedAt).toLocaleDateString()}
                                    </p>
                                </div>
                                <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                    <button
                                        className="p-2 hover:bg-surface rounded-lg transition-colors"
                                        title="Download"
                                    >
                                        <Download className="w-4 h-4 text-muted hover:text-white" />
                                    </button>
                                    <button
                                        className="p-2 hover:bg-surface rounded-lg transition-colors"
                                        title="Delete"
                                    >
                                        <Trash2 className="w-4 h-4 text-muted hover:text-red-400" />
                                    </button>
                                </div>
                            </div>
                        );
                    })
                )}
            </div>
        </div>
    );
};
