import { useState, useRef } from 'react';
import { Send } from 'lucide-react';
import { useData, type Task } from '../../context/DataContext';
import { MentionAutocomplete } from '../ui/MentionAutocomplete';

interface CommentThreadProps {
    task: Task;
}

export const CommentThread = ({ task }: CommentThreadProps) => {
    const { addComment, teamMembers } = useData();
    const [newComment, setNewComment] = useState('');
    const [cursorPosition, setCursorPosition] = useState(0);
    const [showMentions, setShowMentions] = useState(false);
    const textareaRef = useRef<HTMLTextAreaElement>(null);

    const handleCommentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
        const value = e.target.value;
        const cursor = e.target.selectionStart;

        setNewComment(value);
        setCursorPosition(cursor);

        // Check if we should show mentions autocomplete
        const textBeforeCursor = value.substring(0, cursor);
        const mentionMatch = textBeforeCursor.match(/@(\w*)$/);
        setShowMentions(!!mentionMatch);
    };

    const handleMentionSelect = (member: typeof teamMembers[0]) => {
        if (!textareaRef.current) return;

        const cursor = cursorPosition;
        const textBeforeCursor = newComment.substring(0, cursor);
        const textAfterCursor = newComment.substring(cursor);

        // Find the @ symbol position
        const mentionMatch = textBeforeCursor.match(/@(\w*)$/);
        if (!mentionMatch) return;

        const mentionStart = cursor - mentionMatch[0].length;
        const beforeMention = newComment.substring(0, mentionStart);
        const mention = `@${member.name}`;
        const updatedText = beforeMention + mention + ' ' + textAfterCursor;

        setNewComment(updatedText);
        setShowMentions(false);

        // Set cursor after the mention
        setTimeout(() => {
            if (textareaRef.current) {
                const newCursorPos = mentionStart + mention.length + 1;
                textareaRef.current.setSelectionRange(newCursorPos, newCursorPos);
                textareaRef.current.focus();
            }
        }, 0);
    };

    const extractMentions = (text: string): string[] => {
        const mentions: string[] = [];
        const mentionRegex = /@([\w\s]+?)(?=\s|$|@)/g;
        let match;

        while ((match = mentionRegex.exec(text)) !== null) {
            mentions.push(match[1]);
        }

        return mentions;
    };

    const handleSubmit = () => {
        if (!newComment.trim()) return;

        const mentions = extractMentions(newComment);

        addComment(task.id, {
            userId: 'current-user',
            userName: 'Current User',
            content: newComment,
            mentions,
            edited: false
        });

        setNewComment('');
        setShowMentions(false);
    };

    const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
        if (e.key === 'Enter' && !e.shiftKey && !showMentions) {
            e.preventDefault();
            handleSubmit();
        }
    };

    const renderCommentWithMentions = (content: string, mentions: string[]) => {
        if (mentions.length === 0) return content;

        let result = content;
        mentions.forEach(mention => {
            const mentionRegex = new RegExp(`@${mention}(?=\\s|$)`, 'g');
            result = result.replace(
                mentionRegex,
                `<span class="mention bg-primary/20 text-primary px-1 rounded">@${mention}</span>`
            );
        });

        return <span dangerouslySetInnerHTML={{ __html: result }} />;
    };

    return (
        <div className="space-y-4">
            {/* Comment List */}
            <div className="space-y-4">
                {task.comments.length === 0 ? (
                    <div className="text-center py-8 text-muted">
                        <p>No comments yet. Start the conversation!</p>
                    </div>
                ) : (
                    task.comments.map((comment) => (
                        <div key={comment.id} className="flex gap-3">
                            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-sm font-medium text-white flex-shrink-0">
                                {comment.userName.split(' ').map(n => n[0]).join('')}
                            </div>
                            <div className="flex-1">
                                <div className="flex items-baseline gap-2 mb-1">
                                    <span className="font-medium text-sm">{comment.userName}</span>
                                    <span className="text-xs text-muted">
                                        {new Date(comment.createdAt).toLocaleString()}
                                    </span>
                                </div>
                                <div className="text-sm text-muted-foreground">
                                    {renderCommentWithMentions(comment.content, comment.mentions)}
                                </div>
                            </div>
                        </div>
                    ))
                )}
            </div>


            {/* New Comment Input with Mention Autocomplete */}
            <div className="mt-4 bg-background rounded-lg border border-border p-4">
                <div className="relative">
                    {showMentions && (
                        <MentionAutocomplete
                            value={newComment}
                            cursorPosition={cursorPosition}
                            teamMembers={teamMembers}
                            onSelect={handleMentionSelect}
                            onClose={() => setShowMentions(false)}
                        />
                    )}
                    <div className="flex gap-3">
                        <textarea
                            ref={textareaRef}
                            value={newComment}
                            onChange={handleCommentChange}
                            onKeyDown={handleKeyDown}
                            placeholder="Write a comment... Type @ to mention someone"
                            className="flex-1 px-4 py-3 bg-surface border border-border rounded-lg text-sm text-white placeholder-muted resize-none focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all"
                            rows={3}
                        />
                        <button
                            onClick={handleSubmit}
                            disabled={!newComment.trim()}
                            className="px-6 py-3 bg-primary text-white rounded-lg hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center h-fit"
                        >
                            <Send className="w-5 h-5" />
                        </button>
                    </div>
                    <div className="flex items-center gap-4 mt-3 text-xs text-muted">
                        <span className="flex items-center gap-1">
                            <kbd className="px-2 py-1 bg-surface border border-border rounded">Enter</kbd>
                            Send
                        </span>
                        <span className="flex items-center gap-1">
                            <kbd className="px-2 py-1 bg-surface border border-border rounded">Shift+Enter</kbd>
                            New line
                        </span>
                        <span className="flex items-center gap-1">
                            <kbd className="px-2 py-1 bg-surface border border-border rounded">@</kbd>
                            Mention
                        </span>
                    </div>
                </div>
            </div>
        </div>
    );
};
