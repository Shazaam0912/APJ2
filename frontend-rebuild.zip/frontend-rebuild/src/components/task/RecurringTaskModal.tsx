import { useState } from 'react';
import { X, Repeat, Calendar, AlertCircle } from 'lucide-react';

interface RecurringTaskModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (rule: RecurrenceRule) => void;
}

interface RecurrenceRule {
    frequency: 'daily' | 'weekly' | 'monthly';
    interval: number;
    endDate?: string;
    count?: number;
}

export const RecurringTaskModal = ({ isOpen, onClose, onSave }: RecurringTaskModalProps) => {
    const [frequency, setFrequency] = useState<'daily' | 'weekly' | 'monthly'>('weekly');
    const [interval, setInterval] = useState(1);
    const [endType, setEndType] = useState<'never' | 'date' | 'count'>('never');
    const [endDate, setEndDate] = useState('');
    const [count, setCount] = useState(10);

    const handleSave = () => {
        const rule: RecurrenceRule = {
            frequency,
            interval,
            ...(endType === 'date' && { endDate }),
            ...(endType === 'count' && { count })
        };
        onSave(rule);
        onClose();
    };

    const getPreviewText = () => {
        const intervalText = interval === 1 ? '' : `every ${interval} `;
        const frequencyText = frequency === 'daily' ? 'day' : frequency === 'weekly' ? 'week' : 'month';
        const pluralText = interval > 1 ? 's' : '';

        let preview = `Repeats ${intervalText}${frequencyText}${pluralText}`;

        if (endType === 'date' && endDate) {
            preview += ` until ${new Date(endDate).toLocaleDateString()}`;
        } else if (endType === 'count') {
            preview += ` for ${count} occurrence${count !== 1 ? 's' : ''}`;
        }

        return preview;
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={onClose}>
            <div
                className="w-full max-w-md bg-surface border border-border rounded-xl"
                onClick={(e) => e.stopPropagation()}
            >
                {/* Header */}
                <div className="p-6 border-b border-border flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                            <Repeat className="w-5 h-5 text-primary" />
                        </div>
                        <div>
                            <h2 className="text-lg font-bold text-white">Recurring Task</h2>
                            <p className="text-xs text-muted">Set up automatic task creation</p>
                        </div>
                    </div>
                    <button
                        onClick={onClose}
                        className="p-2 hover:bg-hover rounded-lg transition-colors"
                    >
                        <X className="w-5 h-5 text-muted" />
                    </button>
                </div>

                {/* Content */}
                <div className="p-6 space-y-4">
                    {/* Frequency */}
                    <div>
                        <label className="block text-sm font-medium text-muted mb-2">Frequency</label>
                        <select
                            value={frequency}
                            onChange={(e) => setFrequency(e.target.value as 'daily' | 'weekly' | 'monthly')}
                            className="w-full px-3 py-2 bg-background border border-border rounded-lg text-white focus:outline-none focus:border-primary"
                        >
                            <option value="daily">Daily</option>
                            <option value="weekly">Weekly</option>
                            <option value="monthly">Monthly</option>
                        </select>
                    </div>

                    {/* Interval */}
                    <div>
                        <label className="block text-sm font-medium text-muted mb-2">
                            Every
                        </label>
                        <div className="flex items-center gap-2">
                            <input
                                type="number"
                                min="1"
                                max="365"
                                value={interval}
                                onChange={(e) => setInterval(parseInt(e.target.value) || 1)}
                                className="w-20 px-3 py-2 bg-background border border-border rounded-lg text-white focus:outline-none focus:border-primary"
                            />
                            <span className="text-sm text-muted">
                                {frequency === 'daily' ? 'day(s)' : frequency === 'weekly' ? 'week(s)' : 'month(s)'}
                            </span>
                        </div>
                    </div>

                    {/* End Type */}
                    <div>
                        <label className="block text-sm font-medium text-muted mb-2">Ends</label>
                        <div className="space-y-2">
                            <label className="flex items-center gap-2 cursor-pointer">
                                <input
                                    type="radio"
                                    name="endType"
                                    value="never"
                                    checked={endType === 'never'}
                                    onChange={(e) => setEndType(e.target.value as any)}
                                    className="w-4 h-4 text-primary"
                                />
                                <span className="text-sm text-white">Never</span>
                            </label>

                            <label className="flex items-center gap-2 cursor-pointer">
                                <input
                                    type="radio"
                                    name="endType"
                                    value="date"
                                    checked={endType === 'date'}
                                    onChange={(e) => setEndType(e.target.value as any)}
                                    className="w-4 h-4 text-primary"
                                />
                                <span className="text-sm text-white">On date</span>
                            </label>
                            {endType === 'date' && (
                                <input
                                    type="date"
                                    value={endDate}
                                    onChange={(e) => setEndDate(e.target.value)}
                                    className="w-full ml-6 px-3 py-2 bg-background border border-border rounded-lg text-white focus:outline-none focus:border-primary"
                                />
                            )}

                            <label className="flex items-center gap-2 cursor-pointer">
                                <input
                                    type="radio"
                                    name="endType"
                                    value="count"
                                    checked={endType === 'count'}
                                    onChange={(e) => setEndType(e.target.value as any)}
                                    className="w-4 h-4 text-primary"
                                />
                                <span className="text-sm text-white">After</span>
                            </label>
                            {endType === 'count' && (
                                <div className="flex items-center gap-2 ml-6">
                                    <input
                                        type="number"
                                        min="1"
                                        max="100"
                                        value={count}
                                        onChange={(e) => setCount(parseInt(e.target.value) || 1)}
                                        className="w-20 px-3 py-2 bg-background border border-border rounded-lg text-white focus:outline-none focus:border-primary"
                                    />
                                    <span className="text-sm text-muted">occurrence(s)</span>
                                </div>
                            )}
                        </div>
                    </div>

                    {/* Preview */}
                    <div className="p-3 bg-primary/10 border border-primary/20 rounded-lg">
                        <div className="flex items-start gap-2">
                            <Calendar className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                            <div>
                                <p className="text-sm text-primary font-medium">{getPreviewText()}</p>
                                <p className="text-xs text-primary/70 mt-1">
                                    New tasks will be created automatically based on this schedule
                                </p>
                            </div>
                        </div>
                    </div>

                    {/* Warning */}
                    <div className="p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
                        <div className="flex items-start gap-2">
                            <AlertCircle className="w-4 h-4 text-yellow-400 mt-0.5 flex-shrink-0" />
                            <p className="text-xs text-yellow-400">
                                Note: Recurring tasks are simulated in this demo. In a real app, these would be created by a backend service.
                            </p>
                        </div>
                    </div>
                </div>

                {/* Footer */}
                <div className="p-6 border-t border-border flex gap-3">
                    <button
                        onClick={onClose}
                        className="flex-1 px-4 py-2 bg-background hover:bg-hover text-white rounded-lg transition-colors"
                    >
                        Cancel
                    </button>
                    <button
                        onClick={handleSave}
                        className="flex-1 px-4 py-2 bg-primary hover:bg-blue-600 text-white rounded-lg font-medium transition-colors"
                    >
                        Set Recurring
                    </button>
                </div>
            </div>
        </div>
    );
};
