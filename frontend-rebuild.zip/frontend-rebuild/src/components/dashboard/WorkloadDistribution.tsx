import { Users } from 'lucide-react';
import type { Task } from '../../context/DataContext';

interface WorkloadDistributionProps {
    tasks: Task[];
    members?: string[]; // Optional for now, can be derived from tasks
}

export const WorkloadDistribution = ({ tasks, members = [] }: WorkloadDistributionProps) => {
    // Calculate workload per assignee
    const workload = tasks.reduce((acc, task) => {
        const assignee = task.assignee || 'Unassigned';
        acc[assignee] = (acc[assignee] || 0) + 1;
        return acc;
    }, {} as Record<string, number>);

    // Get all unique assignees (from tasks + provided members)
    const allAssignees = Array.from(new Set([...Object.keys(workload), ...members])).filter(name => name !== 'Unassigned');

    // Add Unassigned if there are unassigned tasks
    if (workload['Unassigned']) {
        allAssignees.push('Unassigned');
    }

    const teamMembers = allAssignees.map((name, index) => {
        const taskCount = workload[name] || 0;
        const capacity = 10; // Default capacity per person
        const colors = ['bg-blue-500', 'bg-purple-500', 'bg-green-500', 'bg-orange-500', 'bg-pink-500'];

        return {
            name,
            avatar: name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase(),
            tasks: taskCount,
            capacity,
            color: name === 'Unassigned' ? 'bg-gray-400' : colors[index % colors.length]
        };
    }).sort((a, b) => b.tasks - a.tasks); // Sort by highest workload

    return (
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm">
            <div className="p-6 border-b border-gray-100">
                <div className="flex items-center gap-2">
                    <Users className="w-5 h-5 text-gray-600" />
                    <h3 className="text-lg font-semibold text-gray-900">Workload Distribution</h3>
                </div>
                <p className="text-sm text-gray-500 mt-1">Current task allocation across team members</p>
            </div>
            <div className="p-6">
                <div className="space-y-4">
                    {teamMembers.length > 0 ? (
                        teamMembers.map((member, idx) => {
                            const utilization = (member.tasks / member.capacity) * 100;
                            const isOverloaded = utilization > 90;
                            const isUnderutilized = utilization < 40;

                            return (
                                <div key={idx} className="space-y-2">
                                    <div className="flex items-center justify-between">
                                        <div className="flex items-center gap-3">
                                            <div className={`w-10 h-10 rounded-full ${member.color} flex items-center justify-center text-white font-semibold text-sm`}>
                                                {member.avatar}
                                            </div>
                                            <div>
                                                <p className="font-medium text-gray-900">{member.name}</p>
                                                <p className="text-xs text-gray-500">
                                                    {member.tasks} tasks
                                                </p>
                                            </div>
                                        </div>
                                        <div className="text-right">
                                            <span className={`text-sm font-semibold ${isOverloaded ? 'text-red-600' :
                                                isUnderutilized ? 'text-yellow-600' :
                                                    'text-green-600'
                                                }`}>
                                                {utilization.toFixed(0)}%
                                            </span>
                                        </div>
                                    </div>
                                    <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                                        <div
                                            className={`h-full rounded-full transition-all ${isOverloaded ? 'bg-red-500' :
                                                isUnderutilized ? 'bg-yellow-500' :
                                                    'bg-green-500'
                                                }`}
                                            style={{ width: `${Math.min(utilization, 100)}%` }}
                                        />
                                    </div>
                                </div>
                            );
                        })
                    ) : (
                        <div className="text-center py-8 text-gray-500">
                            No active tasks to display.
                        </div>
                    )}
                </div>
                <div className="mt-6 pt-6 border-t border-gray-100">
                    <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-4">
                            <div className="flex items-center gap-2">
                                <div className="w-3 h-3 rounded-full bg-green-500"></div>
                                <span className="text-gray-600">Optimal</span>
                            </div>
                            <div className="flex items-center gap-2">
                                <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                                <span className="text-gray-600">Underutilized</span>
                            </div>
                            <div className="flex items-center gap-2">
                                <div className="w-3 h-3 rounded-full bg-red-500"></div>
                                <span className="text-gray-600">Overloaded</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
