import { CheckCircle, MessageCircle, FileText, UserPlus, Clock } from 'lucide-react';
import { useState } from 'react';
import { ActivityDetailModal } from './ActivityDetailModal';

export const ActivityFeed = () => {
    const [showDetailModal, setShowDetailModal] = useState(false);

    const activities = [
        {
            id: 1,
            type: 'task_completed',
            user: 'Sarah Johnson',
            avatar: 'SJ',
            action: 'completed',
            target: 'Update landing page design',
            time: '2 minutes ago',
            icon: CheckCircle,
            iconColor: 'text-green-500',
            iconBg: 'bg-green-50'
        },
        {
            id: 2,
            type: 'comment',
            user: 'Mike Chen',
            avatar: 'MC',
            action: 'commented on',
            target: 'API Integration',
            time: '15 minutes ago',
            icon: MessageCircle,
            iconColor: 'text-blue-500',
            iconBg: 'bg-blue-50'
        },
        {
            id: 3,
            type: 'task_created',
            user: 'Emma Davis',
            avatar: 'ED',
            action: 'created',
            target: 'Database migration task',
            time: '1 hour ago',
            icon: FileText,
            iconColor: 'text-purple-500',
            iconBg: 'bg-purple-50'
        },
        {
            id: 4,
            type: 'member_added',
            user: 'James Wilson',
            avatar: 'JW',
            action: 'added',
            target: 'Lisa Anderson to the team',
            time: '2 hours ago',
            icon: UserPlus,
            iconColor: 'text-orange-500',
            iconBg: 'bg-orange-50'
        },
        {
            id: 5,
            type: 'deadline',
            user: 'System',
            avatar: 'SY',
            action: 'reminder:',
            target: '3 tasks due tomorrow',
            time: '3 hours ago',
            icon: Clock,
            iconColor: 'text-red-500',
            iconBg: 'bg-red-50'
        },
    ];

    return (
        <>
            <div className="bg-white rounded-xl border border-gray-200 shadow-sm">
                <div className="p-6 border-b border-gray-100">
                    <h3 className="text-lg font-semibold text-gray-900">Recent Activity</h3>
                    <p className="text-sm text-gray-500 mt-1">Latest updates from your team</p>
                </div>
                <div className="p-6">
                    <div className="space-y-4">
                        {activities.map((activity) => {
                            const Icon = activity.icon;
                            return (
                                <div key={activity.id} className="flex gap-3">
                                    <div className={`w-10 h-10 rounded-lg ${activity.iconBg} flex items-center justify-center flex-shrink-0`}>
                                        <Icon className={`w-5 h-5 ${activity.iconColor}`} />
                                    </div>
                                    <div className="flex-1 min-w-0">
                                        <p className="text-sm text-gray-900">
                                            <span className="font-semibold">{activity.user}</span>
                                            {' '}{activity.action}{' '}
                                            <span className="font-medium text-gray-700">{activity.target}</span>
                                        </p>
                                        <p className="text-xs text-gray-500 mt-1">{activity.time}</p>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                    <button
                        onClick={() => setShowDetailModal(true)}
                        className="w-full mt-6 py-2 text-sm font-medium text-primary hover:text-primary/80 transition-colors"
                    >
                        View all activity
                    </button>
                </div>
            </div>

            <ActivityDetailModal
                isOpen={showDetailModal}
                onClose={() => setShowDetailModal(false)}
            />
        </>
    );
};
