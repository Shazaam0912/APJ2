import { Activity, AlertTriangle, CheckCircle, Clock } from 'lucide-react';
import type { Project } from '../../context/DataContext';

interface ProjectHealthProps {
    projects: Project[];
}

export const ProjectHealth = ({ projects }: ProjectHealthProps) => {
    const getProjectStats = (project: Project) => {
        const tasks = Object.values(project.boardData.tasks);
        const totalTasks = tasks.length;
        const completedTasks = tasks.filter(t => t.status === 'Done' || t.completed).length;
        const progress = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

        // Determine status based on progress
        // In a real app, this would also consider due dates
        let status = 'on-track';
        if (progress < 30 && totalTasks > 0) status = 'delayed';
        else if (progress < 70 && totalTasks > 0) status = 'at-risk';

        // Mock days left for now as Project doesn't have a due date field yet
        const daysLeft = Math.floor(Math.random() * 30) + 1;

        return {
            id: project.id,
            name: project.name,
            status,
            progress,
            tasksCompleted: completedTasks,
            totalTasks,
            daysLeft,
            color: getProjectColor(project.id)
        };
    };

    const getProjectColor = (id: string) => {
        const colors = ['bg-blue-500', 'bg-purple-500', 'bg-green-500', 'bg-orange-500', 'bg-pink-500'];
        return colors[id.charCodeAt(0) % colors.length];
    };

    const getHealthIcon = (status: string) => {
        switch (status) {
            case 'on-track':
                return { icon: CheckCircle, color: 'text-green-500', bg: 'bg-green-50' };
            case 'at-risk':
                return { icon: Clock, color: 'text-yellow-500', bg: 'bg-yellow-50' };
            case 'delayed':
                return { icon: AlertTriangle, color: 'text-red-500', bg: 'bg-red-50' };
            default:
                return { icon: Activity, color: 'text-gray-500', bg: 'bg-gray-50' };
        }
    };

    const getStatusLabel = (status: string) => {
        switch (status) {
            case 'on-track':
                return 'On Track';
            case 'at-risk':
                return 'At Risk';
            case 'delayed':
                return 'Delayed';
            default:
                return 'Unknown';
        }
    };

    const projectStats = projects.map(getProjectStats);

    return (
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm">
            <div className="p-6 border-b border-gray-100">
                <div className="flex items-center gap-2">
                    <Activity className="w-5 h-5 text-gray-600" />
                    <h3 className="text-lg font-semibold text-gray-900">Project Health</h3>
                </div>
                <p className="text-sm text-gray-500 mt-1">Monitor project status and progress</p>
            </div>
            <div className="p-6">
                <div className="space-y-4">
                    {projectStats.length > 0 ? (
                        projectStats.map((project) => {
                            const health = getHealthIcon(project.status);
                            const Icon = health.icon;

                            return (
                                <div key={project.id} className="border border-gray-200 rounded-lg p-4 hover:border-gray-300 transition-colors">
                                    <div className="flex items-start justify-between mb-3">
                                        <div className="flex items-start gap-3">
                                            <div className={`w-10 h-10 rounded-lg ${project.color} flex items-center justify-center text-white font-bold text-sm`}>
                                                {project.name.charAt(0).toUpperCase()}
                                            </div>
                                            <div>
                                                <h4 className="font-semibold text-gray-900">{project.name}</h4>
                                                <p className="text-xs text-gray-500 mt-0.5">
                                                    {project.tasksCompleted} of {project.totalTasks} tasks • {project.daysLeft} days left
                                                </p>
                                            </div>
                                        </div>
                                        <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full ${health.bg}`}>
                                            <Icon className={`w-3.5 h-3.5 ${health.color}`} />
                                            <span className={`text-xs font-medium ${health.color}`}>
                                                {getStatusLabel(project.status)}
                                            </span>
                                        </div>
                                    </div>
                                    <div>
                                        <div className="flex items-center justify-between mb-1.5">
                                            <span className="text-xs font-medium text-gray-600">Progress</span>
                                            <span className="text-xs font-semibold text-gray-900">{project.progress}%</span>
                                        </div>
                                        <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                                            <div
                                                className={`h-full ${project.color} rounded-full transition-all`}
                                                style={{ width: `${project.progress}%` }}
                                            />
                                        </div>
                                    </div>
                                </div>
                            );
                        })
                    ) : (
                        <div className="text-center py-8 text-gray-500">
                            No active projects found.
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};
