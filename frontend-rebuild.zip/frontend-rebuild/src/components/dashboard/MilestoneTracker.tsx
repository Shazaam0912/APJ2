import { Flag, CheckCircle2, Circle, Clock } from 'lucide-react';

export const MilestoneTracker = () => {
    const milestones = [
        {
            id: 1,
            title: 'Alpha Release',
            date: 'Jan 15, 2024',
            status: 'completed',
            progress: 100,
            tasksCompleted: 12,
            totalTasks: 12
        },
        {
            id: 2,
            title: 'Beta Testing',
            date: 'Feb 28, 2024',
            status: 'in-progress',
            progress: 65,
            tasksCompleted: 13,
            totalTasks: 20
        },
        {
            id: 3,
            title: 'Feature Freeze',
            date: 'Mar 15, 2024',
            status: 'upcoming',
            progress: 0,
            tasksCompleted: 0,
            totalTasks: 8
        },
        {
            id: 4,
            title: 'Production Release',
            date: 'Apr 1, 2024',
            status: 'upcoming',
            progress: 0,
            tasksCompleted: 0,
            totalTasks: 15
        },
    ];

    const getStatusIcon = (status: string) => {
        switch (status) {
            case 'completed':
                return { icon: CheckCircle2, color: 'text-green-500' };
            case 'in-progress':
                return { icon: Clock, color: 'text-blue-500' };
            default:
                return { icon: Circle, color: 'text-gray-300' };
        }
    };

    return (
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm">
            <div className="p-6 border-b border-gray-100">
                <div className="flex items-center gap-2">
                    <Flag className="w-5 h-5 text-gray-600" />
                    <h3 className="text-lg font-semibold text-gray-900">Milestones</h3>
                </div>
                <p className="text-sm text-gray-500 mt-1">Track project milestones</p>
            </div>
            <div className="p-6">
                <div className="space-y-6">
                    {milestones.map((milestone, idx) => {
                        const statusInfo = getStatusIcon(milestone.status);
                        const Icon = statusInfo.icon;
                        const isLast = idx === milestones.length - 1;

                        return (
                            <div key={milestone.id} className="relative">
                                <div className="flex gap-4">
                                    <div className="flex flex-col items-center">
                                        <div className={`w-8 h-8 rounded-full border-2 ${milestone.status === 'completed' ? 'border-green-500 bg-green-50' :
                                                milestone.status === 'in-progress' ? 'border-blue-500 bg-blue-50' :
                                                    'border-gray-300 bg-white'
                                            } flex items-center justify-center flex-shrink-0`}>
                                            <Icon className={`w-4 h-4 ${statusInfo.color}`} />
                                        </div>
                                        {!isLast && (
                                            <div className={`w-0.5 h-full mt-2 ${milestone.status === 'completed' ? 'bg-green-500' : 'bg-gray-200'
                                                }`} style={{ minHeight: '40px' }} />
                                        )}
                                    </div>
                                    <div className="flex-1 pb-2">
                                        <div className="flex items-start justify-between mb-1">
                                            <div>
                                                <h4 className="font-semibold text-gray-900">{milestone.title}</h4>
                                                <p className="text-xs text-gray-500 mt-0.5">{milestone.date}</p>
                                            </div>
                                            {milestone.status === 'in-progress' && (
                                                <span className="text-xs font-semibold text-blue-600">
                                                    {milestone.progress}%
                                                </span>
                                            )}
                                        </div>
                                        {milestone.status !== 'upcoming' && (
                                            <>
                                                <p className="text-xs text-gray-600 mt-2">
                                                    {milestone.tasksCompleted}/{milestone.totalTasks} tasks
                                                </p>
                                                {milestone.status === 'in-progress' && (
                                                    <div className="mt-2 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                                                        <div
                                                            className="h-full bg-blue-500 rounded-full transition-all"
                                                            style={{ width: `${milestone.progress}%` }}
                                                        />
                                                    </div>
                                                )}
                                            </>
                                        )}
                                    </div>
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>
        </div>
    );
};
