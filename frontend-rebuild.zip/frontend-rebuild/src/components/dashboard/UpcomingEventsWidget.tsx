import { Calendar, Clock, Video, Users, ChevronRight } from 'lucide-react';
import clsx from 'clsx';
import { useData } from '../../context/DataContext';

interface Event {
    id: string;
    title: string;
    time: string;
    type: 'meeting' | 'deadline' | 'event';
    attendees?: number;
}

interface UpcomingEventsWidgetProps {
    events: Event[];
}

const eventIcons = {
    meeting: Video,
    deadline: Clock,
    event: Calendar,
};

const eventColors = {
    meeting: 'text-blue-500 bg-blue-500/10',
    deadline: 'text-red-500 bg-red-500/10',
    event: 'text-purple-500 bg-purple-500/10',
};

export const UpcomingEventsWidget = ({ events }: UpcomingEventsWidgetProps) => {
    const { setActivePage } = useData();

    return (
        <div className="bg-white border border-border rounded-xl p-6 shadow-sm">
            <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-bold text-text">Upcoming Events</h3>
                <button
                    onClick={() => setActivePage('calendar')}
                    className="text-sm text-primary font-medium hover:underline flex items-center gap-1"
                >
                    View Calendar
                    <ChevronRight className="w-4 h-4" />
                </button>
            </div>
            <div className="space-y-3">
                {events.map((event) => {
                    const Icon = eventIcons[event.type];
                    return (
                        <div
                            key={event.id}
                            className="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer group border border-transparent hover:border-gray-100"
                        >
                            <div className={clsx(
                                "w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0",
                                eventColors[event.type]
                            )}>
                                <Icon className="w-5 h-5" />
                            </div>
                            <div className="flex-1 min-w-0">
                                <p className="text-sm font-medium text-text truncate group-hover:text-primary transition-colors">
                                    {event.title}
                                </p>
                                <div className="flex items-center gap-2 mt-1">
                                    <span className="text-xs text-muted">{event.time}</span>
                                    {event.attendees && (
                                        <div className="flex items-center gap-1 text-xs text-muted">
                                            <Users className="w-3 h-3" />
                                            <span>{event.attendees}</span>
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    );
};
