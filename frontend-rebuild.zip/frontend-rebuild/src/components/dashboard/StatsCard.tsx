import { ChevronRight } from 'lucide-react';
import clsx from 'clsx';

interface StatsCardProps {
    title: string;
    value: string | number;
    icon: React.ReactNode;
    color?: 'blue' | 'green' | 'orange' | 'purple' | 'black';
    onClick?: () => void;
    progress?: number;
}

export const StatsCard = ({ title, value, icon, color = 'blue', onClick, progress }: StatsCardProps) => {
    const colorMap = {
        blue: 'bg-blue-500',
        green: 'bg-green-500',
        orange: 'bg-orange-500',
        purple: 'bg-purple-500',
        black: 'bg-black',
        primary: 'bg-primary'
    };

    const textMap = {
        blue: 'text-blue-500',
        green: 'text-green-500',
        orange: 'text-orange-500',
        purple: 'text-purple-500',
        black: 'text-black',
        primary: 'text-primary'
    };

    return (
        <div
            onClick={onClick}
            className={clsx(
                "bg-white border border-border rounded-xl p-5 hover:shadow-md transition-all duration-200 group relative overflow-hidden",
                onClick && "cursor-pointer hover:border-primary/50"
            )}
        >
            <div className="flex items-start justify-between mb-4">
                <div className={clsx("w-10 h-10 rounded-lg text-white flex items-center justify-center shadow-sm relative", !progress && (colorMap[color as keyof typeof colorMap] || 'bg-black'))}>
                    {progress !== undefined ? (
                        <div className="relative w-10 h-10 flex items-center justify-center">
                            <svg className="w-full h-full transform -rotate-90">
                                <circle
                                    cx="20"
                                    cy="20"
                                    r="18"
                                    stroke="currentColor"
                                    strokeWidth="4"
                                    fill="transparent"
                                    className="text-gray-100"
                                />
                                <circle
                                    cx="20"
                                    cy="20"
                                    r="18"
                                    stroke="currentColor"
                                    strokeWidth="4"
                                    fill="transparent"
                                    strokeDasharray={113}
                                    strokeDashoffset={113 - (113 * progress) / 100}
                                    className={clsx(textMap[color as keyof typeof textMap] || 'text-primary')}
                                    strokeLinecap="round"
                                />
                            </svg>
                            <div className="absolute inset-0 flex items-center justify-center text-[10px] font-bold text-gray-700">
                                {Math.round(progress)}%
                            </div>
                        </div>
                    ) : (
                        icon
                    )}
                </div>
                <div className="flex items-center gap-1 text-xs font-medium text-text group-hover:text-primary transition-colors">
                    View Details <ChevronRight className="w-3 h-3" />
                </div>
            </div>
            <div className="space-y-1">
                <p className="text-2xl font-bold text-text">{value}</p>
                <p className="text-sm text-muted">{title}</p>
            </div>
        </div>
    );
};
