import { X, CheckCircle, MessageCircle, FileText, UserPlus, Clock, Activity } from 'lucide-react';
import clsx from 'clsx';

interface ActivityDetailModalProps {
    isOpen: boolean;
    onClose: () => void;
}

export const ActivityDetailModal = ({ isOpen, onClose }: ActivityDetailModalProps) => {
    if (!isOpen) return null;

    const activities = [
        { id: 1, type: 'task_completed', user: 'Sarah Johnson', avatar: 'SJ', action: 'completed', target: 'Update landing page design', time: '2 minutes ago', icon: CheckCircle, iconColor: 'text-green-500', iconBg: 'bg-green-50' },
        { id: 2, type: 'comment', user: 'Mike Chen', avatar: 'MC', action: 'commented on', target: 'API Integration', time: '15 minutes ago', icon: MessageCircle, iconColor: 'text-blue-500', iconBg: 'bg-blue-50' },
        { id: 3, type: 'task_created', user: 'Emma Davis', avatar: 'ED', action: 'created', target: 'Database migration task', time: '1 hour ago', icon: FileText, iconColor: 'text-purple-500', iconBg: 'bg-purple-50' },
        { id: 4, type: 'member_added', user: 'James Wilson', avatar: 'JW', action: 'added', target: 'Lisa Anderson to the team', time: '2 hours ago', icon: UserPlus, iconColor: 'text-orange-500', iconBg: 'bg-orange-50' },
        { id: 5, type: 'deadline', user: 'System', avatar: 'SY', action: 'reminder:', target: '3 tasks due tomorrow', time: '3 hours ago', icon: Clock, iconColor: 'text-red-500', iconBg: 'bg-red-50' },
        { id: 6, type: 'task_completed', user: 'Alex Thompson', avatar: 'AT', action: 'completed', target: 'Write project documentation', time: '4 hours ago', icon: CheckCircle, iconColor: 'text-green-500', iconBg: 'bg-green-50' },
        { id: 7, type: 'comment', user: 'Lisa Anderson', avatar: 'LA', action: 'commented on', target: 'Sprint Planning Meeting', time: '5 hours ago', icon: MessageCircle, iconColor: 'text-blue-500', iconBg: 'bg-blue-50' },
        { id: 8, type: 'task_created', user: 'David Lee', avatar: 'DL', action: 'created', target: 'Implement dark mode', time: '6 hours ago', icon: FileText, iconColor: 'text-purple-500', iconBg: 'bg-purple-50' },
    ];

    const activityStats = {
        today: activities.slice(0, 5).length,
        thisWeek: activities.length,
        completions: activities.filter(a => a.type === 'task_completed').length,
    };

    return (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={onClose}>
            <div
                className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl max-h-[85vh] flex flex-col overflow-hidden"
                onClick={e => e.stopPropagation()}
            >
                <div className="p-6 border-b border-gray-200 bg-gradient-to-br from-blue-50 to-purple-50">
                    <div className="flex items-center justify-between">
                        <div>
                            <h2 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
                                <Activity className="w-6 h-6 text-primary" /> Activity Timeline
                            </h2>
                            <p className="text-sm text-gray-600 mt-1">Complete history of your team's activities</p>
                        </div>
                        <button onClick={onClose} className="p-2 hover:bg-white rounded-lg transition-colors">
                            <X className="w-5 h-5 text-gray-500" />
                        </button>
                    </div>

                    {/* Quick Stats */}
                    <div className="grid grid-cols-3 gap-4 mt-4">
                        <div className="bg-white rounded-lg p-3">
                            <div className="text-2xl font-bold text-primary">{activityStats.today}</div>
                            <div className="text-xs text-gray-600">Today's Updates</div>
                        </div>
                        <div className="bg-white rounded-lg p-3">
                            <div className="text-2xl font-bold text-blue-600">{activityStats.thisWeek}</div>
                            <div className="text-xs text-gray-600">This Week</div>
                        </div>
                        <div className="bg-white rounded-lg p-3">
                            <div className="text-2xl font-bold text-green-600">{activityStats.completions}</div>
                            <div className="text-xs text-gray-600">Completed</div>
                        </div>
                    </div>
                </div>

                <div className="flex-1 overflow-y-auto p-6">
                    {/* Timeline */}
                    <div className="relative">
                        <div className="absolute left-[21px] top-0 bottom-0 w-0.5 bg-gradient-to-b from-primary/20 via-blue-200 to-transparent" />
                        <div className="space-y-6">
                            {activities.map((activity) => {
                                const Icon = activity.icon;
                                return (
                                    <div key={activity.id} className="relative flex gap-4">
                                        <div className={clsx("w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0 relative z-10 shadow-sm", activity.iconBg)}>
                                            <Icon className={clsx("w-5 h-5", activity.iconColor)} />
                                        </div>
                                        <div className="flex-1 bg-white border border-gray-100 rounded-xl p-4 hover:border-gray-200 hover:shadow-sm transition-all">
                                            <div className="flex items-start justify-between mb-1">
                                                <p className="text-sm text-gray-900">
                                                    <span className="font-semibold">{activity.user}</span>
                                                    {' '}{activity.action}{' '}
                                                    <span className="font-medium text-gray-700">{activity.target}</span>
                                                </p>
                                            </div>
                                            <p className="text-xs text-gray-400">{activity.time}</p>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    </div>

                    <button className="w-full mt-6 py-3 text-sm font-medium text-primary hover:bg-primary/5 rounded-lg transition-colors border border-primary/20">
                        Load More Activities
                    </button>
                </div>
            </div>
        </div>
    );
};
