import { TrendingUp, TrendingDown } from 'lucide-react';
import type { Task } from '../../context/DataContext';

interface PerformanceChartProps {
    tasks: Task[];
}

export const PerformanceChart = ({ tasks }: PerformanceChartProps) => {
    // Generate last 6 months
    const months = Array.from({ length: 6 }, (_, i) => {
        const d = new Date();
        d.setMonth(d.getMonth() - (5 - i));
        return {
            name: d.toLocaleString('default', { month: 'short' }),
            key: `${d.getFullYear()}-${d.getMonth()}`,
            target: 10 // Mock target
        };
    });

    // Calculate completion per month
    const performanceData = months.map(month => {
        const completedCount = tasks.filter(task => {
            if (!task.completed && task.status !== 'Done') return false;
            // Use updatedAt or createdAt as a proxy for completion date if not available
            const date = new Date(task.updatedAt || task.createdAt);
            const key = `${date.getFullYear()}-${date.getMonth()}`;
            return key === month.key;
        }).length;

        return {
            month: month.name,
            completed: completedCount,
            target: month.target
        };
    });

    const totalCompleted = performanceData.reduce((acc, d) => acc + d.completed, 0);
    const avgCompletion = performanceData.length > 0 ? (totalCompleted / performanceData.length).toFixed(1) : 0;

    // Calculate trend (current month vs previous month)
    const currentMonth = performanceData[performanceData.length - 1].completed;
    const prevMonth = performanceData[performanceData.length - 2]?.completed || 0;
    const trend = currentMonth >= prevMonth;
    const trendDiff = prevMonth > 0 ? Math.round(((currentMonth - prevMonth) / prevMonth) * 100) : 0;

    return (
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm">
            <div className="p-6 border-b border-gray-100">
                <div className="flex items-center justify-between">
                    <div>
                        <h3 className="text-lg font-semibold text-gray-900">Performance Overview</h3>
                        <p className="text-sm text-gray-500 mt-1">Task completion trends over time</p>
                    </div>
                    <div className="flex items-center gap-2">
                        {trend ? (
                            <TrendingUp className="w-5 h-5 text-green-500" />
                        ) : (
                            <TrendingDown className="w-5 h-5 text-red-500" />
                        )}
                        <span className={`text-sm font-semibold ${trend ? 'text-green-600' : 'text-red-600'}`}>
                            {trend ? '+' : ''}{trendDiff}% vs last month
                        </span>
                    </div>
                </div>
            </div>
            <div className="p-6">
                <div className="flex items-end justify-between gap-4 h-48">
                    {performanceData.map((data, idx) => {
                        // Normalize height relative to max value or target, capped at 100%
                        const maxVal = Math.max(...performanceData.map(d => d.completed), 10);
                        const height = maxVal > 0 ? (data.completed / maxVal) * 100 : 0;

                        return (
                            <div key={idx} className="flex-1 flex flex-col items-center gap-2">
                                <div className="w-full flex items-end justify-center h-40">
                                    <div
                                        className="w-full bg-gradient-to-t from-primary to-primary/70 rounded-t-lg transition-all hover:opacity-80 cursor-pointer relative group"
                                        style={{ height: `${Math.max(height, 5)}%` }} // Min height for visibility
                                    >
                                        <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-gray-900 text-white px-2 py-1 rounded text-xs font-semibold opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                                            {data.completed} tasks
                                        </div>
                                    </div>
                                </div>
                                <span className="text-xs font-medium text-gray-600">{data.month}</span>
                            </div>
                        );
                    })}
                </div>
                <div className="mt-6 pt-6 border-t border-gray-100 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                        <div className="flex items-center gap-2">
                            <div className="w-3 h-3 rounded-full bg-primary"></div>
                            <span className="text-sm text-gray-600">Completed Tasks</span>
                        </div>
                    </div>
                    <div className="text-right">
                        <p className="text-sm text-gray-500">Avg. Monthly Completion</p>
                        <p className="text-2xl font-bold text-gray-900">{avgCompletion}</p>
                    </div>
                </div>
            </div>
        </div>
    );
};
