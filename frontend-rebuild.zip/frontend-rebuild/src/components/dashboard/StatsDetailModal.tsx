import { X, Users, Briefcase, FileText, Target, BarChart3, PieChart, TrendingUp } from 'lucide-react';
import type { Project, Task } from '../../context/DataContext';
import clsx from 'clsx';

interface StatsDetailModalProps {
    isOpen: boolean;
    onClose: () => void;
    type: 'employees' | 'projects' | 'tasks' | 'completion' | null;
    data: {
        projects: Project[];
        tasks: Task[];
        teamMembers: any[]; // Using any for now as TeamMember type isn't exported yet
    };
}

export const StatsDetailModal = ({ isOpen, onClose, type, data }: StatsDetailModalProps) => {
    if (!isOpen || !type) return null;

    const renderContent = () => {
        switch (type) {
            case 'employees':
                return <EmployeesAnalysis members={data.teamMembers} tasks={data.tasks} />;
            case 'projects':
                return <ProjectsAnalysis projects={data.projects} />;
            case 'tasks':
                return <TasksAnalysis tasks={data.tasks} />;
            case 'completion':
                return <CompletionAnalysis tasks={data.tasks} />;
            default:
                return null;
        }
    };

    const getTitle = () => {
        switch (type) {
            case 'employees': return 'Team Analytics';
            case 'projects': return 'Project Portfolio Health';
            case 'tasks': return 'Task Distribution Analysis';
            case 'completion': return 'Performance Metrics';
            default: return '';
        }
    };

    return (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={onClose}>
            <div
                className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col"
                onClick={e => e.stopPropagation()}
            >
                {/* Header */}
                <div className="p-6 border-b border-gray-100 flex items-center justify-between bg-gray-50/50">
                    <div className="flex items-center gap-3">
                        <div className="p-2 bg-primary/10 rounded-lg text-primary">
                            {type === 'employees' && <Users className="w-6 h-6" />}
                            {type === 'projects' && <Briefcase className="w-6 h-6" />}
                            {type === 'tasks' && <FileText className="w-6 h-6" />}
                            {type === 'completion' && <Target className="w-6 h-6" />}
                        </div>
                        <div>
                            <h2 className="text-xl font-bold text-gray-900">{getTitle()}</h2>
                            <p className="text-sm text-gray-500">Detailed breakdown and insights</p>
                        </div>
                    </div>
                    <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                        <X className="w-5 h-5 text-gray-400" />
                    </button>
                </div>

                {/* Content */}
                <div className="flex-1 overflow-y-auto p-6 bg-gray-50/30">
                    {renderContent()}
                </div>
            </div>
        </div>
    );
};

// Sub-components for specific views

const EmployeesAnalysis = ({ members, tasks }: { members: any[], tasks: Task[] }) => {
    // Calculate workload
    const workload = tasks.reduce((acc, task) => {
        const assignee = task.assignee || 'Unassigned';
        acc[assignee] = (acc[assignee] || 0) + 1;
        return acc;
    }, {} as Record<string, number>);

    return (
        <div className="space-y-6">
            <div className="grid grid-cols-3 gap-4">
                <div className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm">
                    <h3 className="text-sm font-medium text-gray-500 mb-1">Total Members</h3>
                    <p className="text-2xl font-bold text-gray-900">{members.length}</p>
                </div>
                <div className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm">
                    <h3 className="text-sm font-medium text-gray-500 mb-1">Active Now</h3>
                    <p className="text-2xl font-bold text-green-600">
                        {members.filter(m => m.status === 'online').length}
                    </p>
                </div>
                <div className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm">
                    <h3 className="text-sm font-medium text-gray-500 mb-1">Avg. Workload</h3>
                    <p className="text-2xl font-bold text-blue-600">
                        {Math.round(tasks.length / (members.length || 1))} <span className="text-sm font-normal text-gray-400">tasks/person</span>
                    </p>
                </div>
            </div>

            <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm">
                <h3 className="text-lg font-bold text-gray-900 mb-6">Workload Distribution</h3>
                <div className="space-y-4">
                    {Object.entries(workload).map(([name, count], idx) => (
                        <div key={name} className="flex items-center gap-4">
                            <div className="w-32 text-sm font-medium text-gray-700 truncate">{name}</div>
                            <div className="flex-1 h-3 bg-gray-100 rounded-full overflow-hidden">
                                <div
                                    className={clsx(
                                        "h-full rounded-full transition-all",
                                        idx % 3 === 0 ? "bg-blue-500" : idx % 3 === 1 ? "bg-purple-500" : "bg-green-500"
                                    )}
                                    style={{ width: `${Math.min((count / 10) * 100, 100)}%` }}
                                />
                            </div>
                            <div className="w-12 text-sm text-gray-500 text-right">{count} tasks</div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

const ProjectsAnalysis = ({ projects }: { projects: Project[] }) => {
    const onTrack = projects.filter(p => {
        const tasks = Object.values(p.boardData.tasks);
        const completed = tasks.filter(t => t.status === 'Done').length;
        return tasks.length === 0 || (completed / tasks.length) > 0.7;
    }).length;

    return (
        <div className="space-y-6">
            <div className="grid grid-cols-2 gap-6">
                <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm flex flex-col items-center justify-center">
                    <div className="relative w-40 h-40 mb-4">
                        <svg className="w-full h-full transform -rotate-90">
                            <circle cx="80" cy="80" r="70" stroke="#F3F4F6" strokeWidth="20" fill="transparent" />
                            <circle
                                cx="80" cy="80" r="70" stroke="#10B981" strokeWidth="20" fill="transparent"
                                strokeDasharray={440}
                                strokeDashoffset={440 - (440 * (onTrack / projects.length))}
                                strokeLinecap="round"
                            />
                        </svg>
                        <div className="absolute inset-0 flex flex-col items-center justify-center">
                            <span className="text-3xl font-bold text-gray-900">{Math.round((onTrack / (projects.length || 1)) * 100)}%</span>
                            <span className="text-xs text-gray-500 uppercase font-semibold">Healthy</span>
                        </div>
                    </div>
                    <h3 className="text-lg font-bold text-gray-900">Project Health Score</h3>
                    <p className="text-sm text-gray-500 text-center mt-2">Based on task completion rates</p>
                </div>

                <div className="space-y-4">
                    {projects.map(project => {
                        const tasks = Object.values(project.boardData.tasks);
                        const completed = tasks.filter(t => t.status === 'Done').length;
                        const progress = tasks.length > 0 ? Math.round((completed / tasks.length) * 100) : 0;

                        return (
                            <div key={project.id} className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm">
                                <div className="flex justify-between items-center mb-2">
                                    <h4 className="font-semibold text-gray-900">{project.name}</h4>
                                    <span className={clsx(
                                        "px-2 py-1 rounded text-xs font-medium",
                                        progress >= 70 ? "bg-green-100 text-green-700" : "bg-yellow-100 text-yellow-700"
                                    )}>{progress >= 70 ? 'On Track' : 'At Risk'}</span>
                                </div>
                                <div className="w-full bg-gray-100 rounded-full h-2">
                                    <div
                                        className={clsx("h-full rounded-full", progress >= 70 ? "bg-green-500" : "bg-yellow-500")}
                                        style={{ width: `${progress}%` }}
                                    />
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>
        </div>
    );
};

const TasksAnalysis = ({ tasks }: { tasks: Task[] }) => {
    const statusCounts = {
        todo: tasks.filter(t => t.status === 'To Do').length,
        inProgress: tasks.filter(t => t.status === 'In Progress').length,
        done: tasks.filter(t => t.status === 'Done').length,
    };

    const priorityCounts = {
        high: tasks.filter(t => t.priority === 'high').length,
        medium: tasks.filter(t => t.priority === 'medium').length,
        low: tasks.filter(t => t.priority === 'low').length,
    };

    return (
        <div className="space-y-6">
            <div className="grid grid-cols-2 gap-6">
                <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm">
                    <h3 className="text-lg font-bold text-gray-900 mb-6 flex items-center gap-2">
                        <PieChart className="w-5 h-5 text-gray-400" />
                        Status Breakdown
                    </h3>
                    <div className="flex items-center justify-center gap-8">
                        <div className="space-y-3">
                            <div className="flex items-center gap-2">
                                <div className="w-3 h-3 rounded-full bg-gray-300" />
                                <span className="text-sm text-gray-600">To Do ({statusCounts.todo})</span>
                            </div>
                            <div className="flex items-center gap-2">
                                <div className="w-3 h-3 rounded-full bg-blue-500" />
                                <span className="text-sm text-gray-600">In Progress ({statusCounts.inProgress})</span>
                            </div>
                            <div className="flex items-center gap-2">
                                <div className="w-3 h-3 rounded-full bg-green-500" />
                                <span className="text-sm text-gray-600">Done ({statusCounts.done})</span>
                            </div>
                        </div>
                        {/* Simple CSS Pie Chart representation */}
                        <div className="relative w-32 h-32 rounded-full border-8 border-gray-100 flex items-center justify-center">
                            <div className="text-center">
                                <span className="block text-2xl font-bold text-gray-900">{tasks.length}</span>
                                <span className="text-xs text-gray-500">Total</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm">
                    <h3 className="text-lg font-bold text-gray-900 mb-6 flex items-center gap-2">
                        <BarChart3 className="w-5 h-5 text-gray-400" />
                        Priority Breakdown
                    </h3>
                    <div className="space-y-4">
                        <div className="space-y-1">
                            <div className="flex justify-between text-sm">
                                <span className="text-red-600 font-medium">High Priority</span>
                                <span className="text-gray-600">{priorityCounts.high}</span>
                            </div>
                            <div className="w-full bg-red-50 rounded-full h-2">
                                <div className="bg-red-500 h-full rounded-full" style={{ width: `${(priorityCounts.high / tasks.length) * 100}%` }} />
                            </div>
                        </div>
                        <div className="space-y-1">
                            <div className="flex justify-between text-sm">
                                <span className="text-yellow-600 font-medium">Medium Priority</span>
                                <span className="text-gray-600">{priorityCounts.medium}</span>
                            </div>
                            <div className="w-full bg-yellow-50 rounded-full h-2">
                                <div className="bg-yellow-500 h-full rounded-full" style={{ width: `${(priorityCounts.medium / tasks.length) * 100}%` }} />
                            </div>
                        </div>
                        <div className="space-y-1">
                            <div className="flex justify-between text-sm">
                                <span className="text-green-600 font-medium">Low Priority</span>
                                <span className="text-gray-600">{priorityCounts.low}</span>
                            </div>
                            <div className="w-full bg-green-50 rounded-full h-2">
                                <div className="bg-green-500 h-full rounded-full" style={{ width: `${(priorityCounts.low / tasks.length) * 100}%` }} />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

const CompletionAnalysis = ({ tasks }: { tasks: Task[] }) => {
    const completedTasks = tasks.filter(t => t.status === 'Done' || t.completed);
    const rate = tasks.length > 0 ? (completedTasks.length / tasks.length) * 100 : 0;

    return (
        <div className="space-y-6">
            <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm text-center">
                <h3 className="text-lg font-bold text-gray-900 mb-2">Overall Completion Rate</h3>
                <div className="text-5xl font-bold text-primary mb-2">{rate.toFixed(1)}%</div>
                <p className="text-gray-500">{completedTasks.length} out of {tasks.length} tasks completed</p>
            </div>

            <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm">
                <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-gray-400" />
                    Velocity Insights
                </h3>
                <div className="p-4 bg-blue-50 rounded-lg border border-blue-100 text-blue-800 text-sm">
                    <p className="font-medium mb-1">💡 AI Insight</p>
                    <p>Based on your current velocity, you are on track to complete all active tasks within the next 14 days. Consider reallocating resources from "Low Priority" tasks to speed up "High Priority" items.</p>
                </div>
            </div>
        </div>
    );
};
