import { X, Clock, Flag, Calendar, ChevronRight, Target } from 'lucide-react';
import type { Task } from '../../context/DataContext';
import clsx from 'clsx';

interface FocusDetailModalProps {
    isOpen: boolean;
    onClose: () => void;
    tasks: Task[];
    onTaskClick?: (taskId: string) => void;
}

export const FocusDetailModal = ({ isOpen, onClose, tasks, onTaskClick }: FocusDetailModalProps) => {
    if (!isOpen) return null;

    // Filter for high priority tasks
    const highPriorityTasks = tasks.filter(t => t.priority === 'high');
    const mediumPriorityTasks = tasks.filter(t => t.priority === 'medium');
    const dueSoonTasks = tasks.filter(t => {
        if (!t.dueDate) return false;
        const daysUntilDue = Math.ceil((new Date(t.dueDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24));
        return daysUntilDue <= 3 && daysUntilDue >= 0;
    });

    const priorityColor = (priority: string) => {
        switch (priority) {
            case 'high': return 'bg-red-500';
            case 'medium': return 'bg-yellow-500';
            case 'low': return 'bg-green-500';
            default: return 'bg-gray-500';
        }
    };

    const statusColor = (status: string) => {
        switch (status) {
            case 'done': return 'text-green-600 bg-green-50';
            case 'in_progress': return 'text-blue-600 bg-blue-50';
            case 'todo': return 'text-gray-600 bg-gray-50';
            default: return 'text-gray-600 bg-gray-50';
        }
    };

    const TaskCard = ({ task }: { task: Task }) => (
        <div
            className="p-4 border border-gray-100 rounded-xl hover:border-primary/30 hover:shadow-sm transition-all cursor-pointer group"
            onClick={() => onTaskClick?.(task.id)}
        >
            <div className="flex items-start justify-between gap-3 mb-2">
                <h4 className="font-semibold text-gray-900 group-hover:text-primary transition-colors">{task.content}</h4>
                <ChevronRight className="w-5 h-5 text-gray-400 group-hover:text-primary transition-colors flex-shrink-0" />
            </div>
            <p className="text-sm text-gray-500 mb-3 line-clamp-2">{task.description}</p>
            <div className="flex items-center gap-3 text-xs">
                <div className={clsx("px-2 py-1 rounded-full", statusColor(task.status))}>
                    {task.status.replace('_', ' ').toUpperCase()}
                </div>
                <div className="flex items-center gap-1 text-gray-500">
                    <div className={clsx("w-2 h-2 rounded-full", priorityColor(task.priority))} />
                    <span className="capitalize">{task.priority}</span>
                </div>
                {task.dueDate && (
                    <div className="flex items-center gap-1 text-gray-500">
                        <Calendar className="w-3 h-3" />
                        <span>{new Date(task.dueDate).toLocaleDateString()}</span>
                    </div>
                )}
            </div>
        </div>
    );

    return (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={onClose}>
            <div
                className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl max-h-[85vh] flex flex-col overflow-hidden"
                onClick={e => e.stopPropagation()}
            >
                <div className="p-6 border-b border-gray-200 bg-gradient-to-br from-primary/5 to-blue-50">
                    <div className="flex items-center justify-between">
                        <div>
                            <h2 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
                                <Target className="w-6 h-6 text-primary" /> Priority Task Manager
                            </h2>
                            <p className="text-sm text-gray-600 mt-1">Focus on what matters most right now</p>
                        </div>
                        <button onClick={onClose} className="p-2 hover:bg-white rounded-lg transition-colors">
                            <X className="w-5 h-5 text-gray-500" />
                        </button>
                    </div>

                    {/* Quick Stats */}
                    <div className="grid grid-cols-3 gap-4 mt-4">
                        <div className="bg-white rounded-lg p-3">
                            <div className="text-2xl font-bold text-red-600">{highPriorityTasks.length}</div>
                            <div className="text-xs text-gray-600">High Priority</div>
                        </div>
                        <div className="bg-white rounded-lg p-3">
                            <div className="text-2xl font-bold text-yellow-600">{mediumPriorityTasks.length}</div>
                            <div className="text-xs text-gray-600">Medium Priority</div>
                        </div>
                        <div className="bg-white rounded-lg p-3">
                            <div className="text-2xl font-bold text-blue-600">{dueSoonTasks.length}</div>
                            <div className="text-xs text-gray-600">Due This Week</div>
                        </div>
                    </div>
                </div>

                <div className="flex-1 overflow-y-auto p-6 space-y-6">
                    {/* High Priority Section */}
                    {highPriorityTasks.length > 0 && (
                        <div>
                            <div className="flex items-center gap-2 mb-3">
                                <Flag className="w-5 h-5 text-red-500" />
                                <h3 className="font-bold text-gray-900">High Priority Tasks</h3>
                                <span className="text-xs text-gray-500">({highPriorityTasks.length})</span>
                            </div>
                            <div className="space-y-3">
                                {highPriorityTasks.map(task => <TaskCard key={task.id} task={task} />)}
                            </div>
                        </div>
                    )}

                    {/* Due Soon Section */}
                    {dueSoonTasks.length > 0 && (
                        <div>
                            <div className="flex items-center gap-2 mb-3">
                                <Clock className="w-5 h-5 text-blue-500" />
                                <h3 className="font-bold text-gray-900">Due This Week</h3>
                                <span className="text-xs text-gray-500">({dueSoonTasks.length})</span>
                            </div>
                            <div className="space-y-3">
                                {dueSoonTasks.map(task => <TaskCard key={task.id} task={task} />)}
                            </div>
                        </div>
                    )}

                    {/* Medium Priority Section */}
                    {mediumPriorityTasks.length > 0 && (
                        <div>
                            <div className="flex items-center gap-2 mb-3">
                                <Flag className="w-5 h-5 text-yellow-500" />
                                <h3 className="font-bold text-gray-900">Medium Priority Tasks</h3>
                                <span className="text-xs text-gray-500">({mediumPriorityTasks.length})</span>
                            </div>
                            <div className="space-y-3">
                                {mediumPriorityTasks.slice(0, 5).map(task => <TaskCard key={task.id} task={task} />)}
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};
