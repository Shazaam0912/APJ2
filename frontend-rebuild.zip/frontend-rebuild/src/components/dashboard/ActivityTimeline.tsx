import { Clock, MessageSquare, FileText, GitBranch } from 'lucide-react';
import clsx from 'clsx';


interface ActivityItem {
    id: string;
    type: 'task_created' | 'task_completed' | 'comment_added' | 'document_updated' | 'status_changed';
    user: {
        name: string;
        avatar?: string;
    };
    title: string;
    description: string;
    timestamp: string;
    target?: {
        name: string;
        type: string;
    };
}

const activityIcons = {
    task_created: GitBranch,
    task_completed: Clock,
    comment_added: MessageSquare,
    document_updated: FileText,
    status_changed: GitBranch,
};

const activityColors = {
    task_created: 'text-blue-500 bg-blue-500/10',
    task_completed: 'text-green-500 bg-green-500/10',
    comment_added: 'text-purple-500 bg-purple-500/10',
    document_updated: 'text-orange-500 bg-orange-500/10',
    status_changed: 'text-yellow-500 bg-yellow-500/10',
};

interface ActivityTimelineProps {
    activities: ActivityItem[];
}

export const ActivityTimeline = ({ activities }: ActivityTimelineProps) => {
    return (
        <div className="bg-white border border-border rounded-xl p-6 shadow-sm">
            <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-bold text-text">Recent Activity</h3>
                <button className="text-sm text-primary font-medium hover:underline">View All</button>
            </div>
            <div className="space-y-6">
                {activities.map((activity, index) => {
                    const Icon = activityIcons[activity.type];
                    return (
                        <div key={activity.id} className="flex gap-4 relative group">
                            {/* Timeline line */}
                            {index < activities.length - 1 && (
                                <div className="absolute left-[18px] top-10 w-px h-full bg-gray-100 group-hover:bg-gray-200 transition-colors" />
                            )}

                            {/* Icon */}
                            <div className={clsx(
                                "w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 z-10 ring-4 ring-white",
                                activityColors[activity.type]
                            )}>
                                <Icon className="w-4 h-4" />
                            </div>

                            {/* Content */}
                            <div className="flex-1 min-w-0 pt-1">
                                <div className="flex items-start justify-between gap-4 mb-1">
                                    <div className="flex items-center gap-2 min-w-0">
                                        <span className="text-sm font-bold text-text truncate">
                                            {activity.user.name}
                                        </span>
                                        <span className="text-xs text-muted whitespace-nowrap">• {activity.timestamp}</span>
                                    </div>
                                </div>
                                <p className="text-sm text-gray-600 mb-2">
                                    {activity.description}
                                </p>
                                {activity.target && (
                                    <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-gray-50 border border-gray-100 rounded-lg text-xs hover:bg-gray-100 transition-colors cursor-pointer">
                                        <span className="text-muted font-medium uppercase tracking-wider text-[10px]">{activity.target.type}</span>
                                        <span className="font-semibold text-text">{activity.target.name}</span>
                                    </div>
                                )}
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    );
};
