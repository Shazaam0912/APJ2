import { Target, ChevronRight, Clock, Flag } from 'lucide-react';
import type { Task } from '../../context/DataContext';
import { useState } from 'react';
import { FocusDetailModal } from './FocusDetailModal';

interface FocusWidgetProps {
    tasks: Task[];
}

export const FocusWidget = ({ tasks }: FocusWidgetProps) => {
    const [showDetailModal, setShowDetailModal] = useState(false);

    // Filter for high priority and due soon tasks
    const priorityTasks = tasks
        .filter(t => t.priority === 'high' || t.priority === 'medium')
        .sort((a, b) => {
            if (a.priority === 'high' && b.priority !== 'high') return -1;
            if (b.priority === 'high' && a.priority !== 'high') return 1;
            return 0;
        })
        .slice(0, 3);

    const priorityColor = (priority: string) => {
        switch (priority) {
            case 'high': return 'bg-red-500';
            case 'medium': return 'bg-yellow-500';
            case 'low': return 'bg-green-500';
            default: return 'bg-gray-500';
        }
    };

    const priorityLabel = (priority: string) => {
        return priority.charAt(0).toUpperCase() + priority.slice(1);
    };

    return (
        <>
            <div className="bg-gradient-to-br from-primary to-primary/80 rounded-xl shadow-lg text-white">
                <div className="p-6 border-b border-white/10">
                    <div className="flex items-center gap-2">
                        <Target className="w-5 h-5" />
                        <h3 className="text-lg font-semibold">Today's Focus</h3>
                    </div>
                    <p className="text-sm text-white/80 mt-1">Your top priority tasks</p>
                </div>
                <div className="p-6">
                    <div className="space-y-3">
                        {priorityTasks.length > 0 ? priorityTasks.map((task) => (
                            <div
                                key={task.id}
                                className="bg-white/10 backdrop-blur-sm rounded-lg p-4 hover:bg-white/20 transition-all cursor-pointer group"
                            >
                                <div className="flex items-start justify-between gap-3">
                                    <div className="flex-1 min-w-0">
                                        <div className="flex items-center gap-2 mb-2">
                                            <div className={`w-2 h-2 rounded-full ${priorityColor(task.priority)}`}></div>
                                            <span className="text-xs font-medium text-white/70">Priority Task</span>
                                        </div>
                                        <p className="text-sm font-medium text-white mb-2 line-clamp-2">
                                            {task.content}
                                        </p>
                                        <div className="flex items-center gap-3 text-xs text-white/60">
                                            <span className={`px-2 py-0.5 rounded-full ${task.priority === 'high' ? 'bg-red-500/20 text-red-200' :
                                                task.priority === 'medium' ? 'bg-yellow-500/20 text-yellow-200' :
                                                    'bg-green-500/20 text-green-200'
                                                }`}>
                                                {priorityLabel(task.priority)}
                                            </span>
                                            {task.dueDate && (
                                                <div className="flex items-center gap-1">
                                                    <Clock className="w-3 h-3" />
                                                    <span>{new Date(task.dueDate).toLocaleDateString()}</span>
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                    <ChevronRight className="w-5 h-5 text-white/40 group-hover:text-white/80 transition-colors flex-shrink-0" />
                                </div>
                            </div>
                        )) : (
                            <div className="text-center py-8 text-white/60">
                                <Flag className="w-8 h-8 mx-auto mb-2 opacity-50" />
                                <p className="text-sm">No priority tasks at the moment</p>
                            </div>
                        )}
                    </div>
                    <button
                        onClick={() => setShowDetailModal(true)}
                        className="w-full mt-4 py-2 text-sm font-medium text-white/90 hover:text-white transition-colors flex items-center justify-center gap-2 hover:gap-3"
                    >
                        View all tasks
                        <ChevronRight className="w-4 h-4" />
                    </button>
                </div>
            </div>

            <FocusDetailModal
                isOpen={showDetailModal}
                onClose={() => setShowDetailModal(false)}
                tasks={tasks}
            />
        </>
    );
};
