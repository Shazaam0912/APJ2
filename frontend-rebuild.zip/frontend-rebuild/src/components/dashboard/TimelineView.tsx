import { useData } from '../../context/DataContext';
import clsx from 'clsx';

export const TimelineView = () => {
    const { data } = useData();
    const allTasks = Object.values(data.tasks).filter(t => !t.archived);

    // Group tasks by month
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const currentMonth = new Date().getMonth();
    const visibleMonths = months.slice(currentMonth, currentMonth + 6);

    const getTaskColor = (status: string) => {
        switch (status) {
            case 'Done': return 'bg-green-500';
            case 'In Progress': return 'bg-blue-500';
            case 'To Do': return 'bg-gray-400';
            default: return 'bg-purple-500';
        }
    };

    const getPriorityColor = (priority: string) => {
        switch (priority?.toLowerCase()) {
            case 'urgent':
            case 'high': return 'border-l-4 border-red-500';
            case 'medium': return 'border-l-4 border-yellow-500';
            case 'low': return 'border-l-4 border-green-500';
            default: return 'border-l-4 border-gray-300';
        }
    };

    // Calculate task position based on dates
    const getTaskPosition = (task: any) => {
        // Mock positioning - in real app, calculate based on actual dates
        const randomStart = Math.floor(Math.random() * 50);
        const randomWidth = Math.floor(Math.random() * 30) + 15;
        return { left: `${randomStart}%`, width: `${randomWidth}%` };
    };

    return (
        <div className="h-full flex flex-col bg-white">
            {/* Timeline Header */}
            <div className="flex border-b border-gray-200 bg-gray-50 sticky top-0 z-10">
                <div className="w-64 p-4 border-r border-gray-200 font-semibold text-gray-700">
                    Task
                </div>
                <div className="flex-1 flex">
                    {visibleMonths.map((month, idx) => (
                        <div key={idx} className="flex-1 p-4 border-r border-gray-200 last:border-r-0 text-center">
                            <div className="font-semibold text-gray-700">{month}</div>
                            <div className="text-xs text-gray-500 mt-1">2025</div>
                        </div>
                    ))}
                </div>
            </div>

            {/* Timeline Content */}
            <div className="flex-1 overflow-y-auto">
                {allTasks.slice(0, 15).map((task, index) => {
                    const position = getTaskPosition(task);

                    return (
                        <div key={task.id} className={clsx(
                            "flex border-b border-gray-100 hover:bg-gray-50 transition-colors",
                            index % 2 === 0 ? "bg-white" : "bg-gray-50/50"
                        )}>
                            {/* Task Name */}
                            <div className="w-64 p-4 border-r border-gray-200">
                                <div className={clsx("font-medium text-sm text-gray-900 truncate", getPriorityColor(task.priority))}>
                                    <div className="pl-3">{task.content}</div>
                                </div>
                                <div className="flex items-center gap-2 mt-2 pl-3">
                                    {task.assignee && (
                                        <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-xs font-semibold text-primary">
                                            {task.assignee}
                                        </div>
                                    )}
                                    <span className={clsx(
                                        "text-xs px-2 py-0.5 rounded-full font-medium",
                                        task.priority === 'high' || task.priority === 'urgent' ? 'bg-red-100 text-red-700' :
                                            task.priority === 'medium' ? 'bg-yellow-100 text-yellow-700' :
                                                'bg-green-100 text-green-700'
                                    )}>
                                        {task.priority || 'Low'}
                                    </span>
                                </div>
                            </div>

                            {/* Timeline Bar */}
                            <div className="flex-1 p-4 relative">
                                <div
                                    className={clsx(
                                        "absolute top-1/2 -translate-y-1/2 rounded-lg shadow-sm hover:shadow-md transition-all cursor-pointer h-8 flex items-center px-3",
                                        getTaskColor(task.status)
                                    )}
                                    style={position}
                                >
                                    <span className="text-white text-xs font-semibold truncate">
                                        {task.content}
                                    </span>
                                </div>
                            </div>
                        </div>
                    );
                })}
            </div>

            {/* Legend */}
            <div className="border-t border-gray-200 p-4 bg-gray-50">
                <div className="flex items-center gap-6 text-sm">
                    <div className="flex items-center gap-2">
                        <div className="w-4 h-4 rounded bg-gray-400"></div>
                        <span className="text-gray-600">To Do</span>
                    </div>
                    <div className="flex items-center gap-2">
                        <div className="w-4 h-4 rounded bg-blue-500"></div>
                        <span className="text-gray-600">In Progress</span>
                    </div>
                    <div className="flex items-center gap-2">
                        <div className="w-4 h-4 rounded bg-green-500"></div>
                        <span className="text-gray-600">Completed</span>
                    </div>
                    <div className="flex items-center gap-2">
                        <div className="w-4 h-4 rounded bg-purple-500"></div>
                        <span className="text-gray-600">Under Review</span>
                    </div>
                </div>
            </div>
        </div>
    );
};
