import { useState } from 'react';
import { useData } from '../../context/DataContext';
import { ArrowUpDown, Edit2, Trash2, CheckCircle2 } from 'lucide-react';
import clsx from 'clsx';

export const SpreadsheetView = () => {
    const { data, updateTask, deleteTask } = useData();
    const [sortField, setSortField] = useState<string>('');
    const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
    const [selectedRows, setSelectedRows] = useState<Set<string>>(new Set());

    const allTasks = Object.values(data.tasks).filter(t => !t.archived);

    const handleSort = (field: string) => {
        if (sortField === field) {
            setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
        } else {
            setSortField(field);
            setSortDirection('asc');
        }
    };

    const toggleRowSelection = (id: string) => {
        const newSelection = new Set(selectedRows);
        if (newSelection.has(id)) {
            newSelection.delete(id);
        } else {
            newSelection.add(id);
        }
        setSelectedRows(newSelection);
    };

    const toggleAllRows = () => {
        if (selectedRows.size === allTasks.length) {
            setSelectedRows(new Set());
        } else {
            setSelectedRows(new Set(allTasks.map(t => t.id)));
        }
    };

    const getPriorityBadge = (priority: string) => {
        const colors: any = {
            urgent: 'bg-red-100 text-red-700 border-red-200',
            high: 'bg-red-100 text-red-700 border-red-200',
            medium: 'bg-yellow-100 text-yellow-700 border-yellow-200',
            low: 'bg-green-100 text-green-700 border-green-200',
        };
        return colors[priority?.toLowerCase()] || 'bg-gray-100 text-gray-700 border-gray-200';
    };

    const getStatusBadge = (status: string) => {
        const colors: any = {
            'To Do': 'bg-gray-100 text-gray-700',
            'In Progress': 'bg-blue-100 text-blue-700',
            'Done': 'bg-green-100 text-green-700',
            'Under Review': 'bg-purple-100 text-purple-700',
        };
        return colors[status] || 'bg-gray-100 text-gray-700';
    };

    return (
        <div className="h-full flex flex-col bg-white">
            {/* Bulk Actions Bar */}
            {selectedRows.size > 0 && (
                <div className="bg-primary/10 border-b border-primary/20 px-6 py-3 flex items-center gap-4">
                    <span className="text-sm font-semibold text-primary">
                        {selectedRows.size} task{selectedRows.size > 1 ? 's' : ''} selected
                    </span>
                    <button className="text-sm px-3 py-1.5 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors font-medium">
                        Mark Complete
                    </button>
                    <button className="text-sm px-3 py-1.5 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors font-medium">
                        Change Status
                    </button>
                    <button className="text-sm px-3 py-1.5 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors font-medium text-red-600">
                        Delete
                    </button>
                </div>
            )}

            {/* Spreadsheet Header */}
            <div className="border-b border-gray-200 bg-gray-50 sticky top-0 z-10">
                <div className="flex text-sm font-semibold text-gray-700">
                    <div className="w-12 p-4 border-r border-gray-200 flex items-center justify-center">
                        <input
                            type="checkbox"
                            checked={selectedRows.size === allTasks.length && allTasks.length > 0}
                            onChange={toggleAllRows}
                            className="w-4 h-4 rounded border-gray-300 text-primary focus:ring-primary"
                        />
                    </div>
                    <div className="flex-1 p-4 border-r border-gray-200 cursor-pointer hover:bg-gray-100 transition-colors" onClick={() => handleSort('content')}>
                        <div className="flex items-center gap-2">
                            Task Name
                            <ArrowUpDown className="w-4 h-4" />
                        </div>
                    </div>
                    <div className="w-40 p-4 border-r border-gray-200 cursor-pointer hover:bg-gray-100 transition-colors" onClick={() => handleSort('status')}>
                        <div className="flex items-center gap-2">
                            Status
                            <ArrowUpDown className="w-4 h-4" />
                        </div>
                    </div>
                    <div className="w-32 p-4 border-r border-gray-200 cursor-pointer hover:bg-gray-100 transition-colors" onClick={() => handleSort('priority')}>
                        <div className="flex items-center gap-2">
                            Priority
                            <ArrowUpDown className="w-4 h-4" />
                        </div>
                    </div>
                    <div className="w-32 p-4 border-r border-gray-200">Assignee</div>
                    <div className="w-36 p-4 border-r border-gray-200 cursor-pointer hover:bg-gray-100 transition-colors" onClick={() => handleSort('dueDate')}>
                        <div className="flex items-center gap-2">
                            Due Date
                            <ArrowUpDown className="w-4 h-4" />
                        </div>
                    </div>
                    <div className="w-32 p-4 text-center">Actions</div>
                </div>
            </div>

            {/* Spreadsheet Rows */}
            <div className="flex-1 overflow-y-auto">
                {allTasks.map((task, index) => (
                    <div
                        key={task.id}
                        className={clsx(
                            "flex text-sm border-b border-gray-100 hover:bg-gray-50 transition-colors",
                            selectedRows.has(task.id) && "bg-primary/5",
                            index % 2 === 0 ? "bg-white" : "bg-gray-50/30"
                        )}
                    >
                        <div className="w-12 p-4 border-r border-gray-100 flex items-center justify-center">
                            <input
                                type="checkbox"
                                checked={selectedRows.has(task.id)}
                                onChange={() => toggleRowSelection(task.id)}
                                className="w-4 h-4 rounded border-gray-300 text-primary focus:ring-primary"
                            />
                        </div>
                        <div className="flex-1 p-4 border-r border-gray-100">
                            <div className="font-medium text-gray-900">{task.content}</div>
                            {task.description && (
                                <div className="text-xs text-gray-500 mt-1 truncate">{task.description}</div>
                            )}
                        </div>
                        <div className="w-40 p-4 border-r border-gray-100">
                            <span className={clsx("px-3 py-1 rounded-full text-xs font-semibold", getStatusBadge(task.status))}>
                                {task.status}
                            </span>
                        </div>
                        <div className="w-32 p-4 border-r border-gray-100">
                            <span className={clsx("px-2 py-1 rounded-lg text-xs font-semibold border", getPriorityBadge(task.priority))}>
                                {task.priority || 'Low'}
                            </span>
                        </div>
                        <div className="w-32 p-4 border-r border-gray-100">
                            {task.assignee && (
                                <div className="flex items-center gap-2">
                                    <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-xs font-semibold text-primary">
                                        {task.assignee}
                                    </div>
                                    <span className="text-gray-700">{task.assignee}</span>
                                </div>
                            )}
                        </div>
                        <div className="w-36 p-4 border-r border-gray-100 text-gray-600">
                            {task.dueDate || '-'}
                        </div>
                        <div className="w-32 p-4 flex items-center justify-center gap-2">
                            <button
                                onClick={() => updateTask(task.id, { completed: !task.completed })}
                                className="p-1.5 hover:bg-green-100 rounded-lg transition-colors text-green-600"
                                title="Mark complete"
                            >
                                <CheckCircle2 className="w-4 h-4" />
                            </button>
                            <button
                                className="p-1.5 hover:bg-blue-100 rounded-lg transition-colors text-blue-600"
                                title="Edit"
                            >
                                <Edit2 className="w-4 h-4" />
                            </button>
                            <button
                                onClick={() => deleteTask(task.id)}
                                className="p-1.5 hover:bg-red-100 rounded-lg transition-colors text-red-600"
                                title="Delete"
                            >
                                <Trash2 className="w-4 h-4" />
                            </button>
                        </div>
                    </div>
                ))}
            </div>

            {/* Footer Stats */}
            <div className="border-t border-gray-200 bg-gray-50 px-6 py-3 flex items-center justify-between text-sm text-gray-600">
                <div>Total: {allTasks.length} tasks</div>
                <div>Showing all tasks</div>
            </div>
        </div>
    );
};
