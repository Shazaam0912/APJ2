import React from 'react';
import clsx from 'clsx';

interface BadgeProps extends React.HTMLAttributes<HTMLDivElement> {
    variant?: 'default' | 'secondary' | 'outline' | 'destructive' | 'success' | 'warning' | 'info';
    pulse?: boolean;
    size?: 'sm' | 'md' | 'lg';
}

export const Badge = ({ className, variant = 'default', pulse = false, size = 'md', ...props }: BadgeProps) => {
    const variants = {
        default: 'bg-primary-100 text-primary-700 border-primary-200',
        secondary: 'bg-gray-100 text-gray-700 border-gray-200',
        outline: 'text-gray-700 border-gray-300 bg-white',
        destructive: 'bg-danger-50 text-danger-600 border-danger-200',
        success: 'bg-success-50 text-success-700 border-success-200',
        warning: 'bg-warning-50 text-warning-700 border-warning-200',
        info: 'bg-blue-50 text-blue-700 border-blue-200',
    };

    const sizes = {
        sm: 'px-2 py-0.5 text-[10px]',
        md: 'px-2.5 py-0.5 text-xs',
        lg: 'px-3 py-1 text-sm',
    };

    return (
        <div className={clsx(
            "inline-flex items-center rounded-full border font-semibold transition-all",
            variants[variant],
            sizes[size],
            pulse && 'animate-pulse-slow',
            className
        )} {...props} />
    );
};

