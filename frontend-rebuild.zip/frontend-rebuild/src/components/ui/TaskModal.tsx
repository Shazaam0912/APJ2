import { useState, useEffect } from 'react';
import { X, Calendar, User, Flag, AlignLeft } from 'lucide-react';
import { useData, type Task } from '../../context/DataContext';

interface TaskModalProps {
    isOpen: boolean;
    onClose: () => void;
    task?: Task;
    columnId?: string;
}

export const TaskModal = ({ isOpen, onClose, task, columnId }: TaskModalProps) => {
    const { addTask, updateTask, deleteTask } = useData();
    const [formData, setFormData] = useState<Partial<Task>>({
        content: '',
        description: '',
        priority: 'medium',
        assignee: '',
        dueDate: '',
    });

    useEffect(() => {
        if (task) {
            setFormData(task);
        } else {
            setFormData({
                content: '',
                description: '',
                priority: 'medium',
                assignee: '',
                dueDate: '',
            });
        }
    }, [task, isOpen]);

    if (!isOpen) return null;

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (task) {
            updateTask({ ...task, ...formData } as Task);
        } else if (columnId) {
            addTask(columnId, formData as Omit<Task, 'id' | 'status'>);
        }
        onClose();
    };

    const handleDelete = () => {
        if (task) {
            deleteTask(task.id);
            onClose();
        }
    };

    return (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <div className="bg-surface w-full max-w-2xl rounded-xl border border-border shadow-2xl overflow-hidden">
                <form onSubmit={handleSubmit}>
                    <div className="p-6 border-b border-border flex items-center justify-between">
                        <h2 className="text-xl font-semibold text-white">
                            {task ? 'Edit Task' : 'New Task'}
                        </h2>
                        <div className="flex items-center gap-2">
                            {task && (
                                <button
                                    type="button"
                                    onClick={handleDelete}
                                    className="text-red-500 hover:bg-red-500/10 px-3 py-1.5 rounded-lg text-sm transition-colors"
                                >
                                    Delete
                                </button>
                            )}
                            <button
                                type="button"
                                onClick={onClose}
                                className="text-muted hover:text-white p-1 rounded-lg hover:bg-hover transition-colors"
                            >
                                <X className="w-5 h-5" />
                            </button>
                        </div>
                    </div>

                    <div className="p-6 space-y-6">
                        <input
                            type="text"
                            placeholder="Task title"
                            value={formData.content}
                            onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                            className="w-full bg-transparent text-2xl font-bold text-white placeholder-muted border-none focus:ring-0 p-0"
                            required
                        />

                        <div className="grid grid-cols-2 gap-6">
                            <div className="space-y-4">
                                <div className="flex items-center gap-3 text-sm">
                                    <div className="w-8 flex justify-center text-muted"><Flag className="w-4 h-4" /></div>
                                    <span className="text-muted w-20">Priority</span>
                                    <select
                                        value={formData.priority}
                                        onChange={(e) => setFormData({ ...formData, priority: e.target.value as any })}
                                        className="bg-background border border-border rounded px-2 py-1 text-white text-sm focus:border-primary outline-none"
                                    >
                                        <option value="low">Low</option>
                                        <option value="medium">Medium</option>
                                        <option value="high">High</option>
                                    </select>
                                </div>

                                <div className="flex items-center gap-3 text-sm">
                                    <div className="w-8 flex justify-center text-muted"><User className="w-4 h-4" /></div>
                                    <span className="text-muted w-20">Assignee</span>
                                    <input
                                        type="text"
                                        placeholder="Unassigned"
                                        value={formData.assignee}
                                        onChange={(e) => setFormData({ ...formData, assignee: e.target.value })}
                                        className="bg-transparent text-white placeholder-muted focus:ring-0 border-none p-0 text-sm"
                                    />
                                </div>

                                <div className="flex items-center gap-3 text-sm">
                                    <div className="w-8 flex justify-center text-muted"><Calendar className="w-4 h-4" /></div>
                                    <span className="text-muted w-20">Due Date</span>
                                    <input
                                        type="text"
                                        placeholder="No date"
                                        value={formData.dueDate}
                                        onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
                                        className="bg-transparent text-white placeholder-muted focus:ring-0 border-none p-0 text-sm"
                                    />
                                </div>
                            </div>
                        </div>

                        <div className="space-y-2">
                            <div className="flex items-center gap-2 text-muted">
                                <AlignLeft className="w-4 h-4" />
                                <span className="text-sm font-medium">Description</span>
                            </div>
                            <textarea
                                placeholder="Add a more detailed description..."
                                value={formData.description}
                                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                                className="w-full h-32 bg-background rounded-lg border border-border p-3 text-white placeholder-muted focus:border-primary outline-none resize-none text-sm"
                            />
                        </div>
                    </div>

                    <div className="p-6 border-t border-border flex justify-end gap-3">
                        <button
                            type="button"
                            onClick={onClose}
                            className="px-4 py-2 text-white hover:bg-hover rounded-lg transition-colors"
                        >
                            Cancel
                        </button>
                        <button
                            type="submit"
                            className="px-4 py-2 bg-primary hover:bg-blue-600 text-white rounded-lg font-medium transition-colors"
                        >
                            {task ? 'Save Changes' : 'Create Task'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};
