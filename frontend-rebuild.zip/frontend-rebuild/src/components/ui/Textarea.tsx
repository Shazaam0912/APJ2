import React from 'react';
import clsx from 'clsx';

interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
    label?: string;
    error?: string;
    helperText?: string;
    fullWidth?: boolean;
}

export const Textarea = React.forwardRef<HTMLTextAreaElement, TextareaProps>(
    ({ className, label, error, helperText, fullWidth, ...props }, ref) => {
        return (
            <div className={clsx("flex flex-col gap-1.5", fullWidth && "w-full")}>
                {label && (
                    <label className="text-sm font-semibold text-gray-700">
                        {label}
                        {props.required && <span className="text-danger-500 ml-1">*</span>}
                    </label>
                )}

                <textarea
                    ref={ref}
                    className={clsx(
                        "w-full px-4 py-2.5 bg-white border rounded-xl text-gray-900 placeholder-gray-400",
                        "focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary",
                        "transition-all duration-200 resize-none",
                        "disabled:opacity-50 disabled:cursor-not-allowed disabled:bg-gray-50",
                        error ? "border-danger-300 focus:ring-danger/50 focus:border-danger" : "border-gray-300",
                        className
                    )}
                    {...props}
                />

                {(error || helperText) && (
                    <p className={clsx(
                        "text-xs",
                        error ? "text-danger-600" : "text-gray-500"
                    )}>
                        {error || helperText}
                    </p>
                )}
            </div>
        );
    }
);

Textarea.displayName = 'Textarea';
