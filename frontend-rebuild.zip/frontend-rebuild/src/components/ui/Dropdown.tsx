import React, { useRef, useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import clsx from 'clsx';

interface DropdownProps {
    trigger: React.ReactElement;
    children: React.ReactNode;
    align?: 'start' | 'center' | 'end';
    side?: 'top' | 'bottom';
    className?: string;
}

export const Dropdown = ({ trigger, children, align = 'start', side = 'bottom', className }: DropdownProps) => {
    const [isOpen, setIsOpen] = useState(false);
    const [position, setPosition] = useState({ x: 0, y: 0 });
    const triggerRef = useRef<HTMLDivElement>(null);
    const contentRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (
                contentRef.current &&
                !contentRef.current.contains(event.target as Node) &&
                triggerRef.current &&
                !triggerRef.current.contains(event.target as Node)
            ) {
                setIsOpen(false);
            }
        };

        const handleEscape = (event: KeyboardEvent) => {
            if (event.key === 'Escape') {
                setIsOpen(false);
            }
        };

        if (isOpen) {
            document.addEventListener('mousedown', handleClickOutside);
            document.addEventListener('keydown', handleEscape);
        }

        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
            document.removeEventListener('keydown', handleEscape);
        };
    }, [isOpen]);

    useEffect(() => {
        if (isOpen && triggerRef.current && contentRef.current) {
            const triggerRect = triggerRef.current.getBoundingClientRect();
            const contentRect = contentRef.current.getBoundingClientRect();

            let x = 0;
            let y = 0;

            // Vertical positioning
            if (side === 'bottom') {
                y = triggerRect.bottom + 4;
            } else {
                y = triggerRect.top - contentRect.height - 4;
            }

            // Horizontal positioning
            if (align === 'start') {
                x = triggerRect.left;
            } else if (align === 'end') {
                x = triggerRect.right - contentRect.width;
            } else {
                x = triggerRect.left + (triggerRect.width - contentRect.width) / 2;
            }

            // Ensure dropdown stays in viewport
            const padding = 8;
            if (x + contentRect.width > window.innerWidth - padding) {
                x = window.innerWidth - contentRect.width - padding;
            }
            if (x < padding) {
                x = padding;
            }

            setPosition({ x, y });
        }
    }, [isOpen, align, side]);

    return (
        <>
            <div
                ref={triggerRef}
                onClick={() => setIsOpen(!isOpen)}
                className="inline-block cursor-pointer"
            >
                {trigger}
            </div>
            {isOpen && createPortal(
                <div
                    ref={contentRef}
                    className={clsx(
                        "fixed z-50 bg-surface border border-border rounded-lg shadow-lg py-1 min-w-[200px] animate-in fade-in-0 zoom-in-95",
                        className
                    )}
                    style={{
                        left: `${position.x}px`,
                        top: `${position.y}px`,
                    }}
                >
                    {children}
                </div>,
                document.body
            )}
        </>
    );
};

interface DropdownItemProps {
    icon?: React.ReactNode;
    children: React.ReactNode;
    onClick?: () => void;
    variant?: 'default' | 'danger';
    disabled?: boolean;
}

export const DropdownItem = ({ icon, children, onClick, variant = 'default', disabled }: DropdownItemProps) => {
    return (
        <button
            onClick={onClick}
            disabled={disabled}
            className={clsx(
                "w-full flex items-center gap-3 px-3 py-2 text-sm transition-colors",
                variant === 'default' && "text-white hover:bg-hover",
                variant === 'danger' && "text-red-500 hover:bg-red-500/10",
                disabled && "opacity-50 cursor-not-allowed"
            )}
        >
            {icon && <span className="w-4 h-4">{icon}</span>}
            <span>{children}</span>
        </button>
    );
};

export const DropdownSeparator = () => {
    return <div className="h-px bg-border my-1" />;
};

export const DropdownLabel = ({ children }: { children: React.ReactNode }) => {
    return <div className="px-3 py-2 text-xs font-semibold text-muted uppercase tracking-wider">{children}</div>;
};
