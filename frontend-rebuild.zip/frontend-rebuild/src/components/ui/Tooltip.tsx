import React, { useRef, useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import clsx from 'clsx';

interface TooltipProps {
    content: string;
    children: React.ReactElement;
    side?: 'top' | 'bottom' | 'left' | 'right';
    delay?: number;
}

export const Tooltip = ({ content, children, side = 'right', delay = 200 }: TooltipProps) => {
    const [isVisible, setIsVisible] = useState(false);
    const [position, setPosition] = useState({ x: 0, y: 0 });
    const triggerRef = useRef<HTMLDivElement>(null);
    const timeoutRef = useRef<number | undefined>(undefined);

    const handleMouseEnter = () => {
        timeoutRef.current = setTimeout(() => {
            if (triggerRef.current) {
                const rect = triggerRef.current.getBoundingClientRect();
                let x = 0, y = 0;

                switch (side) {
                    case 'right':
                        x = rect.right + 8;
                        y = rect.top + rect.height / 2;
                        break;
                    case 'left':
                        x = rect.left - 8;
                        y = rect.top + rect.height / 2;
                        break;
                    case 'top':
                        x = rect.left + rect.width / 2;
                        y = rect.top - 8;
                        break;
                    case 'bottom':
                        x = rect.left + rect.width / 2;
                        y = rect.bottom + 8;
                        break;
                }

                setPosition({ x, y });
                setIsVisible(true);
            }
        }, delay);
    };

    const handleMouseLeave = () => {
        if (timeoutRef.current) {
            clearTimeout(timeoutRef.current);
        }
        setIsVisible(false);
    };

    useEffect(() => {
        return () => {
            if (timeoutRef.current) {
                clearTimeout(timeoutRef.current);
            }
        };
    }, []);

    const sideStyles = {
        top: 'translate-x-[-50%] translate-y-[-100%]',
        bottom: 'translate-x-[-50%] translate-y-0',
        left: 'translate-x-[-100%] translate-y-[-50%]',
        right: 'translate-x-0 translate-y-[-50%]',
    };

    return (
        <>
            <div
                ref={triggerRef}
                onMouseEnter={handleMouseEnter}
                onMouseLeave={handleMouseLeave}
                className="inline-block"
            >
                {children}
            </div>
            {isVisible && createPortal(
                <div
                    className={clsx(
                        "fixed z-50 px-2 py-1 text-xs font-medium text-white bg-gray-900 rounded shadow-lg pointer-events-none whitespace-nowrap",
                        sideStyles[side]
                    )}
                    style={{
                        left: `${position.x}px`,
                        top: `${position.y}px`,
                    }}
                >
                    {content}
                </div>,
                document.body
            )}
        </>
    );
};
