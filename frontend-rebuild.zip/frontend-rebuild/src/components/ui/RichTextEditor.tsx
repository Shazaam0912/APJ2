import { useState, useRef, type KeyboardEvent } from 'react';
import { Bold, Italic, List, Link as LinkIcon, Code } from 'lucide-react';

interface RichTextEditorProps {
    value: string;
    onChange: (value: string) => void;
    placeholder?: string;
    minRows?: number;
    maxRows?: number;
    onKeyDown?: (e: KeyboardEvent<HTMLTextAreaElement>) => void;
}

export const RichTextEditor = ({
    value,
    onChange,
    placeholder = 'Write something...',
    minRows = 3,
    maxRows = 10,
    onKeyDown
}: RichTextEditorProps) => {
    const [showPreview, setShowPreview] = useState(false);
    const textareaRef = useRef<HTMLTextAreaElement>(null);

    const insertMarkdown = (before: string, after: string = '') => {
        const textarea = textareaRef.current;
        if (!textarea) return;

        const start = textarea.selectionStart;
        const end = textarea.selectionEnd;
        const selectedText = value.substring(start, end);
        const newText = value.substring(0, start) + before + selectedText + after + value.substring(end);

        onChange(newText);

        // Set cursor position after insertion
        setTimeout(() => {
            const newCursorPos = start + before.length + selectedText.length;
            textarea.setSelectionRange(newCursorPos, newCursorPos);
            textarea.focus();
        }, 0);
    };

    const handleToolbarAction = (action: string) => {
        switch (action) {
            case 'bold':
                insertMarkdown('**', '**');
                break;
            case 'italic':
                insertMarkdown('*', '*');
                break;
            case 'list':
                insertMarkdown('- ');
                break;
            case 'link':
                insertMarkdown('[', '](url)');
                break;
            case 'code':
                insertMarkdown('`', '`');
                break;
        }
    };

    const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
        // Handle keyboard shortcuts
        if (e.metaKey || e.ctrlKey) {
            switch (e.key) {
                case 'b':
                    e.preventDefault();
                    insertMarkdown('**', '**');
                    break;
                case 'i':
                    e.preventDefault();
                    insertMarkdown('*', '*');
                    break;
                case 'k':
                    e.preventDefault();
                    insertMarkdown('[', '](url)');
                    break;
            }
        }

        // Call parent's onKeyDown if provided
        onKeyDown?.(e);
    };

    const renderPreview = (text: string) => {
        let html = text;

        // Bold
        html = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');

        // Italic
        html = html.replace(/\*(.*?)\*/g, '<em>$1</em>');

        // Code
        html = html.replace(/`(.*?)`/g, '<code class="px-1.5 py-0.5 bg-surface border border-border rounded text-sm">$1</code>');

        // Links
        html = html.replace(/\[(.*?)\]\((.*?)\)/g, '<a href="$2" class="text-primary hover:underline" target="_blank">$1</a>');

        // Lists
        html = html.replace(/^- (.*)$/gm, '<li class="ml-4">$1</li>');

        // Line breaks
        html = html.replace(/\n/g, '<br>');

        return html;
    };

    return (
        <div className="border border-border rounded-lg overflow-hidden bg-surface">
            {/* Toolbar */}
            <div className="flex items-center gap-1 px-2 py-2 border-b border-border bg-background/50">
                <button
                    type="button"
                    onClick={() => handleToolbarAction('bold')}
                    className="p-2 hover:bg-hover rounded transition-colors"
                    title="Bold (Cmd+B)"
                >
                    <Bold className="w-4 h-4 text-muted" />
                </button>
                <button
                    type="button"
                    onClick={() => handleToolbarAction('italic')}
                    className="p-2 hover:bg-hover rounded transition-colors"
                    title="Italic (Cmd+I)"
                >
                    <Italic className="w-4 h-4 text-muted" />
                </button>
                <button
                    type="button"
                    onClick={() => handleToolbarAction('list')}
                    className="p-2 hover:bg-hover rounded transition-colors"
                    title="List"
                >
                    <List className="w-4 h-4 text-muted" />
                </button>
                <button
                    type="button"
                    onClick={() => handleToolbarAction('link')}
                    className="p-2 hover:bg-hover rounded transition-colors"
                    title="Link (Cmd+K)"
                >
                    <LinkIcon className="w-4 h-4 text-muted" />
                </button>
                <button
                    type="button"
                    onClick={() => handleToolbarAction('code')}
                    className="p-2 hover:bg-hover rounded transition-colors"
                    title="Code"
                >
                    <Code className="w-4 h-4 text-muted" />
                </button>

                <div className="flex-1" />

                <button
                    type="button"
                    onClick={() => setShowPreview(!showPreview)}
                    className={`px-3 py-1 text-xs rounded transition-colors ${showPreview ? 'bg-primary text-white' : 'bg-hover text-muted'
                        }`}
                >
                    {showPreview ? 'Edit' : 'Preview'}
                </button>
            </div>

            {/* Editor/Preview */}
            {showPreview ? (
                <div
                    className="px-4 py-3 text-sm text-white min-h-[80px] prose prose-invert max-w-none"
                    dangerouslySetInnerHTML={{ __html: renderPreview(value) }}
                />
            ) : (
                <textarea
                    ref={textareaRef}
                    value={value}
                    onChange={(e) => onChange(e.target.value)}
                    onKeyDown={handleKeyDown}
                    placeholder={placeholder}
                    className="w-full px-4 py-3 bg-transparent text-sm text-white placeholder-muted resize-none focus:outline-none"
                    rows={minRows}
                    style={{ maxHeight: `${maxRows * 1.5}rem` }}
                />
            )}
        </div>
    );
};
