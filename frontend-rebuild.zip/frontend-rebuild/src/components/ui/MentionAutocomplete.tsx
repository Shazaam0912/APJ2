import { useState, useRef, useEffect, type KeyboardEvent } from 'react';
import type { TeamMember } from '../../context/DataContext';

interface MentionAutocompleteProps {
    value: string;
    cursorPosition: number;
    teamMembers: TeamMember[];
    onSelect: (member: TeamMember) => void;
    onClose: () => void;
}

export const MentionAutocomplete = ({
    value,
    cursorPosition,
    teamMembers,
    onSelect,
    onClose
}: MentionAutocompleteProps) => {
    const [selectedIndex, setSelectedIndex] = useState(0);
    const [mentionQuery, setMentionQuery] = useState('');
    const dropdownRef = useRef<HTMLDivElement>(null);

    // Detect @ mention and extract query
    useEffect(() => {
        const textBeforeCursor = value.substring(0, cursorPosition);
        const match = textBeforeCursor.match(/@(\w*)$/);

        if (match) {
            setMentionQuery(match[1].toLowerCase());
        } else {
            onClose();
        }
    }, [value, cursorPosition, onClose]);

    // Filter team members based on query
    const filteredMembers = teamMembers.filter(member =>
        member.name.toLowerCase().includes(mentionQuery) ||
        member.email?.toLowerCase().includes(mentionQuery)
    );

    // Reset selected index when filtered list changes
    useEffect(() => {
        setSelectedIndex(0);
    }, [mentionQuery]);

    // Handle keyboard navigation
    const handleKeyDown = (e: KeyboardEvent) => {
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            setSelectedIndex(prev => (prev + 1) % filteredMembers.length);
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            setSelectedIndex(prev => (prev - 1 + filteredMembers.length) % filteredMembers.length);
        } else if (e.key === 'Enter' && filteredMembers.length > 0) {
            e.preventDefault();
            onSelect(filteredMembers[selectedIndex]);
        } else if (e.key === 'Escape') {
            e.preventDefault();
            onClose();
        }
    };

    // Scroll selected item into view
    useEffect(() => {
        const selectedElement = dropdownRef.current?.querySelector(`[data-index="${selectedIndex}"]`);
        selectedElement?.scrollIntoView({ block: 'nearest' });
    }, [selectedIndex]);

    if (filteredMembers.length === 0) {
        return null;
    }

    return (
        <div
            ref={dropdownRef}
            className="absolute bottom-full left-0 right-0 mb-2 bg-surface border border-border rounded-lg shadow-2xl max-h-64 overflow-y-auto z-50"
            onKeyDown={handleKeyDown}
        >
            <div className="py-2">
                <div className="px-3 py-2 text-xs font-medium text-muted border-b border-border">
                    Mention someone
                </div>
                {filteredMembers.map((member, index) => (
                    <button
                        key={member.id}
                        data-index={index}
                        onClick={() => onSelect(member)}
                        className={`w-full px-4 py-3 text-left hover:bg-hover transition-colors flex items-center gap-3 ${index === selectedIndex ? 'bg-primary/10 border-l-2 border-primary' : ''
                            }`}
                    >
                        <div className="w-9 h-9 rounded-full bg-primary flex items-center justify-center text-sm font-semibold text-white flex-shrink-0">
                            {member.initials || member.name.split(' ').map(n => n[0]).join('')}
                        </div>
                        <div className="flex-1 min-w-0">
                            <div className="text-sm font-medium text-white truncate">
                                {member.name}
                            </div>
                            {member.email && (
                                <div className="text-xs text-muted truncate">
                                    {member.email}
                                </div>
                            )}
                        </div>
                    </button>
                ))}
            </div>
            <div className="px-4 py-2 text-xs text-muted border-t border-border bg-background/50">
                <span className="inline-flex items-center gap-2">
                    <kbd className="px-1.5 py-0.5 bg-surface border border-border rounded text-xs">↑↓</kbd>
                    Navigate
                    <kbd className="px-1.5 py-0.5 bg-surface border border-border rounded text-xs">Enter</kbd>
                    Select
                    <kbd className="px-1.5 py-0.5 bg-surface border border-border rounded text-xs">Esc</kbd>
                    Close
                </span>
            </div>
        </div>
    );
};
