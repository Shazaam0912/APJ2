import { useState } from 'react';
import clsx from 'clsx';

interface StoryPointPickerProps {
    value?: number;
    onChange: (points: number | undefined) => void;
    size?: 'sm' | 'md' | 'lg';
}

// Fibonacci sequence for story points
const STORY_POINTS = [0, 1, 2, 3, 5, 8, 13, 21];

export const StoryPointPicker = ({ value, onChange, size = 'md' }: StoryPointPickerProps) => {
    const [isOpen, setIsOpen] = useState(false);

    const handleSelect = (points: number) => {
        onChange(points === value ? undefined : points);
        setIsOpen(false);
    };

    const getSizeClasses = () => {
        switch (size) {
            case 'sm':
                return 'px-2 py-1 text-xs';
            case 'lg':
                return 'px-4 py-2 text-base';
            default:
                return 'px-3 py-1.5 text-sm';
        }
    };

    return (
        <div className="relative">
            <button
                onClick={() => setIsOpen(!isOpen)}
                className={clsx(
                    'flex items-center gap-2 bg-surface hover:bg-hover border border-border rounded-lg transition-colors font-medium',
                    getSizeClasses(),
                    value !== undefined ? 'text-primary border-primary/50' : 'text-muted'
                )}
            >
                {value !== undefined ? (
                    <>
                        <span className="text-primary font-bold">{value}</span>
                        <span className="text-muted text-xs">SP</span>
                    </>
                ) : (
                    <span>Set Points</span>
                )}
            </button>

            {isOpen && (
                <>
                    {/* Backdrop */}
                    <div
                        className="fixed inset-0 z-10"
                        onClick={() => setIsOpen(false)}
                    />

                    {/* Dropdown */}
                    <div className="absolute top-full left-0 mt-2 bg-surface border border-border rounded-lg shadow-xl z-20 p-2 min-w-[200px]">
                        <div className="text-xs text-muted font-semibold mb-2 px-2">
                            Story Points (Fibonacci)
                        </div>
                        <div className="grid grid-cols-4 gap-2">
                            {STORY_POINTS.map(points => (
                                <button
                                    key={points}
                                    onClick={() => handleSelect(points)}
                                    className={clsx(
                                        'h-10 rounded-lg font-bold transition-all',
                                        value === points
                                            ? 'bg-primary text-white scale-105'
                                            : 'bg-background hover:bg-hover text-muted hover:text-white'
                                    )}
                                >
                                    {points}
                                </button>
                            ))}
                        </div>
                        {value !== undefined && (
                            <button
                                onClick={() => {
                                    onChange(undefined);
                                    setIsOpen(false);
                                }}
                                className="w-full mt-2 px-3 py-2 text-xs text-red-400 hover:bg-red-500/10 rounded-lg transition-colors"
                            >
                                Clear Points
                            </button>
                        )}
                    </div>
                </>
            )}
        </div>
    );
};
