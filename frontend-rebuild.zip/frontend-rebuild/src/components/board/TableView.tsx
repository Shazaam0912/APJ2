import { useState } from 'react';
import clsx from 'clsx';
import type { Task } from '../../context/DataContext';
import { Badge } from '../ui/Badge';

interface TableViewProps {
    tasks: Task[];
}

export const TableView = ({ tasks }: TableViewProps) => {
    const [selectedTasks, setSelectedTasks] = useState<Set<string>>(new Set());

    const toggleTaskSelection = (taskId: string) => {
        const newSelection = new Set(selectedTasks);
        if (newSelection.has(taskId)) {
            newSelection.delete(taskId);
        } else {
            newSelection.add(taskId);
        }
        setSelectedTasks(newSelection);
    };

    const toggleAllTasks = () => {
        if (selectedTasks.size === tasks.length) {
            setSelectedTasks(new Set());
        } else {
            setSelectedTasks(new Set(tasks.map(t => t.id)));
        }
    };

    const getPriorityVariant = (priority: string) => {
        switch (priority) {
            case 'high': return 'destructive';
            case 'medium': return 'warning';
            default: return 'default';
        }
    };

    return (
        <div className="flex-1 overflow-auto">
            <table className="w-full">
                <thead className="bg-surface sticky top-0 border-b border-border">
                    <tr>
                        <th className="w-12 px-4 py-3">
                            <input
                                type="checkbox"
                                checked={selectedTasks.size === tasks.length && tasks.length > 0}
                                onChange={toggleAllTasks}
                                className="w-4 h-4 rounded border-border bg-background"
                            />
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-muted uppercase tracking-wider">Task</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-muted uppercase tracking-wider">Status</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-muted uppercase tracking-wider">Priority</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-muted uppercase tracking-wider">Assignee</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-muted uppercase tracking-wider">Due Date</th>
                        <th className="px-6 py-3 text-center text-xs font-medium text-muted uppercase tracking-wider">Sub-tasks</th>
                        <th className="px-6 py-3 text-center text-xs font-medium text-muted uppercase tracking-wider">Comments</th>
                        <th className="px-6 py-3 text-center text-xs font-medium text-muted uppercase tracking-wider">Files</th>
                        <th className="px-6 py-3 text-center text-xs font-medium text-muted uppercase tracking-wider">Time</th>
                        <th className="px-6 py-3 text-right text-xs font-medium text-muted uppercase tracking-wider">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {tasks.map((task) => (
                        <tr
                            key={task.id}
                            className={clsx(
                                'border-b border-border hover:bg-hover transition-colors cursor-pointer',
                                selectedTasks.has(task.id) && 'bg-primary/5'
                            )}
                            onClick={() => toggleTaskSelection(task.id)}
                        >
                            <td className="px-4 py-3">
                                <input
                                    type="checkbox"
                                    checked={selectedTasks.has(task.id)}
                                    onChange={() => toggleTaskSelection(task.id)}
                                    className="w-4 h-4 rounded border-border bg-background"
                                    onClick={(e) => e.stopPropagation()}
                                />
                            </td>
                            <td className="px-4 py-3">
                                <div>
                                    <p className="text-sm font-medium text-white">{task.content}</p>
                                    {task.description && (
                                        <p className="text-xs text-muted mt-1">{task.description}</p>
                                    )}
                                </div>
                            </td>
                            <td className="px-4 py-3">
                                <span className="text-sm text-muted capitalize">
                                    {task.status.replace('col-', '').replace('1', 'To Do').replace('2', 'In Progress').replace('3', 'Done')}
                                </span>
                            </td>
                            <td className="px-4 py-3">
                                <Badge variant={getPriorityVariant(task.priority)}>
                                    {task.priority}
                                </Badge>
                            </td>
                            <td className="px-4 py-3">
                                {task.assignee && (
                                    <div className="flex items-center gap-2">
                                        <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center text-xs font-medium text-white">
                                            {task.assignee}
                                        </div>
                                        <span className="text-sm text-white">{task.assignee}</span>
                                    </div>
                                )}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-muted">
                                {task.dueDate || '-'}
                            </td>

                            {/* Sub-tasks */}
                            <td className="px-6 py-4 whitespace-nowrap text-center">
                                {task.subTasks.length > 0 ? (
                                    <span className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-primary/10 text-primary">
                                        {task.subTasks.length}
                                    </span>
                                ) : (
                                    <span className="text-muted text-xs">-</span>
                                )}
                            </td>

                            {/* Comments */}
                            <td className="px-6 py-4 whitespace-nowrap text-center">
                                {task.comments.length > 0 ? (
                                    <span className="inline-flex items-center gap-1 text-sm text-muted">
                                        {task.comments.length}
                                    </span>
                                ) : (
                                    <span className="text-muted text-xs">-</span>
                                )}
                            </td>

                            {/* Files */}
                            <td className="px-6 py-4 whitespace-nowrap text-center">
                                {task.attachments.length > 0 ? (
                                    <span className="inline-flex items-center gap-1 text-sm text-muted">
                                        {task.attachments.length}
                                    </span>
                                ) : (
                                    <span className="text-muted text-xs">-</span>
                                )}
                            </td>

                            {/* Time */}
                            <td className="px-6 py-4 whitespace-nowrap text-center">
                                {task.loggedHours > 0 ? (
                                    <span className="inline-flex items-center gap-1 text-sm">
                                        <span className="text-primary font-medium">{task.loggedHours}h</span>
                                    </span>
                                ) : (
                                    <span className="text-muted text-xs">-</span>
                                )}
                            </td>

                            <td className="px-6 py-4 whitespace-nowrap text-right text-sm">
                                <button className="text-primary hover:text-blue-400 transition-colors">
                                    View
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>

            {selectedTasks.size > 0 && (
                <div className="fixed bottom-4 left-1/2 -translate-x-1/2 bg-surface border border-border rounded-lg shadow-lg px-4 py-3 flex items-center gap-4">
                    <span className="text-sm text-white">
                        {selectedTasks.size} task{selectedTasks.size > 1 ? 's' : ''} selected
                    </span>
                    <div className="flex items-center gap-2">
                        <button className="px-3 py-1.5 text-sm bg-primary hover:bg-blue-600 text-white rounded-lg transition-colors">
                            Change Status
                        </button>
                        <button className="px-3 py-1.5 text-sm bg-background hover:bg-hover text-white rounded-lg transition-colors">
                            Assign
                        </button>
                        <button className="px-3 py-1.5 text-sm bg-red-500/10 hover:bg-red-500/20 text-red-500 rounded-lg transition-colors">
                            Delete
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
};
