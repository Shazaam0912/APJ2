import { useState } from 'react';
import { DragDropContext, Droppable, type DropResult } from 'react-beautiful-dnd';
import { ChevronDown, ChevronRight, Plus } from 'lucide-react';
import clsx from 'clsx';
import { type Task, type BoardData } from '../../context/DataContext';
import { WipLimitIndicator } from './WipLimitIndicator';
import { TaskCard } from './TaskCard';

interface SwimlaneViewProps {
    data: BoardData;
    groupBy: 'assignee' | 'priority' | 'label';
    onTaskClick: (task: Task) => void;
    onAddTask: (columnId: string) => void;
    onDragEnd: (result: DropResult) => void;
}

interface Swimlane {
    id: string;
    title: string;
    tasks: Task[];
    color?: string;
}

export const SwimlaneView = ({ data, groupBy, onTaskClick, onAddTask, onDragEnd }: SwimlaneViewProps) => {
    const [collapsedLanes, setCollapsedLanes] = useState<Set<string>>(new Set());

    const toggleLane = (laneId: string) => {
        setCollapsedLanes(prev => {
            const next = new Set(prev);
            if (next.has(laneId)) {
                next.delete(laneId);
            } else {
                next.add(laneId);
            }
            return next;
        });
    };

    // Group tasks into swimlanes based on groupBy criteria
    const getSwimlanes = (): Swimlane[] => {
        const allTasks = Object.values(data.tasks).filter(task => !task.parentId);

        if (groupBy === 'assignee') {
            const groupedByAssignee = new Map<string, Task[]>();

            allTasks.forEach(task => {
                const assignee = task.assignee || 'Unassigned';
                if (!groupedByAssignee.has(assignee)) {
                    groupedByAssignee.set(assignee, []);
                }
                groupedByAssignee.get(assignee)!.push(task);
            });

            return Array.from(groupedByAssignee.entries()).map(([assignee, tasks]) => ({
                id: assignee,
                title: assignee,
                tasks,
                color: assignee === 'Unassigned' ? '#666' : '#5A8FF6'
            }));
        }

        if (groupBy === 'priority') {
            const priorityOrder = ['high', 'medium', 'low'];
            const priorityColors = {
                high: '#EF4444',
                medium: '#F59E0B',
                low: '#10B981'
            };

            const groupedByPriority = new Map<string, Task[]>();
            priorityOrder.forEach(p => groupedByPriority.set(p, []));

            allTasks.forEach(task => {
                const priority = task.priority;
                if (!groupedByPriority.has(priority)) {
                    groupedByPriority.set(priority, []);
                }
                groupedByPriority.get(priority)!.push(task);
            });

            return priorityOrder.map(priority => ({
                id: priority,
                title: priority.charAt(0).toUpperCase() + priority.slice(1) + ' Priority',
                tasks: groupedByPriority.get(priority) || [],
                color: priorityColors[priority as keyof typeof priorityColors]
            }));
        }

        if (groupBy === 'label') {
            const groupedByLabel = new Map<string, Task[]>();

            allTasks.forEach(task => {
                if (task.tags.length === 0) {
                    if (!groupedByLabel.has('No Labels')) {
                        groupedByLabel.set('No Labels', []);
                    }
                    groupedByLabel.get('No Labels')!.push(task);
                } else {
                    task.tags.forEach(tag => {
                        if (!groupedByLabel.has(tag)) {
                            groupedByLabel.set(tag, []);
                        }
                        groupedByLabel.get(tag)!.push(task);
                    });
                }
            });

            return Array.from(groupedByLabel.entries()).map(([label, tasks]) => ({
                id: label,
                title: label,
                tasks,
                color: label === 'No Labels' ? '#666' : '#8B5CF6'
            }));
        }

        return [];
    };

    const swimlanes = getSwimlanes();

    // Get tasks for a specific column within a swimlane
    const getTasksForColumnInLane = (lane: Swimlane, columnId: string): Task[] => {
        const column = data.columns[columnId];
        return lane.tasks.filter(task => column.taskIds.includes(task.id));
    };

    return (
        <DragDropContext onDragEnd={onDragEnd}>
            <div className="flex-1 overflow-auto">
                {swimlanes.map(lane => {
                    const isCollapsed = collapsedLanes.has(lane.id);
                    const laneTaskCount = lane.tasks.length;

                    return (
                        <div key={lane.id} className="border-b border-border">
                            {/* Swimlane Header */}
                            <div
                                className="sticky left-0 bg-white border-b border-border px-4 py-3 flex items-center gap-3 hover:bg-gray-50 transition-colors cursor-pointer"
                                onClick={() => toggleLane(lane.id)}
                            >
                                <button className="p-1 hover:bg-gray-200 rounded transition-colors text-muted">
                                    {isCollapsed ? (
                                        <ChevronRight className="w-4 h-4" />
                                    ) : (
                                        <ChevronDown className="w-4 h-4" />
                                    )}
                                </button>

                                <div
                                    className="w-1 h-8 rounded-full"
                                    style={{ backgroundColor: lane.color }}
                                />

                                <h3 className="text-sm font-semibold text-text">{lane.title}</h3>

                                <span className="px-2 py-0.5 bg-gray-100 text-muted rounded-full text-xs font-medium border border-gray-200">
                                    {laneTaskCount} {laneTaskCount === 1 ? 'task' : 'tasks'}
                                </span>
                            </div>

                            {/* Swimlane Content */}
                            {!isCollapsed && (
                                <div className="p-6 overflow-x-auto bg-gray-50/30">
                                    <div className="flex gap-6 min-w-max">
                                        {data.columnOrder.map(columnId => {
                                            const column = data.columns[columnId];
                                            const tasks = getTasksForColumnInLane(lane, columnId);

                                            return (
                                                <div key={column.id} className="flex flex-col w-80 bg-gray-50/50 rounded-xl">
                                                    {/* Column Header */}
                                                    <div className="p-4 flex items-center justify-between">
                                                        <div className="flex items-center gap-2 flex-1">
                                                            <h4 className="font-semibold text-text text-sm">{column.title}</h4>
                                                            <span className="px-2 py-0.5 bg-white border border-gray-200 text-muted rounded-full text-xs font-medium shadow-sm">
                                                                {tasks.length}
                                                            </span>
                                                            <WipLimitIndicator
                                                                current={tasks.length}
                                                                limit={column.wipLimit}
                                                                showWarning={column.showWipWarning !== false}
                                                            />
                                                        </div>
                                                        <button
                                                            onClick={(e) => {
                                                                e.stopPropagation();
                                                                onAddTask(column.id);
                                                            }}
                                                            className="p-1 hover:bg-gray-200 rounded-lg transition-colors text-muted hover:text-text"
                                                        >
                                                            <Plus className="w-4 h-4" />
                                                        </button>
                                                    </div>

                                                    {/* Column Tasks */}
                                                    <Droppable droppableId={`${lane.id}::${column.id}`}>
                                                        {(provided, snapshot) => (
                                                            <div
                                                                ref={provided.innerRef}
                                                                {...provided.droppableProps}
                                                                className={clsx(
                                                                    'flex-1 p-3 space-y-3 min-h-[100px] transition-colors',
                                                                    snapshot.isDraggingOver && 'bg-gray-100/50'
                                                                )}
                                                            >
                                                                {tasks.map((task, index) => (
                                                                    <TaskCard
                                                                        key={task.id}
                                                                        task={task}
                                                                        index={index}
                                                                        onClick={onTaskClick}
                                                                    />
                                                                ))}
                                                                {provided.placeholder}
                                                            </div>
                                                        )}
                                                    </Droppable>
                                                </div>
                                            );
                                        })}
                                    </div>
                                </div>
                            )}
                        </div>
                    );
                })}
            </div>
        </DragDropContext>
    );
};
