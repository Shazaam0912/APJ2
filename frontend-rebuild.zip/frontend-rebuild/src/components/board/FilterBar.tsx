import { Filter, X } from 'lucide-react';
import { Dropdown, DropdownItem } from '../ui/Dropdown';

interface FilterChip {
    id: string;
    label: string;
    value: string;
}

interface FilterBarProps {
    filters: FilterChip[];
    onRemoveFilter: (id: string) => void;
    onClearAll: () => void;
    onAddFilter: (type: string, value: string) => void;
}

export const FilterBar = ({ filters, onRemoveFilter, onClearAll, onAddFilter }: FilterBarProps) => {
    const handleAddFilter = (type: string) => {
        // For demo purposes, add a sample filter
        // In a real app, this would open a secondary dropdown/modal to select the specific value
        let value = '';
        switch (type) {
            case 'Assignee':
                value = 'JD';
                break;
            case 'Priority':
                value = 'High';
                break;
            case 'Status':
                value = 'To Do';
                break;
            case 'Label':
                value = 'Bug';
                break;
        }
        onAddFilter(type, value);
    };

    return (
        <div className="flex items-center gap-3 p-4 bg-white border-b border-gray-200">
            <Dropdown
                trigger={
                    <button className="flex items-center gap-2 px-3 py-2 text-sm bg-white hover:bg-gray-50 border border-gray-200 rounded-xl transition-all text-gray-700 font-medium">
                        <Filter className="w-4 h-4" />
                        <span>Add Filter</span>
                    </button>
                }
                align="start"
            >
                <DropdownItem onClick={() => handleAddFilter('Assignee')}>
                    Filter by Assignee
                </DropdownItem>
                <DropdownItem onClick={() => handleAddFilter('Priority')}>
                    Filter by Priority
                </DropdownItem>
                <DropdownItem onClick={() => handleAddFilter('Status')}>
                    Filter by Status
                </DropdownItem>
                <DropdownItem onClick={() => handleAddFilter('Label')}>
                    Filter by Label
                </DropdownItem>
            </Dropdown>

            {/* Active Filters */}
            <div className="flex items-center gap-2 flex-1 flex-wrap">
                {filters.map((filter) => (
                    <div
                        key={filter.id}
                        className="flex items-center gap-2 px-3 py-1.5 bg-primary/10 text-primary rounded-lg text-sm font-medium"
                    >
                        <span>{filter.label}: {filter.value}</span>
                        <button
                            onClick={() => onRemoveFilter(filter.id)}
                            className="hover:bg-primary/20 rounded p-0.5 transition-colors"
                        >
                            <X className="w-3 h-3" />
                        </button>
                    </div>
                ))}
                {filters.length > 0 && (
                    <button
                        onClick={onClearAll}
                        className="text-sm text-gray-500 hover:text-gray-900 transition-colors font-medium"
                    >
                        Clear all
                    </button>
                )}
            </div>
        </div>
    );
};
