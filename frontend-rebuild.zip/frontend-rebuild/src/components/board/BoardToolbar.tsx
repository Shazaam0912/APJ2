import { ChevronDown, Grid3x3, List, Table, Rows, Zap, Filter } from 'lucide-react';
import { Dropdown, DropdownItem } from '../ui/Dropdown';
import { Badge } from '../ui/Badge';
import clsx from 'clsx';

interface BoardToolbarProps {
    currentView: 'board' | 'list' | 'table' | 'sprint';
    onViewChange: (view: 'board' | 'list' | 'table' | 'sprint') => void;
    groupBy: 'none' | 'status' | 'assignee' | 'priority';
    onGroupByChange: (groupBy: 'none' | 'status' | 'assignee' | 'priority') => void;
    swimlaneGroupBy?: 'none' | 'assignee' | 'priority' | 'label';
    onSwimlaneGroupByChange?: (groupBy: 'none' | 'assignee' | 'priority' | 'label') => void;
    onFilterClick?: () => void;
    activeFilterCount?: number;
}

export const BoardToolbar = ({
    currentView,
    onViewChange,
    groupBy,
    onGroupByChange,
    swimlaneGroupBy = 'none',
    onSwimlaneGroupByChange,
    onFilterClick,
    activeFilterCount = 0
}: BoardToolbarProps) => {
    const groupByLabels = {
        none: 'No Grouping',
        status: 'Group by Status',
        assignee: 'Group by Assignee',
        priority: 'Group by Priority',
    };

    const swimlaneLabels = {
        none: 'No Swimlanes',
        assignee: 'Swimlanes by Assignee',
        priority: 'Swimlanes by Priority',
        label: 'Swimlanes by Label',
    };

    return (
        <div className="flex items-center justify-between p-4 bg-white border-b border-gray-200">
            <div className="flex items-center gap-3">
                {/* Swimlane Grouping (only show in board view) */}
                {currentView === 'board' && onSwimlaneGroupByChange && (
                    <Dropdown
                        trigger={
                            <button className="flex items-center gap-2 px-4 py-2.5 text-sm bg-white hover:bg-gray-50 border border-gray-200 rounded-xl transition-all shadow-sm hover:shadow-md text-gray-700 font-semibold">
                                <Rows className="w-4 h-4" />
                                <span>{swimlaneLabels[swimlaneGroupBy]}</span>
                                <ChevronDown className="w-4 h-4" />
                            </button>
                        }
                        align="start"
                    >
                        <DropdownItem onClick={() => onSwimlaneGroupByChange('none')}>
                            No Swimlanes
                        </DropdownItem>
                        <DropdownItem onClick={() => onSwimlaneGroupByChange('assignee')}>
                            Swimlanes by Assignee
                        </DropdownItem>
                        <DropdownItem onClick={() => onSwimlaneGroupByChange('priority')}>
                            Swimlanes by Priority
                        </DropdownItem>
                        <DropdownItem onClick={() => onSwimlaneGroupByChange('label')}>
                            Swimlanes by Label
                        </DropdownItem>
                    </Dropdown>
                )}

                {/* Grouping Dropdown (for other views) */}
                {currentView !== 'board' && (
                    <Dropdown
                        trigger={
                            <button className="flex items-center gap-2 px-4 py-2.5 text-sm bg-white hover:bg-gray-50 border border-gray-200 rounded-xl transition-all shadow-sm hover:shadow-md text-gray-700 font-semibold">
                                <span>{groupByLabels[groupBy]}</span>
                                <ChevronDown className="w-4 h-4" />
                            </button>
                        }
                        align="start"
                    >
                        <DropdownItem onClick={() => onGroupByChange('none')}>
                            No Grouping
                        </DropdownItem>
                        <DropdownItem onClick={() => onGroupByChange('status')}>
                            Group by Status
                        </DropdownItem>
                        <DropdownItem onClick={() => onGroupByChange('assignee')}>
                            Group by Assignee
                        </DropdownItem>
                        <DropdownItem onClick={() => onGroupByChange('priority')}>
                            Group by Priority
                        </DropdownItem>
                    </Dropdown>
                )}

                {/* Add Filter Button */}
                {onFilterClick && (
                    <button
                        onClick={onFilterClick}
                        className="flex items-center gap-2 px-4 py-2.5 text-sm bg-white hover:bg-gray-50 border border-gray-200 rounded-xl transition-all shadow-sm hover:shadow-md text-gray-700 font-semibold relative"
                    >
                        <Filter className="w-4 h-4" />
                        <span>Add Filter</span>
                        {activeFilterCount > 0 && (
                            <Badge size="sm" variant="default" className="ml-1">
                                {activeFilterCount}
                            </Badge>
                        )}
                    </button>
                )}
            </div>

            {/* View Switcher */}
            <div className="flex items-center gap-1 bg-gray-50 border border-gray-200 rounded-xl p-1 shadow-sm">
                <button
                    onClick={() => onViewChange('board')}
                    className={clsx(
                        'flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-semibold transition-all',
                        currentView === 'board'
                            ? 'bg-primary text-white shadow-soft'
                            : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                    )}
                >
                    <Grid3x3 className="w-4 h-4" />
                    <span>Board</span>
                </button>
                <button
                    onClick={() => onViewChange('list')}
                    className={clsx(
                        'flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-semibold transition-all',
                        currentView === 'list'
                            ? 'bg-primary text-white shadow-soft'
                            : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                    )}
                >
                    <List className="w-4 h-4" />
                    <span>List</span>
                </button>
                <button
                    onClick={() => onViewChange('table')}
                    className={clsx(
                        'flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-semibold transition-all',
                        currentView === 'table'
                            ? 'bg-primary text-white shadow-soft'
                            : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                    )}
                >
                    <Table className="w-4 h-4" />
                    <span>Table</span>
                </button>
                <button
                    onClick={() => onViewChange('sprint')}
                    className={clsx(
                        'flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-semibold transition-all',
                        currentView === 'sprint'
                            ? 'bg-primary text-white shadow-soft'
                            : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                    )}
                >
                    <Zap className="w-4 h-4" />
                    <span>Sprint</span>
                </button>
            </div>
        </div>
    );
};

