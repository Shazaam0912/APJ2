import { Draggable } from 'react-beautiful-dnd';
import clsx from 'clsx';
import { type Task } from '../../context/DataContext';

interface TaskCardProps {
    task: Task;
    index: number;
    onClick: (task: Task) => void;
}

export const TaskCard = ({ task, index, onClick }: TaskCardProps) => {
    const priorityColors = {
        high: 'bg-red-500',
        medium: 'bg-yellow-500',
        low: 'bg-green-500'
    };

    const priorityBadgeColors = {
        high: 'bg-red-100 text-red-700',
        medium: 'bg-yellow-100 text-yellow-700',
        low: 'bg-green-100 text-green-700'
    };

    return (
        <Draggable draggableId={task.id} index={index}>
            {(provided, snapshot) => (
                <div
                    ref={provided.innerRef}
                    {...provided.draggableProps}
                    {...provided.dragHandleProps}
                    onClick={() => onClick(task)}
                    className={clsx(
                        'relative bg-white rounded-lg p-4 cursor-pointer transition-all group',
                        'border border-gray-100 shadow-sm hover:shadow-md',
                        snapshot.isDragging && 'shadow-xl ring-2 ring-primary/20 rotate-2 z-50'
                    )}
                >
                    {/* Left Border Indicator */}
                    <div
                        className={clsx(
                            "absolute left-0 top-3 bottom-3 w-1 rounded-r-full",
                            priorityColors[task.priority as keyof typeof priorityColors] || 'bg-gray-300'
                        )}
                    />

                    <div className="pl-3">
                        {/* Title */}
                        <p className="text-sm font-medium text-gray-900 mb-3 leading-snug">
                            {task.content}
                        </p>

                        {/* Footer: Avatar & Priority */}
                        <div className="flex items-center justify-between mt-2">
                            {/* Assignee Avatar */}
                            <div className="flex items-center gap-2">
                                {task.assignee ? (
                                    <div className="flex items-center gap-1.5">
                                        <div className="w-6 h-6 rounded-full bg-blue-100 flex items-center justify-center text-[10px] font-bold text-blue-700 ring-2 ring-white">
                                            {task.assignee.substring(0, 2).toUpperCase()}
                                        </div>
                                        <span className="text-xs text-gray-500 font-medium">
                                            {task.assignee}
                                        </span>
                                    </div>
                                ) : (
                                    <div className="w-6 h-6 rounded-full bg-gray-100 flex items-center justify-center text-[10px] text-gray-400 ring-2 ring-white">
                                        ?
                                    </div>
                                )}
                            </div>

                            {/* Priority Badge */}
                            <span
                                className={clsx(
                                    'px-2.5 py-0.5 rounded-full text-[10px] font-semibold uppercase tracking-wide',
                                    priorityBadgeColors[task.priority as keyof typeof priorityBadgeColors] || 'bg-gray-100 text-gray-600'
                                )}
                            >
                                {task.priority}
                            </span>
                        </div>
                    </div>
                </div>
            )}
        </Draggable>
    );
};
