import { Calendar, Clock, MapPin, Users } from 'lucide-react';
import clsx from 'clsx';

interface AgendaViewProps {
    events: any[];
    onEventClick: (event: any) => void;
    onCreateClick: () => void;
}

export const AgendaView = ({ events, onEventClick, onCreateClick }: AgendaViewProps) => {
    const getEventColor = (type: string) => {
        switch (type) {
            case 'meeting': return 'text-blue-600 bg-blue-50 border-blue-200';
            case 'deadline': return 'text-red-600 bg-red-50 border-red-200';
            case 'milestone': return 'text-purple-600 bg-purple-50 border-purple-200';
            case 'task': return 'text-green-600 bg-green-50 border-green-200';
            case 'review': return 'text-orange-600 bg-orange-50 border-orange-200';
            default: return 'text-gray-600 bg-gray-50 border-gray-200';
        }
    };

    const getIconColor = (type: string) => {
        switch (type) {
            case 'meeting': return 'bg-blue-500';
            case 'deadline': return 'bg-red-500';
            case 'milestone': return 'bg-purple-500';
            case 'task': return 'bg-green-500';
            case 'review': return 'bg-orange-500';
            default: return 'bg-gray-500';
        }
    };

    // Sort events by date
    const sortedEvents = [...events].sort((a, b) =>
        new Date(a.start).getTime() - new Date(b.start).getTime()
    );

    // Group events by date
    const groupedEvents: { [key: string]: any[] } = {};
    sortedEvents.forEach(event => {
        const dateKey = new Date(event.start).toLocaleDateString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
        if (!groupedEvents[dateKey]) {
            groupedEvents[dateKey] = [];
        }
        groupedEvents[dateKey].push(event);
    });

    const isToday = (dateStr: string) => {
        const today = new Date().toLocaleDateString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
        return dateStr === today;
    };

    if (sortedEvents.length === 0) {
        return (
            <div className="flex-1 flex flex-col items-center justify-center bg-white rounded-2xl border border-gray-200 p-12">
                <Calendar className="w-20 h-20 text-gray-300 mb-4" />
                <h3 className="text-xl font-bold text-gray-900 mb-2">No upcoming events</h3>
                <p className="text-gray-500 mb-6 text-center max-w-md">
                    You don't have any events scheduled. Create your first event to get started.
                </p>
                <button
                    onClick={onCreateClick}
                    className="bg-primary hover:bg-blue-600 text-white px-6 py-3 rounded-xl font-semibold transition-all shadow-sm hover:shadow-md"
                >
                    Create Event
                </button>
            </div>
        );
    }

    return (
        <div className="flex-1 overflow-y-auto bg-white rounded-2xl border border-gray-200 shadow-sm">
            <div className="p-6 space-y-8">
                {Object.entries(groupedEvents).map(([dateStr, dateEvents]) => (
                    <div key={dateStr}>
                        {/* Date Header */}
                        <div className={clsx(
                            "flex items-center gap-3 mb-4 pb-2 border-b-2",
                            isToday(dateStr) ? "border-primary" : "border-gray-200"
                        )}>
                            <div className={clsx(
                                "font-bold text-lg",
                                isToday(dateStr) ? "text-primary" : "text-gray-900"
                            )}>
                                {dateStr}
                            </div>
                            {isToday(dateStr) && (
                                <span className="px-2 py-0.5 bg-primary text-white text-xs font-semibold rounded-full">
                                    Today
                                </span>
                            )}
                            <span className="text-sm text-gray-500">
                                {dateEvents.length} {dateEvents.length === 1 ? 'event' : 'events'}
                            </span>
                        </div>

                        {/* Events List */}
                        <div className="space-y-3">
                            {dateEvents.map(event => (
                                <div
                                    key={event.id}
                                    onClick={() => onEventClick(event)}
                                    className={clsx(
                                        "p-5 rounded-xl border-2 cursor-pointer hover:shadow-lg transition-all group",
                                        getEventColor(event.type)
                                    )}
                                >
                                    <div className="flex items-start gap-4">
                                        {/* Icon */}
                                        <div className={clsx(
                                            "w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 text-white shadow-sm",
                                            getIconColor(event.type)
                                        )}>
                                            <Calendar className="w-6 h-6" />
                                        </div>

                                        {/* Content */}
                                        <div className="flex-1 min-w-0">
                                            <div className="flex items-start justify-between gap-3 mb-2">
                                                <h3 className="font-bold text-lg text-gray-900">{event.title}</h3>
                                                <span className="px-2 py-1 bg-white rounded-lg text-xs font-semibold capitalize whitespace-nowrap border border-gray-200">
                                                    {event.type}
                                                </span>
                                            </div>

                                            {event.description && (
                                                <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                                                    {event.description}
                                                </p>
                                            )}

                                            <div className="flex flex-wrap items-center gap-4 text-sm text-gray-600">
                                                <div className="flex items-center gap-1.5">
                                                    <Clock className="w-4 h-4" />
                                                    <span>
                                                        {new Date(event.start).toLocaleTimeString('en-US', {
                                                            hour: 'numeric',
                                                            minute: '2-digit'
                                                        })}
                                                        {event.end && ` - ${new Date(event.end).toLocaleTimeString('en-US', {
                                                            hour: 'numeric',
                                                            minute: '2-digit'
                                                        })}`}
                                                    </span>
                                                </div>

                                                {event.location && (
                                                    <div className="flex items-center gap-1.5">
                                                        <MapPin className="w-4 h-4" />
                                                        <span>{event.location}</span>
                                                    </div>
                                                )}

                                                {event.attendees && event.attendees.length > 0 && (
                                                    <div className="flex items-center gap-1.5">
                                                        <Users className="w-4 h-4" />
                                                        <span>{event.attendees.length} attendees</span>
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};
