import clsx from 'clsx';

interface MonthViewProps {
    currentDate: Date;
    events: any[];
    onEventClick: (event: any) => void;
    onDateClick: (date: Date) => void;
}

export const MonthView = ({ currentDate, events, onEventClick, onDateClick }: MonthViewProps) => {
    const daysInMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).getDate();
    const firstDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1).getDay();

    const getEventsForDay = (day: number) => {
        return events.filter(e => {
            const eventDate = new Date(e.start);
            return eventDate.getDate() === day &&
                eventDate.getMonth() === currentDate.getMonth() &&
                eventDate.getFullYear() === currentDate.getFullYear();
        });
    };

    const getEventColor = (type: string) => {
        switch (type) {
            case 'meeting': return 'bg-blue-50 text-blue-700 border-blue-200';
            case 'deadline': return 'bg-red-50 text-red-700 border-red-200';
            case 'milestone': return 'bg-purple-50 text-purple-700 border-purple-200';
            case 'task': return 'bg-green-50 text-green-700 border-green-200';
            case 'review': return 'bg-orange-50 text-orange-700 border-orange-200';
            default: return 'bg-gray-50 text-gray-700 border-gray-200';
        }
    };

    return (
        <div className="flex-1 bg-white rounded-2xl border border-gray-200 overflow-hidden flex flex-col shadow-sm">
            {/* Weekday Headers */}
            <div className="grid grid-cols-7 border-b border-gray-200 bg-gray-50">
                {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                    <div key={day} className="py-4 text-center text-sm font-semibold text-gray-700 uppercase tracking-wider">
                        {day}
                    </div>
                ))}
            </div>

            {/* Calendar Grid */}
            <div className="flex-1 grid grid-cols-7 grid-rows-5 overflow-y-auto">
                {Array.from({ length: firstDayOfMonth }).map((_, i) => (
                    <div key={`empty-${i}`} className="border-b border-r border-gray-100 bg-gray-50/50" />
                ))}

                {Array.from({ length: daysInMonth }).map((_, i) => {
                    const day = i + 1;
                    const dayEvents = getEventsForDay(day);
                    const isToday = day === new Date().getDate() &&
                        currentDate.getMonth() === new Date().getMonth() &&
                        currentDate.getFullYear() === new Date().getFullYear();
                    const cellDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);

                    return (
                        <div
                            key={day}
                            className="border-b border-r border-gray-100 p-3 min-h-[120px] relative group hover:bg-gray-50/50 transition-all cursor-pointer"
                            onClick={() => onDateClick(cellDate)}
                        >
                            <span className={clsx(
                                "w-8 h-8 flex items-center justify-center rounded-full text-sm font-semibold mb-2",
                                isToday ? "bg-primary text-white shadow-sm" : "text-gray-700 hover:bg-gray-100"
                            )}>
                                {day}
                            </span>

                            <div className="space-y-1.5 overflow-y-auto max-h-[80px]">
                                {dayEvents.slice(0, 3).map(event => (
                                    <div
                                        key={event.id}
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            onEventClick(event);
                                        }}
                                        className={clsx(
                                            "px-2 py-1 rounded-lg text-xs font-medium truncate cursor-pointer hover:opacity-80 transition-all border",
                                            getEventColor(event.type)
                                        )}
                                        title={event.title}
                                    >
                                        {event.title}
                                    </div>
                                ))}
                                {dayEvents.length > 3 && (
                                    <div className="text-xs text-gray-500 font-medium px-2">
                                        +{dayEvents.length - 3} more
                                    </div>
                                )}
                            </div>

                            {/* Quick add button on hover */}
                            <button
                                className="absolute bottom-2 right-2 w-6 h-6 bg-primary text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-lg font-bold hover:scale-110"
                                onClick={(e) => {
                                    e.stopPropagation();
                                    onDateClick(cellDate);
                                }}
                            >
                                +
                            </button>
                        </div>
                    );
                })}
            </div>
        </div>
    );
};
