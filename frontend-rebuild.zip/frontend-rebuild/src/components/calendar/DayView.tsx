import clsx from 'clsx';

interface DayViewProps {
    currentDate: Date;
    events: any[];
    onEventClick: (event: any) => void;
    onTimeSlotClick: (date: Date) => void;
}

export const DayView = ({ currentDate, events, onEventClick, onTimeSlotClick }: DayViewProps) => {
    const hours = Array.from({ length: 24 }, (_, i) => i);

    const getEventsForHour = (hour: number) => {
        return events.filter(e => {
            const eventDate = new Date(e.start);
            const eventHour = eventDate.getHours();
            return eventDate.getDate() === currentDate.getDate() &&
                eventDate.getMonth() === currentDate.getMonth() &&
                eventDate.getFullYear() === currentDate.getFullYear() &&
                eventHour === hour;
        });
    };

    const getEventColor = (type: string) => {
        switch (type) {
            case 'meeting': return 'bg-blue-500 text-white border-blue-600';
            case 'deadline': return 'bg-red-500 text-white border-red-600';
            case 'milestone': return 'bg-purple-500 text-white border-purple-600';
            case 'task': return 'bg-green-500 text-white border-green-600';
            case 'review': return 'bg-orange-500 text-white border-orange-600';
            default: return 'bg-gray-500 text-white border-gray-600';
        }
    };

    const formatTime = (hour: number) => {
        if (hour === 0) return '12:00 AM';
        if (hour < 12) return `${hour}:00 AM`;
        if (hour === 12) return '12:00 PM';
        return `${hour - 12}:00 PM`;
    };

    const isToday = currentDate.getDate() === new Date().getDate() &&
        currentDate.getMonth() === new Date().getMonth() &&
        currentDate.getFullYear() === new Date().getFullYear();

    return (
        <div className="flex-1 flex flex-col bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-sm">
            {/* Day Header */}
            <div className={clsx(
                "p-6 border-b border-gray-200",
                isToday && "bg-primary/10"
            )}>
                <div className="flex items-center justify-center gap-3">
                    <div className="text-sm font-medium text-gray-500 uppercase">
                        {currentDate.toLocaleDateString('en-US', { weekday: 'long' })}
                    </div>
                    <div className={clsx(
                        "text-4xl font-bold",
                        isToday ? "text-primary" : "text-gray-900"
                    )}>
                        {currentDate.getDate()}
                    </div>
                    <div className="text-sm font-medium text-gray-500">
                        {currentDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
                    </div>
                </div>
            </div>

            {/* Time Slots */}
            <div className="flex-1 overflow-y-auto">
                {hours.map(hour => {
                    const hourEvents = getEventsForHour(hour);
                    const cellDate = new Date(currentDate);
                    cellDate.setHours(hour);

                    return (
                        <div
                            key={hour}
                            className="flex border-b border-gray-100 hover:bg-gray-50 transition-colors cursor-pointer group"
                            style={{ minHeight: '80px' }}
                            onClick={() => onTimeSlotClick(cellDate)}
                        >
                            {/* Time */}
                            <div className="w-32 p-4 border-r border-gray-200 text-sm font-medium text-gray-500 text-right flex-shrink-0">
                                {formatTime(hour)}
                            </div>

                            {/* Events */}
                            <div className="flex-1 p-3 relative">
                                {hourEvents.length === 0 ? (
                                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                                        <div className="text-gray-400 text-sm font-medium">Click to add event</div>
                                    </div>
                                ) : (
                                    <div className="space-y-2">
                                        {hourEvents.map(event => (
                                            <div
                                                key={event.id}
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    onEventClick(event);
                                                }}
                                                className={clsx(
                                                    "p-4 rounded-xl cursor-pointer hover:scale-[1.02] transition-transform border shadow-sm",
                                                    getEventColor(event.type)
                                                )}
                                            >
                                                <div className="font-semibold text-base mb-1">{event.title}</div>
                                                {event.description && (
                                                    <div className="text-sm opacity-90 line-clamp-2">{event.description}</div>
                                                )}
                                                <div className="text-xs opacity-80 mt-2 flex items-center gap-2">
                                                    <span>{new Date(event.start).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}</span>
                                                    {event.end && (
                                                        <>
                                                            <span>-</span>
                                                            <span>{new Date(event.end).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}</span>
                                                        </>
                                                    )}
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    );
};
