import { useState, useEffect } from 'react';
import { X, Calendar, Clock, MapPin, Users, Trash2, FileText } from 'lucide-react';
import { useData } from '../../context/DataContext';
import clsx from 'clsx';

interface EventModalProps {
    event?: any;
    initialDate?: Date | null;
    onClose: () => void;
    onSave: (eventData: any) => void;
    onDelete?: () => void;
}

export const EventModal = ({ event, initialDate, onClose, onSave, onDelete }: EventModalProps) => {
    const { teamMembers } = useData();
    const [formData, setFormData] = useState({
        title: '',
        description: '',
        type: 'meeting' as 'meeting' | 'deadline' | 'milestone' | 'task' | 'review',
        start: '',
        end: '',
        location: '',
        attendees: [] as string[],
    });

    useEffect(() => {
        if (event) {
            setFormData({
                title: event.title || '',
                description: event.description || '',
                type: event.type || 'meeting',
                start: event.start || '',
                end: event.end || '',
                location: event.location || '',
                attendees: event.attendees || [],
            });
        } else if (initialDate) {
            const dateStr = initialDate.toISOString().slice(0, 16);
            setFormData(prev => ({
                ...prev,
                start: dateStr,
            }));
        }
    }, [event, initialDate]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!formData.title || !formData.start) return;

        onSave({
            ...formData,
            id: event?.id || `evt-${Date.now()}`,
        });
    };

    const eventTypes = [
        { value: 'meeting', label: 'Meeting', icon: Users, color: 'blue' },
        { value: 'deadline', label: 'Deadline', icon: Clock, color: 'red' },
        { value: 'milestone', label: 'Milestone', icon: Calendar, color: 'purple' },
        { value: 'task', label: 'Task', icon: FileText, color: 'green' },
        { value: 'review', label: 'Review', icon: Users, color: 'orange' },
    ];

    const getTypeColor = (type: string) => {
        const colors: any = {
            blue: 'border-blue-500 bg-blue-50 text-blue-700',
            red: 'border-red-500 bg-red-50 text-red-700',
            purple: 'border-purple-500 bg-purple-50 text-purple-700',
            green: 'border-green-500 bg-green-50 text-green-700',
            orange: 'border-orange-500 bg-orange-50 text-orange-700',
        };
        return colors[type] || colors.blue;
    };

    return (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={onClose}>
            <div
                className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto"
                onClick={(e) => e.stopPropagation()}
            >
                {/* Header */}
                <div className="sticky top-0 bg-white border-b border-gray-200 p-6 flex items-center justify-between rounded-t-2xl">
                    <h2 className="text-2xl font-bold text-gray-900">
                        {event ? 'Edit Event' : 'Create New Event'}
                    </h2>
                    <button
                        onClick={onClose}
                        className="p-2 hover:bg-gray-100 rounded-xl transition-colors text-gray-500 hover:text-gray-900"
                    >
                        <X className="w-5 h-5" />
                    </button>
                </div>

                {/* Form */}
                <form onSubmit={handleSubmit} className="p-6 space-y-6">
                    {/* Title */}
                    <div>
                        <label className="block text-sm font-semibold text-gray-700 mb-2">
                            Event Title *
                        </label>
                        <input
                            type="text"
                            value={formData.title}
                            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                            className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-gray-900 focus:border-primary focus:ring-2 focus:ring-primary/10 outline-none transition-all"
                            placeholder="Enter event title..."
                            required
                        />
                    </div>

                    {/* Event Type */}
                    <div>
                        <label className="block text-sm font-semibold text-gray-700 mb-3">
                            Event Type
                        </label>
                        <div className="grid grid-cols-5 gap-2">
                            {eventTypes.map(type => (
                                <button
                                    key={type.value}
                                    type="button"
                                    onClick={() => setFormData({ ...formData, type: type.value as any })}
                                    className={clsx(
                                        "p-3 rounded-xl border-2 transition-all flex flex-col items-center gap-2 text-sm font-semibold",
                                        formData.type === type.value
                                            ? getTypeColor(type.color)
                                            : "border-gray-200 text-gray-600 hover:border-gray-300 hover:bg-gray-50"
                                    )}
                                >
                                    <type.icon className="w-5 h-5" />
                                    <span className="text-xs">{type.label}</span>
                                </button>
                            ))}
                        </div>
                    </div>

                    {/* Date & Time */}
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-semibold text-gray-700 mb-2">
                                Start Date & Time *
                            </label>
                            <input
                                type="datetime-local"
                                value={formData.start}
                                onChange={(e) => setFormData({ ...formData, start: e.target.value })}
                                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-gray-900 focus:border-primary focus:ring-2 focus:ring-primary/10 outline-none transition-all"
                                required
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-semibold text-gray-700 mb-2">
                                End Date & Time
                            </label>
                            <input
                                type="datetime-local"
                                value={formData.end}
                                onChange={(e) => setFormData({ ...formData, end: e.target.value })}
                                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-gray-900 focus:border-primary focus:ring-2 focus:ring-primary/10 outline-none transition-all"
                            />
                        </div>
                    </div>

                    {/* Description */}
                    <div>
                        <label className="block text-sm font-semibold text-gray-700 mb-2">
                            Description
                        </label>
                        <textarea
                            value={formData.description}
                            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                            className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-gray-900 focus:border-primary focus:ring-2 focus:ring-primary/10 outline-none resize-none transition-all"
                            rows={4}
                            placeholder="Add event description..."
                        />
                    </div>

                    {/* Location */}
                    <div>
                        <label className="block text-sm font-semibold text-gray-700 mb-2">
                            Location
                        </label>
                        <div className="relative">
                            <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                            <input
                                type="text"
                                value={formData.location}
                                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                                className="w-full bg-gray-50 border border-gray-200 rounded-xl pl-11 pr-4 py-3 text-gray-900 focus:border-primary focus:ring-2 focus:ring-primary/10 outline-none transition-all"
                                placeholder="Add location..."
                            />
                        </div>
                    </div>

                    {/* Attendees */}
                    <div>
                        <label className="block text-sm font-semibold text-gray-700 mb-3">
                            Attendees
                        </label>
                        <div className="flex flex-wrap gap-2">
                            {teamMembers.slice(0, 6).map(member => {
                                const isSelected = formData.attendees.includes(member.id);
                                return (
                                    <button
                                        key={member.id}
                                        type="button"
                                        onClick={() => {
                                            setFormData({
                                                ...formData,
                                                attendees: isSelected
                                                    ? formData.attendees.filter(id => id !== member.id)
                                                    : [...formData.attendees, member.id]
                                            });
                                        }}
                                        className={clsx(
                                            "flex items-center gap-2 px-3 py-2 rounded-xl border-2 transition-all text-sm font-medium",
                                            isSelected
                                                ? "border-primary bg-primary/10 text-primary"
                                                : "border-gray-200 text-gray-600 hover:border-gray-300 hover:bg-gray-50"
                                        )}
                                    >
                                        <div
                                            className="w-6 h-6 rounded-full flex items-center justify-center text-white text-xs font-bold"
                                            style={{ backgroundColor: member.avatar }}
                                        >
                                            {member.name.substring(0, 2)}
                                        </div>
                                        {member.name}
                                    </button>
                                );
                            })}
                        </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-3 pt-4 border-t border-gray-200">
                        {onDelete && (
                            <button
                                type="button"
                                onClick={onDelete}
                                className="flex items-center gap-2 px-4 py-2.5 bg-red-50 hover:bg-red-100 text-red-600 rounded-xl font-semibold transition-all border-2 border-red-200"
                            >
                                <Trash2 className="w-4 h-4" />
                                Delete
                            </button>
                        )}
                        <div className="flex-1" />
                        <button
                            type="button"
                            onClick={onClose}
                            className="px-5 py-2.5 bg-white hover:bg-gray-100 text-gray-700 rounded-xl font-semibold transition-all border-2 border-gray-200"
                        >
                            Cancel
                        </button>
                        <button
                            type="submit"
                            className="px-5 py-2.5 bg-primary hover:bg-blue-600 text-white rounded-xl font-semibold transition-all shadow-sm hover:shadow-md"
                        >
                            {event ? 'Update Event' : 'Create Event'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};
