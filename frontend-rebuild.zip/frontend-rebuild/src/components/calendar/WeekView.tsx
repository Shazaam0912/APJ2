import clsx from 'clsx';

interface WeekViewProps {
    currentDate: Date;
    events: any[];
    onEventClick: (event: any) => void;
    onTimeSlotClick: (date: Date) => void;
}

export const WeekView = ({ currentDate, events, onEventClick, onTimeSlotClick }: WeekViewProps) => {
    const hours = Array.from({ length: 24 }, (_, i) => i);
    const startOfWeek = new Date(currentDate);
    startOfWeek.setDate(currentDate.getDate() - currentDate.getDay());

    const weekDays = Array.from({ length: 7 }, (_, i) => {
        const date = new Date(startOfWeek);
        date.setDate(startOfWeek.getDate() + i);
        return date;
    });

    const getEventsForDayAndHour = (day: Date, hour: number) => {
        return events.filter(e => {
            const eventDate = new Date(e.start);
            const eventHour = eventDate.getHours();
            return eventDate.getDate() === day.getDate() &&
                eventDate.getMonth() === day.getMonth() &&
                eventDate.getFullYear() === day.getFullYear() &&
                eventHour === hour;
        });
    };

    const getEventColor = (type: string) => {
        switch (type) {
            case 'meeting': return 'bg-blue-500 text-white border-blue-600';
            case 'deadline': return 'bg-red-500 text-white border-red-600';
            case 'milestone': return 'bg-purple-500 text-white border-purple-600';
            case 'task': return 'bg-green-500 text-white border-green-600';
            case 'review': return 'bg-orange-500 text-white border-orange-600';
            default: return 'bg-gray-500 text-white border-gray-600';
        }
    };

    const formatTime = (hour: number) => {
        if (hour === 0) return '12 AM';
        if (hour < 12) return `${hour} AM`;
        if (hour === 12) return '12 PM';
        return `${hour - 12} PM`;
    };

    const isToday = (date: Date) => {
        const today = new Date();
        return date.getDate() === today.getDate() &&
            date.getMonth() === today.getMonth() &&
            date.getFullYear() === today.getFullYear();
    };

    return (
        <div className="flex-1 flex flex-col bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-sm">
            {/* Day Headers */}
            <div className="grid grid-cols-8 border-b border-gray-200 bg-gray-50 sticky top-0 z-10">
                <div className="p-4 border-r border-gray-200" /> {/* Time column */}
                {weekDays.map((day, idx) => (
                    <div key={idx} className={clsx(
                        "p-4 text-center border-r border-gray-200 last:border-r-0",
                        isToday(day) && "bg-primary/10"
                    )}>
                        <div className="text-xs font-medium text-gray-500 uppercase">
                            {day.toLocaleDateString('en-US', { weekday: 'short' })}
                        </div>
                        <div className={clsx(
                            "text-2xl font-bold mt-1",
                            isToday(day) ? "text-primary" : "text-gray-900"
                        )}>
                            {day.getDate()}
                        </div>
                    </div>
                ))}
            </div>

            {/* Time Grid */}
            <div className="flex-1 overflow-y-auto">
                {hours.map(hour => (
                    <div key={hour} className="grid grid-cols-8 border-b border-gray-100" style={{ minHeight: '60px' }}>
                        {/* Time Label */}
                        <div className="p-2 border-r border-gray-200 text-xs font-medium text-gray-500 text-right pr-3">
                            {formatTime(hour)}
                        </div>

                        {/* Day Cells */}
                        {weekDays.map((day, idx) => {
                            const cellEvents = getEventsForDayAndHour(day, hour);
                            const cellDate = new Date(day);
                            cellDate.setHours(hour);

                            return (
                                <div
                                    key={idx}
                                    className="border-r border-gray-100 last:border-r-0 p-1 hover:bg-gray-50 transition-colors cursor-pointer relative group"
                                    onClick={() => onTimeSlotClick(cellDate)}
                                >
                                    {cellEvents.map(event => (
                                        <div
                                            key={event.id}
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                onEventClick(event);
                                            }}
                                            className={clsx(
                                                "px-2 py-1 rounded-lg text-xs font-semibold cursor-pointer hover:scale-105 transition-transform border mb-1",
                                                getEventColor(event.type)
                                            )}
                                        >
                                            <div className="truncate">{event.title}</div>
                                        </div>
                                    ))}

                                    {/* Quick add on hover */}
                                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                                        <div className="w-6 h-6 bg-primary/20 rounded-full flex items-center justify-center text-primary text-xs font-bold">
                                            +
                                        </div>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                ))}
            </div>
        </div>
    );
};
