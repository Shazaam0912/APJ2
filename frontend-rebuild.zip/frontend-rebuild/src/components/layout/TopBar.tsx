import { Search, Bell, Menu, Sparkles } from 'lucide-react';
import { useState } from 'react';
import { useData } from '../../context/DataContext';
import { StatsDetailModal } from '../dashboard/StatsDetailModal';
import { AIAssistantModal } from '../modals/AIAssistantModal.tsx';
import { CreateTaskModal } from '../modals/CreateTaskModal';
import clsx from 'clsx';

interface TopBarProps {
    onMenuClick: () => void;
}

export const TopBar = ({ onMenuClick }: TopBarProps) => {
    const { notifications, markAsRead, setActivePage, setActiveChannelId, projects, teamMembers, tasks } = useData();
    const [showNotifications, setShowNotifications] = useState(false);
    const [isStatsModalOpen, setIsStatsModalOpen] = useState(false);
    const [isAIModalOpen, setIsAIModalOpen] = useState(false);
    const [showCreateTask, setShowCreateTask] = useState(false);

    const unreadCount = notifications.filter(n => !n.read).length;

    // Use tasks from DataContext
    const allTasks = tasks;

    const handleNotificationClick = (notif: typeof notifications[0]) => {
        markAsRead(notif.id);
        setShowNotifications(false);

        if (notif.actionUrl) {
            if (notif.actionUrl.includes('/chat')) {
                const url = new URL(notif.actionUrl, window.location.origin);
                const channelId = url.searchParams.get('channel');
                if (channelId) {
                    setActiveChannelId(channelId);
                    setActivePage('chat');
                }
            }
        } else if (notif.channelId) {
            setActiveChannelId(notif.channelId);
            setActivePage('chat');
        } else if (notif.relatedTaskId) {
            setActivePage('projects');
        }
    };

    return (
        <>
            <div className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-4 sticky top-0 z-20">
                <div className="flex items-center gap-4 flex-1">
                    <button onClick={onMenuClick} className="lg:hidden p-2 hover:bg-gray-100 rounded-lg">
                        <Menu className="w-5 h-5 text-gray-600" />
                    </button>

                    <div className="relative flex-1 max-w-md hidden md:block">
                        <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
                        <input
                            type="text"
                            placeholder="Search tasks, projects, or team members..."
                            className="w-full pl-9 pr-4 py-2 bg-gray-50 border-none rounded-lg text-sm focus:ring-2 focus:ring-primary/20 transition-all"
                        />
                    </div>
                </div>

                <div className="flex items-center gap-3">
                    <button
                        onClick={() => setIsAIModalOpen(true)}
                        className="hidden sm:flex items-center gap-2 px-3 py-1.5 bg-gradient-to-r from-indigo-50 to-purple-50 text-indigo-700 rounded-lg hover:from-indigo-100 hover:to-purple-100 transition-colors border border-indigo-100"
                    >
                        <Sparkles className="w-4 h-4" />
                        <span className="text-sm font-medium">Ask AI</span>
                    </button>

                    <div className="flex items-center -space-x-3 mr-6 cursor-pointer hover:opacity-90 transition-opacity" onClick={() => setIsStatsModalOpen(true)}>
                        {teamMembers.slice(0, 4).map((member) => (
                            <img
                                key={member.id}
                                src={member.avatar}
                                alt={member.name}
                                className="w-9 h-9 rounded-full ring-2 ring-white object-cover shadow-sm"
                            />
                        ))}
                        {teamMembers.length > 4 && (
                            <div className="w-9 h-9 rounded-full ring-2 ring-white bg-gray-50 flex items-center justify-center text-xs font-bold text-gray-600 shadow-sm">
                                +{teamMembers.length - 4}
                            </div>
                        )}
                    </div>

                    <div className="relative">
                        <button
                            onClick={() => setShowNotifications(!showNotifications)}
                            className="p-2 hover:bg-gray-100 rounded-lg relative transition-colors"
                        >
                            <Bell className="w-5 h-5 text-gray-600" />
                            {unreadCount > 0 && (
                                <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full ring-2 ring-white" />
                            )}
                        </button>

                        {showNotifications && (
                            <>
                                <div className="fixed inset-0 z-30" onClick={() => setShowNotifications(false)} />
                                <div className="absolute right-0 mt-2 w-80 bg-white rounded-xl shadow-lg border border-gray-100 z-40 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
                                    <div className="p-3 border-b border-gray-100 flex items-center justify-between">
                                        <h3 className="font-semibold text-gray-900">Notifications</h3>
                                        <span className="text-xs text-primary font-medium cursor-pointer hover:underline">Mark all as read</span>
                                    </div>
                                    <div className="max-h-[400px] overflow-y-auto">
                                        {notifications.length > 0 ? (
                                            notifications.map(notif => (
                                                <div
                                                    key={notif.id}
                                                    onClick={() => handleNotificationClick(notif)}
                                                    className={clsx(
                                                        "p-3 hover:bg-gray-50 cursor-pointer border-b border-gray-50 last:border-0 transition-colors",
                                                        !notif.read && "bg-blue-50/30"
                                                    )}
                                                >
                                                    <div className="flex items-start gap-3">
                                                        <div className={clsx(
                                                            "w-2 h-2 mt-2 rounded-full flex-shrink-0",
                                                            !notif.read ? "bg-primary" : "bg-gray-300"
                                                        )} />
                                                        <div>
                                                            <p className={clsx("text-sm", !notif.read ? "font-medium text-gray-900" : "text-gray-600")}>
                                                                {notif.title}
                                                            </p>
                                                            <p className="text-xs text-gray-500 mt-0.5 line-clamp-2">{notif.message}</p>
                                                            <span className="text-[10px] text-gray-400 mt-1 block">{notif.timestamp}</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            ))
                                        ) : (
                                            <div className="p-8 text-center text-gray-500 text-sm">
                                                No notifications
                                            </div>
                                        )}
                                    </div>
                                    <div className="p-2 border-t border-gray-100 bg-gray-50">
                                        <button className="w-full py-1.5 text-sm text-gray-600 hover:text-primary font-medium transition-colors">
                                            View all notifications
                                        </button>
                                    </div>
                                </div>
                            </>
                        )}
                    </div>
                </div>
            </div>

            <StatsDetailModal
                isOpen={isStatsModalOpen}
                onClose={() => setIsStatsModalOpen(false)}
                type="employees"
                data={{
                    projects,
                    tasks: allTasks,
                    teamMembers
                }}
            />
            <AIAssistantModal isOpen={isAIModalOpen} onClose={() => setIsAIModalOpen(false)} />
            <CreateTaskModal
                isOpen={showCreateTask}
                onClose={() => setShowCreateTask(false)}
            />
        </>
    );
};
