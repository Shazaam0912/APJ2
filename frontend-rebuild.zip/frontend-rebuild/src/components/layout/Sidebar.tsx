import { Layout, Calendar, MessageSquare, Settings, Users, FolderKanban, Inbox, FileText, ChevronLeft, ChevronRight, Home, Search, HelpCircle, Plus, Check, ChevronsUpDown } from 'lucide-react';
import clsx from 'clsx';
import { useData } from '../../context/DataContext';
import { CreateProjectModal } from '../modals/CreateProjectModal';
import { InboxModal } from '../modals/InboxModal';
import { IntegrationsModal } from '../modals/IntegrationsModal';

import { useState, useRef, useEffect } from 'react';

export const Sidebar = () => {
    const { activePage, setActivePage, notifications, projects, activeProjectId, switchProject, createProject } = useData();
    const [isCollapsed, setIsCollapsed] = useState(false);
    const [showProjectMenu, setShowProjectMenu] = useState(false);
    const [showCreateProjectModal, setShowCreateProjectModal] = useState(false);
    const [showInboxModal, setShowInboxModal] = useState(false);
    const [showIntegrationsModal, setShowIntegrationsModal] = useState(false);
    const projectMenuRef = useRef<HTMLDivElement>(null);

    const activeProject = projects.find(p => p.id === activeProjectId) || projects[0];

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (projectMenuRef.current && !projectMenuRef.current.contains(event.target as Node)) {
                setShowProjectMenu(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const navItems = [
        { icon: Home, label: 'Overview', id: 'dashboard' },
        { icon: FolderKanban, label: 'Board', id: 'projects' },
        { icon: Calendar, label: 'Calendar', id: 'calendar' },
        { icon: MessageSquare, label: 'Chat', id: 'chat' },
        { icon: FileText, label: 'Documents', id: 'documents' },
        { icon: Users, label: 'Team', id: 'team' },
    ];

    const toolItems = [
        { icon: Inbox, label: 'Inbox', id: 'inbox', badge: notifications.filter(n => !n.read).length },
        { icon: Layout, label: 'Integrations', id: 'integrations' },
        { icon: Search, label: 'API Test', id: 'api-test' },
    ];

    return (
        <div className={clsx(
            "h-full bg-sidebar flex flex-col transition-all duration-300 border-r border-border relative",
            isCollapsed ? "w-16" : "w-64"
        )}>
            {/* Header / Project Switcher */}
            <div className="h-16 flex items-center justify-between px-4 mb-2 relative">
                {!isCollapsed ? (
                    <div className="relative w-full" ref={projectMenuRef}>
                        <button
                            onClick={() => setShowProjectMenu(!showProjectMenu)}
                            className="flex items-center gap-2 w-full p-2 hover:bg-gray-100 rounded-lg transition-colors text-left group"
                        >
                            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-blue-600 flex items-center justify-center shadow-sm flex-shrink-0">
                                <Layout className="w-5 h-5 text-white" />
                            </div>
                            <div className="flex-1 min-w-0">
                                <div className="font-bold text-text text-sm leading-none truncate">{activeProject?.name}</div>
                                <div className="text-[10px] text-muted truncate mt-0.5">{activeProject?.category || 'Software Project'}</div>
                            </div>
                            <ChevronsUpDown className="w-4 h-4 text-muted group-hover:text-text transition-colors" />
                        </button>

                        {/* Project Dropdown */}
                        {showProjectMenu && (
                            <div className="absolute top-full left-0 w-full mt-1 bg-white border border-gray-200 rounded-xl shadow-xl z-50 overflow-hidden animate-in fade-in zoom-in-95 duration-100">
                                <div className="p-2 space-y-0.5 max-h-64 overflow-y-auto">
                                    <div className="px-2 py-1.5 text-xs font-semibold text-muted uppercase tracking-wider">Projects</div>
                                    {projects.map(project => (
                                        <button
                                            key={project.id}
                                            onClick={() => {
                                                switchProject(project.id);
                                                setShowProjectMenu(false);
                                            }}
                                            className={clsx(
                                                "w-full flex items-center gap-2 px-2 py-2 rounded-lg text-sm transition-colors",
                                                activeProjectId === project.id ? "bg-primary/10 text-primary font-medium" : "text-gray-600 hover:bg-gray-50"
                                            )}
                                        >
                                            <div className="w-6 h-6 rounded bg-gray-100 flex items-center justify-center text-xs font-bold text-gray-500">
                                                {project.key.substring(0, 2)}
                                            </div>
                                            <span className="flex-1 text-left truncate">{project.name}</span>
                                            {activeProjectId === project.id && <Check className="w-4 h-4" />}
                                        </button>
                                    ))}
                                </div>
                                <div className="p-2 border-t border-gray-100 bg-gray-50">
                                    <button
                                        onClick={() => {
                                            setShowCreateProjectModal(true);
                                            setShowProjectMenu(false);
                                        }}
                                        className="w-full flex items-center gap-2 px-2 py-2 rounded-lg text-sm font-medium text-primary hover:bg-primary/10 transition-colors"
                                    >
                                        <Plus className="w-4 h-4" />
                                        Create New Project
                                    </button>
                                </div>
                            </div>
                        )}
                    </div>
                ) : (
                    <div className="w-full flex justify-center">
                        <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-blue-600 flex items-center justify-center shadow-md cursor-pointer" title={activeProject?.name}>
                            <Layout className="w-5 h-5 text-white" />
                        </div>
                    </div>
                )}
            </div>

            {/* Collapse Toggle (Absolute to not mess with layout) */}
            <button
                onClick={() => setIsCollapsed(!isCollapsed)}
                className={clsx(
                    "absolute -right-3 top-8 w-6 h-6 bg-white border border-gray-200 rounded-full flex items-center justify-center shadow-sm text-muted hover:text-text transition-colors z-10",
                    isCollapsed && "rotate-180"
                )}
            >
                <ChevronLeft className="w-3 h-3" />
            </button>

            {/* Search */}
            {!isCollapsed && (
                <div className="px-4 mb-6">
                    <div className="relative">
                        <Search className="w-4 h-4 text-muted absolute left-3 top-1/2 -translate-y-1/2" />
                        <input
                            type="text"
                            placeholder="Search"
                            className="w-full bg-white border border-border rounded-lg pl-9 pr-3 py-2 text-sm text-text placeholder-muted focus:outline-none focus:ring-2 focus:ring-primary/20"
                        />
                        <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted text-xs">/</span>
                    </div>
                </div>
            )}

            {/* Navigation */}
            <div className="flex-1 overflow-y-auto px-2 space-y-6">
                {/* Main Menu */}
                <div>
                    {!isCollapsed && <h3 className="px-3 text-xs font-medium text-muted mb-2">Menu</h3>}
                    <nav className="space-y-0.5">
                        {navItems.map((item) => {
                            const Icon = item.icon;
                            const isActive = activePage === item.id;

                            return (
                                <button
                                    key={item.id}
                                    onClick={() => setActivePage(item.id as any)}
                                    className={clsx(
                                        'w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-all text-sm font-medium relative',
                                        isActive
                                            ? 'bg-white text-text shadow-sm ring-1 ring-gray-200'
                                            : 'text-muted hover:text-text hover:bg-gray-100/70'
                                    )}
                                >
                                    <Icon className={clsx("w-5 h-5 flex-shrink-0", isActive ? "text-primary" : "text-muted")} />
                                    {!isCollapsed && <span className="flex-1 text-left">{item.label}</span>}
                                </button>
                            );
                        })}
                    </nav>
                </div>

                {/* Tools Menu */}
                <div>
                    {!isCollapsed && <h3 className="px-3 text-xs font-medium text-muted mb-2">Tools</h3>}
                    <nav className="space-y-0.5">
                        {toolItems.map((item) => {
                            const Icon = item.icon;
                            const handleClick = () => {
                                if (item.id === 'inbox') setShowInboxModal(true);
                                else if (item.id === 'integrations') setShowIntegrationsModal(true);
                                else if (item.id === 'api-test') setActivePage('api-test');
                            };

                            return (
                                <button
                                    key={item.id}
                                    onClick={handleClick}
                                    className={clsx(
                                        'w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-all text-sm font-medium relative text-muted hover:text-text hover:bg-gray-100/70'
                                    )}
                                >
                                    <Icon className="w-5 h-5 flex-shrink-0" />
                                    {!isCollapsed && <span className="flex-1 text-left">{item.label}</span>}
                                    {!isCollapsed && item.badge && item.badge > 0 && (
                                        <span className="bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full min-w-[18px] text-center">
                                            {item.badge}
                                        </span>
                                    )}
                                </button>
                            );
                        })}
                    </nav>
                </div>
            </div>

            {/* Footer */}
            <div className="p-4 mt-auto">
                <div className="space-y-1">
                    <button className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium text-muted hover:text-text hover:bg-gray-100/70 transition-colors">
                        <HelpCircle className="w-5 h-5" />
                        {!isCollapsed && <span>Help Center</span>}
                    </button>
                    <button className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium text-muted hover:text-text hover:bg-gray-100/70 transition-colors">
                        <Settings className="w-5 h-5" />
                        {!isCollapsed && <span>Settings</span>}
                    </button>
                </div>

                {!isCollapsed && (
                    <div className="mt-4 pt-4 border-t border-gray-200">
                        <div className="flex items-center gap-3 bg-white p-2 rounded-xl border border-border shadow-sm">
                            <div className="w-8 h-8 rounded-lg bg-red-100 flex items-center justify-center">
                                <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=David" alt="User" className="w-8 h-8 rounded-lg" />
                            </div>
                            <div className="flex-1 min-w-0">
                                <div className="text-sm font-bold text-text truncate">David Johnson</div>
                                <div className="text-xs text-muted truncate">davidj@gmail.com</div>
                            </div>
                            <ChevronRight className="w-4 h-4 text-muted" />
                        </div>
                    </div>
                )}
            </div>

            {/* Create Project Modal */}
            <CreateProjectModal
                isOpen={showCreateProjectModal}
                onClose={() => setShowCreateProjectModal(false)}
                onCreate={createProject}
            />

            {/* Inbox Modal */}
            <InboxModal
                isOpen={showInboxModal}
                onClose={() => setShowInboxModal(false)}
            />

            {/* Integrations Modal */}
            <IntegrationsModal
                isOpen={showIntegrationsModal}
                onClose={() => setShowIntegrationsModal(false)}
            />
        </div>
    );
};
