import { useEffect, useState, useRef, useMemo } from 'react';
import { Search, ArrowRight, FileText, FolderKanban, Calendar, Users, Settings, Hash } from 'lucide-react';
import clsx from 'clsx';
import { useData, type ActivePage } from '../../context/DataContext';

interface SearchResult {
    id: string;
    type: 'page' | 'task' | 'action';
    title: string;
    subtitle?: string;
    icon: React.ReactNode;
    action: () => void;
}

export const CommandPalette = () => {
    const { setActivePage, data } = useData();
    const [isOpen, setIsOpen] = useState(false);
    const [search, setSearch] = useState('');
    const [selectedIndex, setSelectedIndex] = useState(0);
    const inputRef = useRef<HTMLInputElement>(null);
    const selectedButtonRef = useRef<HTMLButtonElement>(null);

    const navigateToPage = (page: ActivePage) => {
        setActivePage(page);
        setIsOpen(false);
        setSearch('');
    };

    const getAllResults = useMemo((): SearchResult[] => {
        const pages: SearchResult[] = [
            { id: 'dashboard', type: 'page', title: 'Dashboard', subtitle: 'View overview', icon: <Hash className="w-4 h-4" />, action: () => navigateToPage('dashboard') },
            { id: 'projects', type: 'page', title: 'Projects', subtitle: 'Manage tasks', icon: <FolderKanban className="w-4 h-4" />, action: () => navigateToPage('projects') },
            { id: 'documents', type: 'page', title: 'Documents', subtitle: 'Wiki and docs', icon: <FileText className="w-4 h-4" />, action: () => navigateToPage('documents') },
            { id: 'calendar', type: 'page', title: 'Calendar', subtitle: 'Events and meetings', icon: <Calendar className="w-4 h-4" />, action: () => navigateToPage('calendar') },
            { id: 'team', type: 'page', title: 'Team', subtitle: 'View members', icon: <Users className="w-4 h-4" />, action: () => navigateToPage('team') },
            { id: 'settings', type: 'page', title: 'Settings', subtitle: 'Preferences', icon: <Settings className="w-4 h-4" />, action: () => navigateToPage('settings') },
        ];

        const tasks: SearchResult[] = Object.values(data.tasks).map((task) => ({
            id: task.id,
            type: 'task' as const,
            title: task.content,
            subtitle: task.priority + ' priority',
            icon: <Hash className="w-4 h-4" />,
            action: () => {
                navigateToPage('projects');
            },
        }));

        return [...pages, ...tasks];
    }, [data.tasks, setActivePage]);

    const filteredResults = useMemo((): SearchResult[] => {
        if (!search.trim()) {
            return getAllResults.slice(0, 8);
        }

        const query = search.toLowerCase();
        return getAllResults.filter((result) =>
            result.title.toLowerCase().includes(query) ||
            result.subtitle?.toLowerCase().includes(query)
        );
    }, [search, getAllResults]);

    // Reset selected index when search changes
    useEffect(() => {
        setSelectedIndex(0);
    }, [search]);

    // Scroll selected item into view
    useEffect(() => {
        if (selectedButtonRef.current) {
            selectedButtonRef.current.scrollIntoView({
                behavior: 'smooth',
                block: 'nearest',
            });
        }
    }, [selectedIndex]);

    // Keyboard shortcut to open/close
    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
                e.preventDefault();
                setIsOpen((prev) => !prev);
                setSearch('');
                setSelectedIndex(0);
            }
            if (e.key === 'Escape' && isOpen) {
                setIsOpen(false);
                setSearch('');
            }
        };

        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [isOpen]);

    // Focus input when opened
    useEffect(() => {
        if (isOpen && inputRef.current) {
            inputRef.current.focus();
        }
    }, [isOpen]);

    // Navigate with arrow keys
    useEffect(() => {
        if (!isOpen) return;

        const handleKeyDown = (e: KeyboardEvent) => {
            if (e.key === 'ArrowDown') {
                e.preventDefault();
                setSelectedIndex((prev) => (prev + 1) % filteredResults.length);
            } else if (e.key === 'ArrowUp') {
                e.preventDefault();
                setSelectedIndex((prev) => (prev - 1 + filteredResults.length) % filteredResults.length);
            } else if (e.key === 'Enter') {
                e.preventDefault();
                if (filteredResults[selectedIndex]) {
                    filteredResults[selectedIndex].action();
                    setIsOpen(false);
                    setSearch('');
                }
            }
        };

        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [isOpen, selectedIndex, filteredResults]);

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-start justify-center pt-32" onClick={() => setIsOpen(false)}>
            <div className="w-full max-w-2xl bg-surface border border-border rounded-xl shadow-2xl" onClick={(e) => e.stopPropagation()}>
                {/* Search Input */}
                <div className="flex items-center gap-3 p-4 border-b border-border">
                    <Search className="w-5 h-5 text-muted" />
                    <input
                        ref={inputRef}
                        type="text"
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                        placeholder="Search for anything..."
                        className="flex-1 bg-transparent text-white placeholder-muted outline-none text-base"
                    />
                    <kbd className="px-2 py-1 text-xs bg-background rounded border border-border text-muted">ESC</kbd>
                </div>

                {/* Results */}
                <div className="max-h-96 overflow-y-auto">
                    {filteredResults.length === 0 ? (
                        <div className="p-8 text-center text-muted">
                            <p>No results found for "{search}"</p>
                        </div>
                    ) : (
                        <div className="p-2">
                            {filteredResults.map((result, index) => (
                                <button
                                    key={result.id}
                                    ref={index === selectedIndex ? selectedButtonRef : null}
                                    onClick={() => {
                                        result.action();
                                        setIsOpen(false);
                                        setSearch('');
                                    }}
                                    className={clsx(
                                        'w-full flex items-center gap-3 p-3 rounded-lg transition-colors text-left',
                                        index === selectedIndex
                                            ? 'bg-primary/10 text-primary'
                                            : 'text-white hover:bg-hover'
                                    )}
                                >
                                    <div className={clsx(
                                        'w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0',
                                        index === selectedIndex ? 'bg-primary text-white' : 'bg-background text-muted'
                                    )}>
                                        {result.icon}
                                    </div>
                                    <div className="flex-1 min-w-0">
                                        <p className="text-sm font-medium truncate">{result.title}</p>
                                        {result.subtitle && (
                                            <p className="text-xs text-muted truncate">{result.subtitle}</p>
                                        )}
                                    </div>
                                    {index === selectedIndex && (
                                        <ArrowRight className="w-4 h-4 flex-shrink-0" />
                                    )}
                                </button>
                            ))}
                        </div>
                    )}
                </div>

                {/* Footer */}
                <div className="flex items-center justify-between p-3 border-t border-border bg-background/50">
                    <div className="flex items-center gap-4 text-xs text-muted">
                        <div className="flex items-center gap-1">
                            <kbd className="px-1.5 py-0.5 bg-surface rounded border border-border">↑</kbd>
                            <kbd className="px-1.5 py-0.5 bg-surface rounded border border-border">↓</kbd>
                            <span>Navigate</span>
                        </div>
                        <div className="flex items-center gap-1">
                            <kbd className="px-1.5 py-0.5 bg-surface rounded border border-border">↵</kbd>
                            <span>Select</span>
                        </div>
                    </div>
                    <span className="text-xs text-muted">⌘K to close</span>
                </div>
            </div>
        </div>
    );
};
