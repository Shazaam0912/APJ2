import { useState } from 'react';
import { Modal } from '../ui/Modal';
import { Input } from '../ui/Input';
import { Textarea } from '../ui/Textarea';
import { Select } from '../ui/Select';
import { Button } from '../ui/Button';
import { Calendar, Tag } from 'lucide-react';
import { useData } from '../../context/DataContext';

interface CreateTaskModalProps {
    isOpen: boolean;
    onClose: () => void;
    columnId?: string;
}

export const CreateTaskModal = ({ isOpen, onClose, columnId }: CreateTaskModalProps) => {
    const { addTask, teamMembers, data } = useData();
    const [formData, setFormData] = useState({
        title: '',
        description: '',
        priority: 'medium',
        assignee: '',
        dueDate: '',
        labels: '',
    });

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();

        addTask(columnId || Object.keys(data.columns)[0], {
            content: formData.title,
            description: formData.description,
            priority: formData.priority as 'low' | 'medium' | 'high',
            assignee: formData.assignee,
            dueDate: formData.dueDate,
            tags: formData.labels.split(',').map(l => l.trim()).filter(Boolean),
        });

        // Reset form
        setFormData({
            title: '',
            description: '',
            priority: 'medium',
            assignee: '',
            dueDate: '',
            labels: '',
        });

        onClose();
    };

    const priorityOptions = [
        { value: 'low', label: 'Low Priority' },
        { value: 'medium', label: 'Medium Priority' },
        { value: 'high', label: 'High Priority' },
    ];

    const assigneeOptions = [
        { value: '', label: 'Unassigned' },
        ...teamMembers.map(member => ({
            value: member.id,
            label: member.name
        }))
    ];

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="Create New Task" size="lg">
            <form onSubmit={handleSubmit} className="space-y-5">
                {/* Task Title */}
                <Input
                    label="Task Title"
                    placeholder="Enter task title..."
                    required
                    fullWidth
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    leftIcon={<Tag className="w-4 h-4" />}
                />

                {/* Description */}
                <Textarea
                    label="Description"
                    placeholder="Add a description..."
                    rows={4}
                    fullWidth
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    helperText="Provide details about this task"
                />

                {/* Priority & Assignee Row */}
                <div className="grid grid-cols-2 gap-4">
                    <Select
                        label="Priority"
                        required
                        fullWidth
                        options={priorityOptions}
                        value={formData.priority}
                        onChange={(e) => setFormData({ ...formData, priority: e.target.value })}
                    />

                    <Select
                        label="Assignee"
                        fullWidth
                        options={assigneeOptions}
                        value={formData.assignee}
                        onChange={(e) => setFormData({ ...formData, assignee: e.target.value })}
                    />
                </div>

                {/* Due Date & Labels Row */}
                <div className="grid grid-cols-2 gap-4">
                    <Input
                        label="Due Date"
                        type="date"
                        fullWidth
                        value={formData.dueDate}
                        onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
                        leftIcon={<Calendar className="w-4 h-4" />}
                    />

                    <Input
                        label="Labels"
                        placeholder="bug, feature, urgent"
                        fullWidth
                        value={formData.labels}
                        onChange={(e) => setFormData({ ...formData, labels: e.target.value })}
                        leftIcon={<Tag className="w-4 h-4" />}
                        helperText="Separate labels with commas"
                    />
                </div>

                {/* Actions */}
                <div className="flex items-center justify-end gap-3 pt-4 border-t border-gray-200">
                    <Button type="button" variant="ghost" onClick={onClose}>
                        Cancel
                    </Button>
                    <Button type="submit" variant="primary">
                        Create Task
                    </Button>
                </div>
            </form>
        </Modal>
    );
};
