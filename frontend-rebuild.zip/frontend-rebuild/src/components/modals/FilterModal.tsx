import { useState } from 'react';
import { Modal } from '../ui/Modal';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';

interface FilterModalProps {
    isOpen: boolean;
    onClose: () => void;
    onApplyFilters: (filters: FilterState) => void;
    currentFilters: FilterState;
}

export interface FilterState {
    priority: string[];
    assignee: string[];
    labels: string[];
    status: string[];
    dueDate: string;
}

export const FilterModal = ({ isOpen, onClose, onApplyFilters, currentFilters }: FilterModalProps) => {
    const [filters, setFilters] = useState<FilterState>(currentFilters);

    const priorityOptions = ['High', 'Medium', 'Low'];
    const statusOptions = ['To Do', 'In Progress', 'In Review', 'Done'];

    const toggleFilter = (category: keyof Omit<FilterState, 'dueDate'>, value: string) => {
        setFilters(prev => ({
            ...prev,
            [category]: prev[category].includes(value)
                ? prev[category].filter(v => v !== value)
                : [...prev[category], value]
        }));
    };

    const handleApply = () => {
        onApplyFilters(filters);
        onClose();
    };

    const handleClear = () => {
        const emptyFilters: FilterState = {
            priority: [],
            assignee: [],
            labels: [],
            status: [],
            dueDate: '',
        };
        setFilters(emptyFilters);
    };

    const activeFilterCount =
        filters.priority.length +
        filters.assignee.length +
        filters.labels.length +
        filters.status.length +
        (filters.dueDate ? 1 : 0);

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="Filter Tasks" size="md">
            <div className="space-y-6">
                {/* Priority Filters */}
                <div>
                    <label className="text-sm font-semibold text-gray-900 mb-3 block">Priority</label>
                    <div className="flex flex-wrap gap-2">
                        {priorityOptions.map(priority => (
                            <button
                                key={priority}
                                onClick={() => toggleFilter('priority', priority)}
                                className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${filters.priority.includes(priority)
                                    ? 'bg-primary text-white shadow-sm'
                                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                                    }`}
                            >
                                {priority}
                            </button>
                        ))}
                    </div>
                </div>

                {/* Status Filters */}
                <div>
                    <label className="text-sm font-semibold text-gray-900 mb-3 block">Status</label>
                    <div className="flex flex-wrap gap-2">
                        {statusOptions.map(status => (
                            <button
                                key={status}
                                onClick={() => toggleFilter('status', status)}
                                className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${filters.status.includes(status)
                                    ? 'bg-primary text-white shadow-sm'
                                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                                    }`}
                            >
                                {status}
                            </button>
                        ))}
                    </div>
                </div>

                {/* Due Date */}
                <div>
                    <Input
                        label="Due Date"
                        type="date"
                        fullWidth
                        value={filters.dueDate}
                        onChange={(e) => setFilters({ ...filters, dueDate: e.target.value })}
                        helperText="Filter tasks due on or before this date"
                    />
                </div>

                {/* Active Filters Count */}
                {activeFilterCount > 0 && (
                    <div className="flex items-center justify-between p-3 bg-primary-50 rounded-xl border border-primary-200">
                        <span className="text-sm font-medium text-primary-700">
                            {activeFilterCount} filter{activeFilterCount > 1 ? 's' : ''} active
                        </span>
                        <button
                            onClick={handleClear}
                            className="text-sm font-semibold text-primary-600 hover:text-primary-700"
                        >
                            Clear all
                        </button>
                    </div>
                )}

                {/* Actions */}
                <div className="flex items-center justify-end gap-3 pt-4 border-t border-gray-200">
                    <Button variant="ghost" onClick={onClose}>
                        Cancel
                    </Button>
                    <Button variant="primary" onClick={handleApply}>
                        Apply Filters
                    </Button>
                </div>
            </div>
        </Modal>
    );
};
