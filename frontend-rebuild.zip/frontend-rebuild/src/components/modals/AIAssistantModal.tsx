import { useState, useRef, useEffect } from 'react';
import { X, Send, Bot, User, Sparkles, Loader2, AlertCircle } from 'lucide-react';
import clsx from 'clsx';
import { AgentAPI } from '../../services/agent.ts';
import { useData, mentionTeamMembers } from '../../context/DataContext';

interface AIAssistantModalProps {
    isOpen: boolean;
    onClose: () => void;
}

interface Message {
    id: string;
    role: 'user' | 'assistant';
    content: string;
    data?: any;
}

export const AIAssistantModal = ({ isOpen, onClose }: AIAssistantModalProps) => {
    const { refreshProjects, refreshTasks, addNotification, activeProjectId } = useData();
    const [messages, setMessages] = useState<Message[]>([
        {
            id: 'welcome',
            role: 'assistant',
            content: 'Hello! I am your PM-AI Agent. I can help you:\n\n• Generate project plans from briefs\n• Create individual tasks\n• Break down tasks into subtasks\n• Estimate time and costs\n• Analyze project health\n• Prioritize backlogs\n\nWhat would you like to work on?'
        }
    ]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [agentEnabled, setAgentEnabled] = useState(false);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (messagesEndRef.current) {
            messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
        }
    }, [messages]);

    useEffect(() => {
        if (isOpen) {
            AgentAPI.checkStatus()
                .then(status => setAgentEnabled(status.enabled))
                .catch(() => setAgentEnabled(false));
        }
    }, [isOpen]);

    if (!isOpen) return null;

    const handleSend = async () => {
        if (!input.trim() || isLoading) return;

        if (!agentEnabled) {
            setMessages(prev => [...prev,
            { id: Date.now().toString(), role: 'user', content: input },
            { id: 'error', role: 'assistant', content: '⚠️ PM-AI Agent is not configured. Please add your OPENROUTER_API_KEY to backend/.env file.' }
            ]);
            setInput('');
            return;
        }

        const userMessage: Message = { id: Date.now().toString(), role: 'user', content: input };
        setMessages(prev => [...prev, userMessage]);
        setInput('');
        setIsLoading(true);

        try {
            // Use unified agent execute endpoint
            const history = messages.map(m => ({ role: m.role, content: m.content }));
            const response = await AgentAPI.execute(input, {
                project_id: activeProjectId,
                team_members: mentionTeamMembers
            }, history);

            let formatted = '';
            if (response.action === 'clarification_needed') {
                formatted = response.message;
            } else {
                formatted = `✅ **${response.action.replace(/_/g, ' ').toUpperCase()}**\n\n${response.message}\n\n${JSON.stringify(response.result, null, 2)}`;
            }

            const assistantMessage: Message = {
                id: (Date.now() + 1).toString(),
                role: 'assistant',
                content: formatted,
                data: response
            };

            setMessages(prev => [...prev, assistantMessage]);

            // If AI created entities, refresh the data
            if (response.execution_details) {
                await refreshProjects();
                await refreshTasks();

                addNotification({
                    type: 'system',
                    title: 'PM-AI Action Complete',
                    message: response.message
                });
            }
        } catch (error: any) {
            const errorMessage: Message = {
                id: (Date.now() + 1).toString(),
                role: 'assistant',
                content: `❌ Error: ${error.message || 'Failed to get response from PM-AI agent'}`
            };
            setMessages(prev => [...prev, errorMessage]);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <>
            <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm" onClick={onClose} />
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
                <div className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl h-[600px] flex flex-col overflow-hidden">
                    <div className="p-4 border-b border-gray-200 bg-gradient-to-r from-indigo-50 to-purple-50">
                        <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
                                    <Sparkles className="w-5 h-5 text-white" />
                                </div>
                                <div>
                                    <h2 className="text-lg font-bold text-gray-900">PM-AI Agent</h2>
                                    <p className="text-xs text-gray-600">Powered by OpenRouter</p>
                                </div>
                            </div>
                            <button onClick={onClose} className="p-2 hover:bg-white/50 rounded-lg transition-colors">
                                <X className="w-5 h-5 text-gray-600" />
                            </button>
                        </div>
                    </div>

                    <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-gray-50">
                        {messages.map((message) => (
                            <div key={message.id} className={clsx('flex gap-3', message.role === 'user' ? 'justify-end' : 'justify-start')}>
                                {message.role === 'assistant' && (
                                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center flex-shrink-0">
                                        <Bot className="w-4 h-4 text-white" />
                                    </div>
                                )}

                                <div className={clsx('max-w-[80%] rounded-2xl px-4 py-3 shadow-sm', message.role === 'user' ? 'bg-gradient-to-br from-indigo-500 to-purple-600 text-white' : 'bg-white text-gray-900 border border-gray-200')}>
                                    <div className="prose prose-sm max-w-none whitespace-pre-wrap">{message.content}</div>
                                </div>

                                {message.role === 'user' && (
                                    <div className="w-8 h-8 rounded-full bg-gray-300 flex items-center justify-center flex-shrink-0">
                                        <User className="w-4 h-4 text-gray-600" />
                                    </div>
                                )}
                            </div>
                        ))}

                        {isLoading && (
                            <div className="flex gap-3 justify-start">
                                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
                                    <Loader2 className="w-4 h-4 text-white animate-spin" />
                                </div>
                                <div className="bg-white rounded-2xl px-4 py-3 border border-gray-200">
                                    <div className="flex gap-1">
                                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                                    </div>
                                </div>
                            </div>
                        )}

                        <div ref={messagesEndRef} />
                    </div>

                    <div className="p-4 border-t border-gray-200 bg-white">
                        {!agentEnabled && (
                            <div className="mb-3 p-2 bg-amber-50 border border-amber-200 rounded-lg flex items-center gap-2 text-xs text-amber-800">
                                <AlertCircle className="w-4 h-4" />
                                <span>Agent not configured. Add OPENROUTER_API_KEY to backend/.env</span>
                            </div>
                        )}
                        <div className="flex gap-2">
                            <input
                                type="text"
                                value={input}
                                onChange={(e) => setInput(e.target.value)}
                                onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                                placeholder="Describe your project or ask me to break down a task..."
                                className="flex-1 px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
                                disabled={isLoading}
                            />
                            <button
                                onClick={handleSend}
                                disabled={isLoading || !input.trim()}
                                className="px-6 py-3 bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-xl hover:from-indigo-600 hover:to-purple-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 font-medium"
                            >
                                {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                                Send
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};
