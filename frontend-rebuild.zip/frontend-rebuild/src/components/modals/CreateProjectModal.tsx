import { useState } from 'react';
import { Modal } from '../ui/Modal';
import { Input } from '../ui/Input';
import { Textarea } from '../ui/Textarea';
import { Select } from '../ui/Select';
import { Button } from '../ui/Button';


interface CreateProjectModalProps {
    isOpen: boolean;
    onClose: () => void;
    onCreate: (project: any) => void;
}

export const CreateProjectModal = ({ isOpen, onClose, onCreate }: CreateProjectModalProps) => {
    const [formData, setFormData] = useState({
        name: '',
        key: '',
        description: '',
        template: 'kanban',
        category: 'software'
    });

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onCreate(formData);
        onClose();
        setFormData({
            name: '',
            key: '',
            description: '',
            template: 'kanban',
            category: 'software'
        });
    };

    // Auto-generate key from name
    const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const name = e.target.value;
        const key = name
            .split(' ')
            .map(word => word[0])
            .join('')
            .toUpperCase()
            .slice(0, 4);

        setFormData(prev => ({
            ...prev,
            name,
            key: prev.key === '' || prev.key.length < name.length ? key : prev.key
        }));
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="Create New Project" size="lg">
            <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-2 gap-6">
                    <div className="col-span-2 sm:col-span-1">
                        <Input
                            label="Project Name"
                            value={formData.name}
                            onChange={handleNameChange}
                            placeholder="e.g. Website Redesign"
                            required
                            fullWidth
                        />
                    </div>
                    <div className="col-span-2 sm:col-span-1">
                        <Input
                            label="Project Key"
                            value={formData.key}
                            onChange={(e) => setFormData({ ...formData, key: e.target.value.toUpperCase() })}
                            placeholder="e.g. WEB"
                            required
                            fullWidth
                            helperText="Used as a prefix for task IDs (e.g. WEB-101)"
                        />
                    </div>
                </div>

                <Textarea
                    label="Description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Describe the goals and scope of this project..."
                    fullWidth
                    rows={3}
                />

                <div className="grid grid-cols-2 gap-6">
                    <Select
                        label="Template"
                        value={formData.template}
                        onChange={(e) => setFormData({ ...formData, template: e.target.value })}
                        options={[
                            { value: 'kanban', label: 'Kanban Board' },
                            { value: 'scrum', label: 'Scrum Sprint' },
                            { value: 'bug', label: 'Bug Tracking' },
                        ]}
                        fullWidth
                    />
                    <Select
                        label="Category"
                        value={formData.category}
                        onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                        options={[
                            { value: 'software', label: 'Software Development' },
                            { value: 'marketing', label: 'Marketing' },
                            { value: 'business', label: 'Business' },
                            { value: 'design', label: 'Design' },
                        ]}
                        fullWidth
                    />
                </div>

                <div className="flex justify-end gap-3 pt-4 border-t border-gray-100">
                    <Button type="button" variant="ghost" onClick={onClose}>
                        Cancel
                    </Button>
                    <Button type="submit" variant="primary">
                        Create Project
                    </Button>
                </div>
            </form>
        </Modal>
    );
};
