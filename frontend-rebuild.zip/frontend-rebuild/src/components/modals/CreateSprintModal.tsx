
import { useState } from 'react';
import { X, Calendar, Target } from 'lucide-react';
import clsx from 'clsx';
import { type Sprint } from '../../context/DataContext';

interface CreateSprintModalProps {
    isOpen: boolean;
    onClose: () => void;
    onCreate: (sprint: Omit<Sprint, 'id'>) => void;
}

export const CreateSprintModal = ({ isOpen, onClose, onCreate }: CreateSprintModalProps) => {
    const [name, setName] = useState('');
    const [goal, setGoal] = useState('');
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');
    const [capacity, setCapacity] = useState<number | ''>('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();

        if (!name || !startDate || !endDate) return;

        onCreate({
            name,
            goal: goal || undefined,
            startDate,
            endDate,
            capacity: capacity || undefined,
            status: 'planning',
            taskIds: [],
            velocity: 0
        });

        // Reset form
        setName('');
        setGoal('');
        setStartDate('');
        setEndDate('');
        setCapacity('');
        onClose();
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop */}
            <div
                className="absolute inset-0 bg-black/70 backdrop-blur-sm"
                onClick={onClose}
            />

            {/* Modal */}
            <div className="relative bg-surface border border-border rounded-2xl shadow-2xl w-full max-w-lg">
                {/* Header */}
                <div className="flex items-center justify-between p-6 border-b border-border">
                    <h2 className="text-xl font-bold text-white">Create New Sprint</h2>
                    <button
                        onClick={onClose}
                        className="p-2 hover:bg-hover rounded-lg transition-colors"
                    >
                        <X className="w-5 h-5 text-muted" />
                    </button>
                </div>

                {/* Form */}
                <form onSubmit={handleSubmit} className="p-6 space-y-5">
                    {/* Sprint Name */}
                    <div>
                        <label className="block text-sm font-semibold text-white mb-2">
                            Sprint Name *
                        </label>
                        <input
                            type="text"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            placeholder="e.g., Sprint 1, Q4 Sprint 2"
                            className="w-full px-4 py-2.5 bg-background border border-border rounded-lg text-white placeholder:text-muted focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                            required
                        />
                    </div>

                    {/* Sprint Goal */}
                    <div>
                        <label className="block text-sm font-semibold text-white mb-2">
                            <div className="flex items-center gap-2">
                                <Target className="w-4 h-4" />
                                <span>Sprint Goal</span>
                            </div>
                        </label>
                        <textarea
                            value={goal}
                            onChange={(e) => setGoal(e.target.value)}
                            placeholder="What do you want to achieve in this sprint?"
                            rows={3}
                            className="w-full px-4 py-2.5 bg-background border border-border rounded-lg text-white placeholder:text-muted focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent resize-none"
                        />
                    </div>

                    {/* Dates */}
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-semibold text-white mb-2">
                                <div className="flex items-center gap-2">
                                    <Calendar className="w-4 h-4" />
                                    <span>Start Date *</span>
                                </div>
                            </label>
                            <input
                                type="date"
                                value={startDate}
                                onChange={(e) => setStartDate(e.target.value)}
                                className="w-full px-4 py-2.5 bg-background border border-border rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                                required
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-semibold text-white mb-2">
                                <div className="flex items-center gap-2">
                                    <Calendar className="w-4 h-4" />
                                    <span>End Date *</span>
                                </div>
                            </label>
                            <input
                                type="date"
                                value={endDate}
                                onChange={(e) => setEndDate(e.target.value)}
                                min={startDate}
                                className="w-full px-4 py-2.5 bg-background border border-border rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                                required
                            />
                        </div>
                    </div>

                    {/* Capacity */}
                    <div>
                        <label className="block text-sm font-semibold text-white mb-2">
                            Team Capacity (Story Points)
                        </label>
                        <input
                            type="number"
                            value={capacity}
                            onChange={(e) => setCapacity(e.target.value ? parseInt(e.target.value) : '')}
                            placeholder="e.g., 40"
                            min="0"
                            className="w-full px-4 py-2.5 bg-background border border-border rounded-lg text-white placeholder:text-muted focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                        />
                        <p className="text-xs text-muted mt-1">
                            Optional: Set the maximum story points your team can complete
                        </p>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center justify-end gap-3 pt-4">
                        <button
                            type="button"
                            onClick={onClose}
                            className="px-4 py-2 text-sm font-medium text-muted hover:text-white hover:bg-hover rounded-lg transition-colors"
                        >
                            Cancel
                        </button>
                        <button
                            type="submit"
                            disabled={!name || !startDate || !endDate}
                            className={clsx(
                                'px-6 py-2 text-sm font-medium rounded-lg transition-all',
                                name && startDate && endDate
                                    ? 'bg-primary hover:bg-primary/90 text-white'
                                    : 'bg-surface text-muted cursor-not-allowed'
                            )}
                        >
                            Create Sprint
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};
