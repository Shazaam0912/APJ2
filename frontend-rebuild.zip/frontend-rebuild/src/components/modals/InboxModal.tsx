import { X, Mail, Search } from 'lucide-react';
import clsx from 'clsx';
import { useState } from 'react';
import { useData } from '../../context/DataContext';

interface InboxModalProps {
    isOpen: boolean;
    onClose: () => void;
}

export const InboxModal = ({ isOpen, onClose }: InboxModalProps) => {
    const { channels, notifications, markMessageAsRead, markAsRead, setActiveChannelId, setActivePage } = useData();
    const [activeTab, setActiveTab] = useState<'messages' | 'notifications'>('messages');

    if (!isOpen) return null;

    // Get all messages from all channels
    const allMessages = channels.flatMap(ch =>
        ch.messages.filter(m => m.senderId !== 'Me').map(m => ({ ...m, channelName: ch.name, channelId: ch.id }))
    );

    // Filter unread messages
    const unreadMessages = allMessages.filter(m => !m.read);

    const handleMessageClick = (channelId: string, messageId: string) => {
        markMessageAsRead(channelId, messageId);
        setActiveChannelId(channelId);
        setActivePage('chat');
        onClose();
    };

    const handleNotificationClick = (notif: typeof notifications[0]) => {
        markAsRead(notif.id);

        // Navigate based on notification type
        if (notif.channelId) {
            setActiveChannelId(notif.channelId);
            setActivePage('chat');
        } else if (notif.relatedTaskId) {
            // Will handle task navigation later
            setActivePage('projects');
        }
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={onClose}>
            <div
                className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl h-[80vh] flex overflow-hidden"
                onClick={e => e.stopPropagation()}
            >
                {/* Sidebar */}
                <div className="w-64 bg-gray-50 border-r border-gray-200 p-4 flex flex-col">
                    <div className="flex items-center justify-between mb-6">
                        <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                            <Mail className="w-5 h-5" /> Inbox
                        </h2>
                    </div>

                    <nav className="space-y-1 flex-1">
                        <button
                            onClick={() => setActiveTab('messages')}
                            className={clsx("w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm font-medium", activeTab === 'messages' ? "bg-white shadow-sm text-primary" : "text-gray-600 hover:bg-gray-100")}
                        >
                            <span>Messages</span>
                            <span className="bg-primary/10 text-primary px-2 py-0.5 rounded-full text-xs">{unreadMessages.length}</span>
                        </button>
                        <button
                            onClick={() => setActiveTab('notifications')}
                            className={clsx("w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm font-medium", activeTab === 'notifications' ? "bg-white shadow-sm text-primary" : "text-gray-600 hover:bg-gray-100")}
                        >
                            <span>Notifications</span>
                            <span className="bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full text-xs">{notifications.filter(n => !n.read).length}</span>
                        </button>
                    </nav>
                </div>

                {/* Message/Notification List */}
                <div className="flex-1 flex flex-col">
                    <div className="p-4 border-b border-gray-200 flex items-center justify-between">
                        <div className="relative flex-1 max-w-md">
                            <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
                            <input
                                type="text"
                                placeholder={`Search ${activeTab}...`}
                                className="w-full pl-9 pr-4 py-2 bg-gray-50 border-none rounded-lg text-sm focus:ring-2 focus:ring-primary/20"
                            />
                        </div>
                        <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg">
                            <X className="w-5 h-5 text-gray-500" />
                        </button>
                    </div>

                    <div className="flex-1 overflow-y-auto">
                        {activeTab === 'messages' ? (
                            unreadMessages.length > 0 ? unreadMessages.map(message => (
                                <div
                                    key={message.id}
                                    onClick={() => handleMessageClick(message.channelId, message.id)}
                                    className={clsx("p-4 border-b border-gray-100 hover:bg-gray-50 cursor-pointer transition-colors", !message.read && "bg-blue-50/30")}
                                >
                                    <div className="flex items-center justify-between mb-1">
                                        <span className={clsx("font-medium", !message.read ? "text-gray-900" : "text-gray-600")}>{message.senderId}</span>
                                        <span className="text-xs text-gray-400">{message.timestamp}</span>
                                    </div>
                                    <h4 className={clsx("text-sm mb-1", !message.read ? "font-semibold text-gray-900" : "font-medium text-gray-700")}>{message.channelName}</h4>
                                    <p className="text-sm text-gray-500 truncate">{message.content}</p>
                                </div>
                            )) : (
                                <div className="flex items-center justify-center h-full text-gray-400">
                                    <p>No unread messages</p>
                                </div>
                            )
                        ) : (
                            notifications.filter(n => !n.read).length > 0 ? notifications.filter(n => !n.read).map(notif => (
                                <div
                                    key={notif.id}
                                    onClick={() => handleNotificationClick(notif)}
                                    className="p-4 border-b border-gray-100 hover:bg-gray-50 cursor-pointer transition-colors"
                                >
                                    <div className="flex items-center justify-between mb-1">
                                        <span className="font-semibold text-gray-900">{notif.title}</span>
                                        <span className="text-xs text-gray-400">{notif.timestamp}</span>
                                    </div>
                                    <p className="text-sm text-gray-600">{notif.message}</p>
                                    <span className={clsx("inline-block mt-2 text-xs px-2 py-0.5 rounded-full",
                                        notif.type === 'mention' ? 'bg-blue-50 text-blue-700' :
                                            notif.type === 'assignment' ? 'bg-green-50 text-green-700' :
                                                'bg-gray-50 text-gray-700'
                                    )}>
                                        {notif.type}
                                    </span>
                                </div>
                            )) : (
                                <div className="flex items-center justify-center h-full text-gray-400">
                                    <p>No unread notifications</p>
                                </div>
                            )
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};
