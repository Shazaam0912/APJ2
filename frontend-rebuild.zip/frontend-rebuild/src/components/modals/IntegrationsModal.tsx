import { X, Layout, Check, ExternalLink } from 'lucide-react';
import clsx from 'clsx';
import { useState } from 'react';

interface IntegrationsModalProps {
    isOpen: boolean;
    onClose: () => void;
}

export const IntegrationsModal = ({ isOpen, onClose }: IntegrationsModalProps) => {
    if (!isOpen) return null;

    const [integrations, setIntegrations] = useState([
        { id: 'slack', name: 'Slack', description: 'Receive notifications and updates in your Slack channels.', connected: true, icon: 'https://cdn.worldvectorlogo.com/logos/slack-new-logo.svg' },
        { id: 'github', name: 'GitHub', description: 'Link commits and pull requests to your tasks.', connected: true, icon: 'https://cdn.worldvectorlogo.com/logos/github-icon-1.svg' },
        { id: 'figma', name: 'Figma', description: 'Embed designs directly into your project boards.', connected: false, icon: 'https://cdn.worldvectorlogo.com/logos/figma-1.svg' },
        { id: 'google-drive', name: 'Google Drive', description: 'Attach files from Drive to your tasks.', connected: false, icon: 'https://cdn.worldvectorlogo.com/logos/google-drive.svg' },
        { id: 'zoom', name: 'Zoom', description: 'Start meetings directly from task comments.', connected: false, icon: 'https://cdn.worldvectorlogo.com/logos/zoom-app.svg' },
    ]);

    const toggleIntegration = (id: string) => {
        setIntegrations(integrations.map(i => i.id === id ? { ...i, connected: !i.connected } : i));
    };

    return (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={onClose}>
            <div
                className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[80vh] flex flex-col overflow-hidden"
                onClick={e => e.stopPropagation()}
            >
                <div className="p-6 border-b border-gray-200 flex items-center justify-between">
                    <div>
                        <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                            <Layout className="w-5 h-5" /> Integrations
                        </h2>
                        <p className="text-sm text-gray-500 mt-1">Connect your favorite tools to supercharge your workflow.</p>
                    </div>
                    <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg">
                        <X className="w-5 h-5 text-gray-500" />
                    </button>
                </div>

                <div className="flex-1 overflow-y-auto p-6 space-y-4">
                    {integrations.map(integration => (
                        <div key={integration.id} className="flex items-start gap-4 p-4 border border-gray-100 rounded-xl hover:border-gray-200 hover:shadow-sm transition-all">
                            <div className="w-12 h-12 rounded-xl bg-gray-50 p-2 flex items-center justify-center flex-shrink-0">
                                <img src={integration.icon} alt={integration.name} className="w-full h-full object-contain" />
                            </div>
                            <div className="flex-1">
                                <div className="flex items-center justify-between mb-1">
                                    <h3 className="font-semibold text-gray-900">{integration.name}</h3>
                                    <button
                                        onClick={() => toggleIntegration(integration.id)}
                                        className={clsx(
                                            "px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors border",
                                            integration.connected
                                                ? "bg-green-50 text-green-700 border-green-200 hover:bg-green-100"
                                                : "bg-white text-gray-700 border-gray-200 hover:bg-gray-50"
                                        )}
                                    >
                                        {integration.connected ? 'Connected' : 'Connect'}
                                    </button>
                                </div>
                                <p className="text-sm text-gray-500">{integration.description}</p>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};
