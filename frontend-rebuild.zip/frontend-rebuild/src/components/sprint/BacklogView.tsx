import { Package, TrendingUp } from 'lucide-react';
import clsx from 'clsx';
import { type Task } from '../../context/DataContext';
import { StoryPointPicker } from '../ui/StoryPointPicker';

interface BacklogViewProps {
    tasks: Task[];
    onTaskClick: (task: Task) => void;
    onUpdateStoryPoints: (taskId: string, points: number | undefined) => void;
}

export const BacklogView = ({ tasks, onTaskClick, onUpdateStoryPoints }: BacklogViewProps) => {
    // Sort by priority (high > medium > low) and then by creation date
    const sortedTasks = [...tasks].sort((a, b) => {
        const priorityOrder = { high: 0, medium: 1, low: 2 };
        const priorityDiff = priorityOrder[a.priority] - priorityOrder[b.priority];
        if (priorityDiff !== 0) return priorityDiff;
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });

    const totalStoryPoints = tasks.reduce((sum, task) => sum + (task.storyPoints || 0), 0);
    const estimatedTasks = tasks.filter(task => task.storyPoints !== undefined).length;

    if (tasks.length === 0) {
        return (
            <div className="flex flex-col items-center justify-center h-96 text-center">
                <div className="w-20 h-20 rounded-full bg-surface border-2 border-dashed border-border flex items-center justify-center mb-4">
                    <Package className="w-10 h-10 text-muted" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">Backlog is Empty</h3>
                <p className="text-muted text-sm max-w-md">
                    All tasks are assigned to sprints. Create new tasks or move tasks back to the backlog to see them here.
                </p>
            </div>
        );
    }

    return (
        <div className="space-y-4">
            {/* Backlog Header */}
            <div className="flex items-center justify-between p-4 bg-surface border border-border rounded-xl">
                <div className="flex items-center gap-3">
                    <div className="p-2 bg-primary/20 rounded-lg">
                        <Package className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                        <h2 className="text-lg font-bold text-white">Product Backlog</h2>
                        <p className="text-sm text-muted">
                            {tasks.length} {tasks.length === 1 ? 'item' : 'items'} • {estimatedTasks} estimated
                        </p>
                    </div>
                </div>

                <div className="flex items-center gap-2 px-4 py-2 bg-primary/10 border border-primary/30 rounded-lg">
                    <TrendingUp className="w-4 h-4 text-primary" />
                    <span className="text-sm font-semibold text-primary">
                        {totalStoryPoints} Total SP
                    </span>
                </div>
            </div>

            {/* Tasks List */}
            <div className="space-y-2">
                {sortedTasks.map((task, index) => (
                    <div
                        key={task.id}
                        className="group flex items-center gap-4 p-4 bg-surface hover:bg-hover border border-border rounded-xl cursor-pointer transition-all hover:border-primary/50"
                    >
                        {/* Priority Indicator */}
                        <div className="flex items-center gap-3">
                            <span className="text-xs text-muted font-mono w-6">
                                #{index + 1}
                            </span>
                            <div
                                className={clsx(
                                    'w-1 h-12 rounded-full',
                                    task.priority === 'high' && 'bg-red-500',
                                    task.priority === 'medium' && 'bg-yellow-500',
                                    task.priority === 'low' && 'bg-green-500'
                                )}
                            />
                        </div>

                        {/* Task Content */}
                        <div
                            className="flex-1 min-w-0"
                            onClick={() => onTaskClick(task)}
                        >
                            <h3 className="font-semibold text-white mb-1 group-hover:text-primary transition-colors">
                                {task.content}
                            </h3>
                            {task.description && (
                                <p className="text-sm text-muted line-clamp-2 mb-2">
                                    {task.description}
                                </p>
                            )}
                            <div className="flex items-center gap-2 flex-wrap">
                                <span
                                    className={clsx(
                                        'px-2 py-0.5 rounded-full text-xs font-medium',
                                        task.priority === 'high' && 'bg-red-500/20 text-red-400',
                                        task.priority === 'medium' && 'bg-yellow-500/20 text-yellow-400',
                                        task.priority === 'low' && 'bg-green-500/20 text-green-400'
                                    )}
                                >
                                    {task.priority}
                                </span>
                                {task.assignee && (
                                    <span className="text-xs text-muted">
                                        Assigned to {task.assignee}
                                    </span>
                                )}
                                {task.tags.length > 0 && (
                                    <div className="flex items-center gap-1">
                                        {task.tags.slice(0, 3).map(tag => (
                                            <span
                                                key={tag}
                                                className="px-2 py-0.5 bg-surface text-muted rounded-full text-xs"
                                            >
                                                {tag}
                                            </span>
                                        ))}
                                    </div>
                                )}
                            </div>
                        </div>

                        {/* Story Points */}
                        <div
                            className="flex-shrink-0"
                            onClick={(e) => e.stopPropagation()}
                        >
                            <StoryPointPicker
                                value={task.storyPoints}
                                onChange={(points) => onUpdateStoryPoints(task.id, points)}
                            />
                        </div>
                    </div>
                ))}
            </div>

            {/* Estimation Summary */}
            {estimatedTasks < tasks.length && (
                <div className="p-4 bg-yellow-500/10 border border-yellow-500/30 rounded-xl">
                    <p className="text-sm text-yellow-400">
                        <strong>{tasks.length - estimatedTasks}</strong> {tasks.length - estimatedTasks === 1 ? 'task needs' : 'tasks need'} story point estimation
                    </p>
                </div>
            )}
        </div>
    );
};
