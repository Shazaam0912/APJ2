import { useState } from 'react';
import { ChevronDown, ChevronRight, Play, CheckCircle, Calendar, Target } from 'lucide-react';
import clsx from 'clsx';
import { type Sprint, type Task } from '../../context/DataContext';
import { format } from 'date-fns';

interface SprintCardProps {
    sprint: Sprint;
    tasks: Task[];
    isActive?: boolean;
    onStart?: () => void;
    onComplete?: () => void;
    onTaskClick?: (task: Task) => void;
}

export const SprintCard = ({
    sprint,
    tasks,
    isActive = false,
    onStart,
    onComplete,
    onTaskClick
}: SprintCardProps) => {
    const [isExpanded, setIsExpanded] = useState(isActive);

    const totalStoryPoints = tasks.reduce((sum, task) => sum + (task.storyPoints || 0), 0);
    const completedStoryPoints = tasks
        .filter(task => task.completed)
        .reduce((sum, task) => sum + (task.storyPoints || 0), 0);
    const completedTasks = tasks.filter(task => task.completed).length;
    const progressPercentage = totalStoryPoints > 0
        ? Math.round((completedStoryPoints / totalStoryPoints) * 100)
        : 0;

    const getStatusColor = () => {
        switch (sprint.status) {
            case 'active':
                return 'bg-green-500';
            case 'completed':
                return 'bg-blue-500';
            default:
                return 'bg-gray-500';
        }
    };

    const getStatusLabel = () => {
        switch (sprint.status) {
            case 'active':
                return 'Active';
            case 'completed':
                return 'Completed';
            default:
                return 'Planning';
        }
    };

    return (
        <div className={clsx(
            'bg-surface border rounded-xl overflow-hidden transition-all',
            isActive ? 'border-primary shadow-lg shadow-primary/20' : 'border-border'
        )}>
            {/* Header */}
            <div
                className="p-4 cursor-pointer hover:bg-hover transition-colors"
                onClick={() => setIsExpanded(!isExpanded)}
            >
                <div className="flex items-start justify-between gap-4">
                    <div className="flex items-start gap-3 flex-1">
                        <button className="p-1 hover:bg-hover rounded transition-colors mt-0.5">
                            {isExpanded ? (
                                <ChevronDown className="w-4 h-4 text-muted" />
                            ) : (
                                <ChevronRight className="w-4 h-4 text-muted" />
                            )}
                        </button>

                        <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                                <h3 className="text-base font-semibold text-white truncate">
                                    {sprint.name}
                                </h3>
                                <span className={clsx(
                                    'px-2 py-0.5 rounded-full text-xs font-medium',
                                    getStatusColor(),
                                    'text-white'
                                )}>
                                    {getStatusLabel()}
                                </span>
                            </div>

                            {sprint.goal && (
                                <div className="flex items-start gap-2 text-sm text-muted mb-2">
                                    <Target className="w-4 h-4 mt-0.5 flex-shrink-0" />
                                    <p className="line-clamp-2">{sprint.goal}</p>
                                </div>
                            )}

                            <div className="flex items-center gap-4 text-xs text-muted">
                                <div className="flex items-center gap-1">
                                    <Calendar className="w-3.5 h-3.5" />
                                    <span>
                                        {format(new Date(sprint.startDate), 'MMM d')} - {format(new Date(sprint.endDate), 'MMM d, yyyy')}
                                    </span>
                                </div>
                                <span>•</span>
                                <span>{tasks.length} tasks</span>
                                <span>•</span>
                                <span>{totalStoryPoints} SP</span>
                                {sprint.capacity && (
                                    <>
                                        <span>•</span>
                                        <span className={clsx(
                                            totalStoryPoints > sprint.capacity && 'text-yellow-400'
                                        )}>
                                            Capacity: {sprint.capacity} SP
                                        </span>
                                    </>
                                )}
                            </div>
                        </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-2">
                        {sprint.status === 'planning' && onStart && (
                            <button
                                onClick={(e) => {
                                    e.stopPropagation();
                                    onStart();
                                }}
                                className="flex items-center gap-2 px-3 py-1.5 bg-primary hover:bg-primary/90 text-white rounded-lg text-sm font-medium transition-colors"
                            >
                                <Play className="w-4 h-4" />
                                <span>Start Sprint</span>
                            </button>
                        )}
                        {sprint.status === 'active' && onComplete && (
                            <button
                                onClick={(e) => {
                                    e.stopPropagation();
                                    onComplete();
                                }}
                                className="flex items-center gap-2 px-3 py-1.5 bg-green-500 hover:bg-green-600 text-white rounded-lg text-sm font-medium transition-colors"
                            >
                                <CheckCircle className="w-4 h-4" />
                                <span>Complete</span>
                            </button>
                        )}
                    </div>
                </div>

                {/* Progress Bar */}
                {sprint.status !== 'planning' && (
                    <div className="mt-3">
                        <div className="flex items-center justify-between text-xs text-muted mb-1">
                            <span>Progress</span>
                            <span>{completedTasks}/{tasks.length} tasks • {completedStoryPoints}/{totalStoryPoints} SP ({progressPercentage}%)</span>
                        </div>
                        <div className="h-2 bg-background rounded-full overflow-hidden">
                            <div
                                className="h-full bg-primary transition-all duration-300"
                                style={{ width: `${progressPercentage}%` }}
                            />
                        </div>
                    </div>
                )}
            </div>

            {/* Tasks List */}
            {isExpanded && tasks.length > 0 && (
                <div className="border-t border-border p-4 space-y-2">
                    {tasks.map(task => (
                        <div
                            key={task.id}
                            onClick={() => onTaskClick?.(task)}
                            className="flex items-center gap-3 p-3 bg-background hover:bg-hover border border-border rounded-lg cursor-pointer transition-colors group"
                        >
                            <input
                                type="checkbox"
                                checked={task.completed}
                                readOnly
                                className="w-4 h-4 rounded border-border"
                            />
                            <div className="flex-1 min-w-0">
                                <p className={clsx(
                                    'text-sm font-medium',
                                    task.completed ? 'text-muted line-through' : 'text-white'
                                )}>
                                    {task.content}
                                </p>
                                <div className="flex items-center gap-2 mt-1">
                                    <span className={clsx(
                                        'px-2 py-0.5 rounded-full text-xs font-medium',
                                        task.priority === 'high' && 'bg-red-500/20 text-red-400',
                                        task.priority === 'medium' && 'bg-yellow-500/20 text-yellow-400',
                                        task.priority === 'low' && 'bg-green-500/20 text-green-400'
                                    )}>
                                        {task.priority}
                                    </span>
                                    {task.assignee && (
                                        <span className="text-xs text-muted">{task.assignee}</span>
                                    )}
                                </div>
                            </div>
                            {task.storyPoints !== undefined && (
                                <div className="px-2 py-1 bg-primary/20 text-primary text-xs font-bold rounded">
                                    {task.storyPoints} SP
                                </div>
                            )}
                        </div>
                    ))}
                </div>
            )}

            {isExpanded && tasks.length === 0 && (
                <div className="border-t border-border p-8 text-center text-muted text-sm">
                    No tasks in this sprint yet. Drag tasks from the backlog to add them.
                </div>
            )}
        </div>
    );
};
