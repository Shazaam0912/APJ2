import { useState } from 'react';
import { Plus, Zap, ListTodo } from 'lucide-react';
import { type Sprint, type Task, useData } from '../../context/DataContext';
import { SprintCard } from './SprintCard';
import { BacklogView } from './BacklogView';
import { CreateSprintModal } from '../modals/CreateSprintModal';

interface SprintPanelProps {
    onTaskClick: (task: Task) => void;
}

export const SprintPanel = ({ onTaskClick }: SprintPanelProps) => {
    const {
        data,
        sprints,
        activeSprint,
        createSprint,
        startSprint,
        completeSprint,
        updateTaskStoryPoints
    } = useData();

    const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
    const [activeTab, setActiveTab] = useState<'sprints' | 'backlog'>('sprints');

    // Get tasks for each sprint
    const getSprintTasks = (sprint: Sprint): Task[] => {
        return sprint.taskIds
            .map(id => data.tasks[id])
            .filter(Boolean);
    };

    // Get backlog tasks (tasks not assigned to any sprint)
    const backlogTasks = Object.values(data.tasks).filter(
        task => !task.parentId && (!task.sprintId || task.isBacklog)
    );

    // Sort sprints: active first, then planning, then completed
    const sortedSprints = [...sprints].sort((a, b) => {
        const statusOrder = { active: 0, planning: 1, completed: 2 };
        return statusOrder[a.status] - statusOrder[b.status];
    });

    const planningSprints = sortedSprints.filter(s => s.status === 'planning');
    const completedSprints = sortedSprints.filter(s => s.status === 'completed');

    return (
        <div className="flex-1 overflow-auto p-6">
            <div className="max-w-7xl mx-auto space-y-6">
                {/* Header */}
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                        <div className="p-3 bg-primary/20 rounded-xl">
                            <Zap className="w-6 h-6 text-primary" />
                        </div>
                        <div>
                            <h1 className="text-2xl font-bold text-white">Sprint Management</h1>
                            <p className="text-sm text-muted">
                                Plan, track, and manage your agile sprints
                            </p>
                        </div>
                    </div>

                    <button
                        onClick={() => setIsCreateModalOpen(true)}
                        className="flex items-center gap-2 px-4 py-2 bg-primary hover:bg-primary/90 text-white rounded-lg font-medium transition-colors"
                    >
                        <Plus className="w-4 h-4" />
                        <span>New Sprint</span>
                    </button>
                </div>

                {/* Tabs */}
                <div className="flex items-center gap-1 bg-surface border border-border rounded-lg p-1 w-fit">
                    <button
                        onClick={() => setActiveTab('sprints')}
                        className={`flex items-center gap-2 px-4 py-2 rounded text-sm font-medium transition-colors ${activeTab === 'sprints'
                                ? 'bg-primary text-white'
                                : 'text-muted hover:text-white hover:bg-hover'
                            }`}
                    >
                        <Zap className="w-4 h-4" />
                        <span>Sprints</span>
                        <span className="px-1.5 py-0.5 bg-background/50 rounded text-xs">
                            {sprints.length}
                        </span>
                    </button>
                    <button
                        onClick={() => setActiveTab('backlog')}
                        className={`flex items-center gap-2 px-4 py-2 rounded text-sm font-medium transition-colors ${activeTab === 'backlog'
                                ? 'bg-primary text-white'
                                : 'text-muted hover:text-white hover:bg-hover'
                            }`}
                    >
                        <ListTodo className="w-4 h-4" />
                        <span>Backlog</span>
                        <span className="px-1.5 py-0.5 bg-background/50 rounded text-xs">
                            {backlogTasks.length}
                        </span>
                    </button>
                </div>

                {/* Content */}
                {activeTab === 'sprints' ? (
                    <div className="space-y-6">
                        {/* Active Sprint */}
                        {activeSprint && (
                            <div>
                                <h2 className="text-sm font-semibold text-muted uppercase tracking-wide mb-3 flex items-center gap-2">
                                    <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                                    Active Sprint
                                </h2>
                                <SprintCard
                                    sprint={activeSprint}
                                    tasks={getSprintTasks(activeSprint)}
                                    isActive
                                    onComplete={() => completeSprint(activeSprint.id)}
                                    onTaskClick={onTaskClick}
                                />
                            </div>
                        )}

                        {/* Planning Sprints */}
                        {planningSprints.length > 0 && (
                            <div>
                                <h2 className="text-sm font-semibold text-muted uppercase tracking-wide mb-3">
                                    Planning ({planningSprints.length})
                                </h2>
                                <div className="space-y-3">
                                    {planningSprints.map(sprint => (
                                        <SprintCard
                                            key={sprint.id}
                                            sprint={sprint}
                                            tasks={getSprintTasks(sprint)}
                                            onStart={() => startSprint(sprint.id)}
                                            onTaskClick={onTaskClick}
                                        />
                                    ))}
                                </div>
                            </div>
                        )}

                        {/* Completed Sprints */}
                        {completedSprints.length > 0 && (
                            <div>
                                <h2 className="text-sm font-semibold text-muted uppercase tracking-wide mb-3">
                                    Completed ({completedSprints.length})
                                </h2>
                                <div className="space-y-3">
                                    {completedSprints.map(sprint => (
                                        <SprintCard
                                            key={sprint.id}
                                            sprint={sprint}
                                            tasks={getSprintTasks(sprint)}
                                            onTaskClick={onTaskClick}
                                        />
                                    ))}
                                </div>
                            </div>
                        )}

                        {/* Empty State */}
                        {sprints.length === 0 && (
                            <div className="flex flex-col items-center justify-center h-96 text-center">
                                <div className="w-20 h-20 rounded-full bg-surface border-2 border-dashed border-border flex items-center justify-center mb-4">
                                    <Zap className="w-10 h-10 text-muted" />
                                </div>
                                <h3 className="text-lg font-semibold text-white mb-2">No Sprints Yet</h3>
                                <p className="text-muted text-sm max-w-md mb-6">
                                    Create your first sprint to start planning and tracking your team's work in agile iterations.
                                </p>
                                <button
                                    onClick={() => setIsCreateModalOpen(true)}
                                    className="flex items-center gap-2 px-6 py-3 bg-primary hover:bg-primary/90 text-white rounded-lg font-medium transition-colors"
                                >
                                    <Plus className="w-5 h-5" />
                                    <span>Create First Sprint</span>
                                </button>
                            </div>
                        )}
                    </div>
                ) : (
                    <BacklogView
                        tasks={backlogTasks}
                        onTaskClick={onTaskClick}
                        onUpdateStoryPoints={updateTaskStoryPoints}
                    />
                )}
            </div>

            {/* Create Sprint Modal */}
            <CreateSprintModal
                isOpen={isCreateModalOpen}
                onClose={() => setIsCreateModalOpen(false)}
                onCreate={createSprint}
            />
        </div>
    );
};
