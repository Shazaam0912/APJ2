/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        background: '#FFFFFF', // White (Main App Background)
        surface: '#FFFFFF', // White (Cards, Widgets)
        primary: '#5A8FF6', // Arctic Blue (Brand)
        secondary: '#6260C2', // Blueberry
        text: '#111827', // Dark Gray (Headings)
        muted: '#6B7280', // Medium Gray (Secondary Text)
        border: '#E5E7EB', // Light Gray (Borders)
        hover: '#F3F4F6', // Very Light Gray (Hover States)
        sidebar: '#FFFFFF', // Sidebar Background
      }
    },
  },
  plugins: [],
}
